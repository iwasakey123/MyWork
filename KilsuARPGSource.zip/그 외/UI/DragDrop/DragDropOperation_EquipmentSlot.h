// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/DragDropOperation.h"
#include "DragDropOperation_EquipmentSlot.generated.h"

UCLASS()
class KILSUARPG_API UDragDropOperation_EquipmentSlot : public UDragDropOperation
{
	GENERATED_BODY()
	
public:
	UPROPERTY() TSubclassOf<class AItem> EquipmentClass;
	UPROPERTY() int32 Amount;
};
