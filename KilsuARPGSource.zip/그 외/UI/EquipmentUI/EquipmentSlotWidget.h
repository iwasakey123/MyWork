// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "KilsuARPG/Data/Enum/EItem.h"
#include "EquipmentSlotWidget.generated.h"

UCLASS()
class KILSUARPG_API UEquipmentSlotWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	virtual void NativeConstruct() override;
public:
	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	virtual void NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation) override;
	virtual bool NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;

	UPROPERTY(BlueprintReadOnly) TSubclassOf<class AItem> EquipmentClass;
	UPROPERTY() EEquipmentType EquipmentSlotType;

	UPROPERTY(meta = (BindWidget)) class UBorder* ItemBorder;
	UPROPERTY(meta = (BindWidget)) class UImage* Icon;
	
	UFUNCTION(blueprintimplementableevent) void PrintEquipmentText(bool bVisible, EEquipmentType EquipmentType);
	//bind
	UFUNCTION() void UpdateSlot();
};

