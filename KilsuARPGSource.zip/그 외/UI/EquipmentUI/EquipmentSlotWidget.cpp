// Fill out your copyright notice in the Description page of Project Settings.


#include "EquipmentSlotWidget.h"
#include "Components/TextBlock.h"
#include "Components/Border.h"
#include "Components/Image.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Components/InventoryComponent.h"
#include "KilsuARPG/Item/Item.h"
#include "KilsuARPG/Item/Weapon/Weapon.h"
#include "KilsuARPG/Item/Armor/Armor.h"
#include "KilsuARPG/Controllers/MyPlayerController.h"
#include "KilsuARPG/UI/DragDrop/DragDropOperation_Slot.h"
#include "KilsuARPG/UI/DragDrop/DragDropOperation_EquipmentSlot.h"
#include "KilsuARPG/UI/InventoryUI/DraggedInventorySlotWidget.h"

void UEquipmentSlotWidget::NativeConstruct()
{
	Super::NativeConstruct();

}
FReply UEquipmentSlotWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	FEventReply reply;
	reply.NativeReply = Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
	if (InMouseEvent.IsMouseButtonDown(FKey("RightMouseButton")))
	{		
		auto EquipmentComp = GetOwningPlayerPawn()->FindComponentByClass<UEquipmentComponent>();
		auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
		if (EquipmentClass && EquipmentComp && InventoryComp && EquipmentClass)
		{
			if (EquipmentClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Weapon)
			{
				if (InventoryComp->AddItem(EquipmentClass, 1) == 0)
				{		
					EquipmentClass = nullptr;
					EquipmentComp->UnEquipWeapon();		
					UpdateSlot();				
				}				
			}
			else if (EquipmentClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Armor)
			{
				auto Armor = Cast<AArmor>(EquipmentClass.GetDefaultObject());
				if (Armor && InventoryComp->AddItem(EquipmentClass, 1) == 0)
				{									
					EquipmentComp->UnEquipArmor(Armor->ArmorInfo.ArmorType);
					EquipmentClass = nullptr;
					UpdateSlot();
				}
			}
		}
		return reply.NativeReply;
	}
	else if (InMouseEvent.IsMouseButtonDown(FKey("LeftMouseButton")))
	{
		reply = UWidgetBlueprintLibrary::DetectDragIfPressed(InMouseEvent, this, FKey("LeftMouseButton"));
		return reply.NativeReply;
	}
	return reply.NativeReply;
}
void UEquipmentSlotWidget::NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation)
{
	Super::NativeOnDragDetected(InGeometry, InMouseEvent, OutOperation);
	if (EquipmentClass == nullptr) return;

	auto PC = Cast<AMyPlayerController>(GetOwningPlayer());
	auto DraggedSlot = CreateWidget<UDraggedInventorySlotWidget>(PC, PC->GetDraggedSlotClass());
	DraggedSlot->DraggedItemClass = EquipmentClass;	

	auto DDSlot = Cast<UDragDropOperation_EquipmentSlot>(UWidgetBlueprintLibrary::CreateDragDropOperation(UDragDropOperation_EquipmentSlot::StaticClass()));
	
	DDSlot->EquipmentClass = EquipmentClass;	
	DDSlot->DefaultDragVisual = DraggedSlot;
	DDSlot->Pivot = EDragPivot::CenterCenter;
	OutOperation = DDSlot;
	UE_LOG(LogTemp, Warning, TEXT("Item DragDeteced from Equipment"));
}
bool UEquipmentSlotWidget::NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{
	Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);
	
	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	auto EquipmentComp = GetOwningPlayerPawn()->FindComponentByClass<UEquipmentComponent>();
	auto DDSlot = Cast<UDragDropOperation_Slot>(InOperation);

	if (DDSlot && DDSlot->DragSlotItemClass != nullptr)
	{
		switch (EquipmentSlotType)
		{
		case EEquipmentType::MainWeapon:
			if (EquipmentClass == nullptr)
			{
				if (DDSlot->DragSlotItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Weapon)
				{
					InventoryComp->UseItemAtidx(DDSlot->DragSlotIdx, 1);
					return true;
				}				
			}
			else //EquipmentClass != nullptr
			{
				if (DDSlot->DragSlotItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Weapon)
				{
					auto tempWeapon = Cast<AWeapon>(EquipmentClass.GetDefaultObject());
					auto Weapon = Cast<AWeapon>(DDSlot->DragSlotItemClass.GetDefaultObject());
					EquipmentComp->UnEquipWeapon();
					InventoryComp->RemoveItem(DDSlot->DragSlotIdx, 1);
					EquipmentComp->EquipWeapon(Weapon->GetClass(), false);
					InventoryComp->AddItemAtidx(DDSlot->DragSlotIdx, tempWeapon->GetClass(), 1);
					return true;
				}
			}
			return false;
		case EEquipmentType::SubWeapon:
			//SubWeapon
			break;
		case EEquipmentType::Cape:			
		case EEquipmentType::Hand:			
		case EEquipmentType::Head:			
		case EEquipmentType::Upper:			
		case EEquipmentType::Lower:			
		case EEquipmentType::Shoes:
			if (EquipmentClass == nullptr)
			{
				if (DDSlot->DragSlotItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Armor)
				{
					InventoryComp->UseItemAtidx(DDSlot->DragSlotIdx, 1);
					return true;
				}
			}
			else
			{
				if (DDSlot->DragSlotItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Armor)
				{
					auto tempArmor = Cast<AArmor>(EquipmentClass.GetDefaultObject());
					auto Armor = Cast<AArmor>(DDSlot->DragSlotItemClass.GetDefaultObject());
					if(tempArmor->ArmorInfo.ArmorType == Armor->ArmorInfo.ArmorType)
					{
						EquipmentComp->UnEquipArmor(Armor->ArmorInfo.ArmorType);
						InventoryComp->RemoveItem(DDSlot->DragSlotIdx, 1);
						EquipmentComp->EquipArmor(Armor->GetClass());
						InventoryComp->AddItemAtidx(DDSlot->DragSlotIdx, tempArmor->GetClass(), 1);
						return true;
					}
				}
			}
			return false;
		default:
			break;
		}
	}
	return false;
}

void UEquipmentSlotWidget::UpdateSlot()
{
	if (IsValid(EquipmentClass))
	{
		Icon->SetBrushFromTexture(EquipmentClass.GetDefaultObject()->ItemInfo.Icon);
		Icon->SetVisibility(ESlateVisibility::Visible);
		//ItemBorder
		PrintEquipmentText(false,EquipmentSlotType);
	}
	else
	{
		Icon->SetBrushFromTexture(nullptr);
		Icon->SetVisibility(ESlateVisibility::Hidden);
		//ItemBorder
		PrintEquipmentText(true,EquipmentSlotType);
	}
}
