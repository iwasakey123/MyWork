// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "KilsuARPG/Data/Enum/EStat.h"
#include "EquipmentWidget.generated.h"

UCLASS()
class KILSUARPG_API UEquipmentWidget : public UUserWidget
{
	GENERATED_BODY()
protected:
	virtual void NativeConstruct() override;

	//Draghandle
	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	virtual void NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation) override;
	virtual bool NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;

public:
	UPROPERTY(meta = (bindWidget)) class UButton* CloseButton;
	UPROPERTY(meta = (BindWidget)) class UEquipmentSlotWidget* Slot_MainWeapon;
	UPROPERTY(meta = (BindWidget)) UEquipmentSlotWidget* Slot_SubWeapon;
	UPROPERTY(meta = (BindWidget)) UEquipmentSlotWidget* Slot_Head;
	UPROPERTY(meta = (BindWidget)) UEquipmentSlotWidget* Slot_Hand;
	UPROPERTY(meta = (BindWidget)) UEquipmentSlotWidget* Slot_Upper;
	UPROPERTY(meta = (BindWidget)) UEquipmentSlotWidget* Slot_Lower;
	UPROPERTY(meta = (BindWidget)) UEquipmentSlotWidget* Slot_Shoes;
	UPROPERTY(meta = (BindWidget)) UEquipmentSlotWidget* Slot_Cape;

	UPROPERTY(meta = (BindWidget)) class UTextBlock* StatsText_HPMAX;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_MPMAX;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_StaminaMAX;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_STR;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_INT;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_ATT;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_MTT;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_CritChance;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_CritDamage;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_DEF;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_MDEF;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_MoveSpeed;
	UPROPERTY(meta = (BindWidget)) UTextBlock* StatsText_AttackSpeed;
	
	UPROPERTY() TArray<UEquipmentSlotWidget*> AllEquipmentSlots;
	
	UFUNCTION() void CloseEquipmentUI();
	UFUNCTION() void UpdateStatUI();
};
