// Fill out your copyright notice in the Description page of Project Settings.


#include "EquipmentWidget.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "KilsuARPG/Controllers/MyPlayerController.h"
#include "KilsuARPG/UI/EquipmentUI/EquipmentSlotWidget.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/UI/DragDrop/DragDropOperation_Widget.h"
#include "KilsuARPG/Data/Enum/EItem.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"

void UEquipmentWidget::NativeConstruct()
{
	Super::NativeConstruct();
	CloseButton->OnClicked.AddDynamic(this, &UEquipmentWidget::CloseEquipmentUI);

	Slot_MainWeapon->EquipmentSlotType = EEquipmentType::MainWeapon;	
	Slot_MainWeapon->UpdateSlot();
	AllEquipmentSlots.Add(Slot_MainWeapon);
	Slot_SubWeapon->EquipmentSlotType = EEquipmentType::SubWeapon;
	Slot_SubWeapon->UpdateSlot();
	AllEquipmentSlots.Add(Slot_SubWeapon);
	Slot_Head->EquipmentSlotType = EEquipmentType::Head;
	Slot_Head->UpdateSlot();
	AllEquipmentSlots.Add(Slot_Head);
	Slot_Hand->EquipmentSlotType = EEquipmentType::Hand;
	Slot_Hand->UpdateSlot();
	AllEquipmentSlots.Add(Slot_Hand);
	Slot_Upper->EquipmentSlotType = EEquipmentType::Upper;
	Slot_Upper->UpdateSlot();
	AllEquipmentSlots.Add(Slot_Upper);
	Slot_Lower->EquipmentSlotType = EEquipmentType::Lower;
	Slot_Lower->UpdateSlot();
	AllEquipmentSlots.Add(Slot_Lower);
	Slot_Shoes->EquipmentSlotType = EEquipmentType::Shoes;
	Slot_Shoes->UpdateSlot();
	AllEquipmentSlots.Add(Slot_Shoes);
	Slot_Cape->EquipmentSlotType = EEquipmentType::Cape;
	Slot_Cape->UpdateSlot();
	AllEquipmentSlots.Add(Slot_Cape);

	auto StatsComp = GetOwningPlayerPawn()->FindComponentByClass<UStatsComponent>();
	if (StatsComp)
		StatsComp->UpdateStatUI.BindUFunction(this, FName("UpdateStatUI"));
}

void UEquipmentWidget::CloseEquipmentUI()
{
	auto PC = Cast<AMyPlayerController>(GetOwningPlayer());
	if(PC)
		PC->OpenUI(EUIType::Equipment);
}

FReply UEquipmentWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	FEventReply reply;
	reply.NativeReply = Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
	if (InMouseEvent.IsMouseButtonDown(FKey("LeftMouseButton")))
	{
		reply = UWidgetBlueprintLibrary::DetectDragIfPressed(InMouseEvent, this, FKey("LeftMouseButton"));
		return reply.NativeReply;
	}
	return reply.NativeReply;
}
void UEquipmentWidget::NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation)
{
	Super::NativeOnDragDetected(InGeometry, InMouseEvent, OutOperation);

	auto DDWidget = Cast<UDragDropOperation_Widget>(UWidgetBlueprintLibrary::CreateDragDropOperation(UDragDropOperation_Widget::StaticClass()));
	if (DDWidget == nullptr)
		return;
	DDWidget->DragWidget = this;
	DDWidget->DragWindowOffset = InGeometry.AbsoluteToLocal(InMouseEvent.GetScreenSpacePosition());
	DDWidget->DefaultDragVisual = this;
	DDWidget->Pivot = EDragPivot::MouseDown;
	OutOperation = DDWidget;
	UE_LOG(LogTemp, Warning, TEXT("EquipmentWidget DragDetected"));
	this->RemoveFromParent();
}
bool UEquipmentWidget::NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{
	Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);
	
	return false;
}

void UEquipmentWidget::UpdateStatUI()
{
	auto Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (Player == nullptr) return;
	auto StatsComp = Player->FindComponentByClass<UStatsComponent>();
	if (StatsComp == nullptr) return;
	
	FString HPMAX_str = FString("HPMAX : ") + FString::FromInt((int32)StatsComp->HP.Max);
	StatsText_HPMAX->SetText(FText::FromString(HPMAX_str));
	FString MPMAX_str = FString("MPMAX : ") + FString::FromInt((int32)StatsComp->MP.Max);
	StatsText_MPMAX->SetText(FText::FromString(MPMAX_str));
	FString StaminaMAX_str = FString("StaminaMAX : ") + FString::FromInt((int32)StatsComp->Stamina.Max);
	StatsText_StaminaMAX->SetText(FText::FromString(StaminaMAX_str));
	FString STR_str = FString("STR : ") + FString::FromInt((int32)StatsComp->STR.Current);
	StatsText_STR->SetText(FText::FromString(STR_str));
	FString INT_str = FString("INT : ") + FString::FromInt((int32)StatsComp->INT.Current);
	StatsText_INT->SetText(FText::FromString(INT_str));
	FString ATT_str = FString("ATT : ") + FString::FromInt((int32)StatsComp->ATT.Current);
	StatsText_ATT->SetText(FText::FromString(ATT_str));
	FString MTT_str = FString("MTT : ") + FString::FromInt((int32)StatsComp->MTT.Current);
	StatsText_MTT->SetText(FText::FromString(MTT_str));
	FString CritChance_str = FString("CritChance : ") + FString::FromInt((int32)StatsComp->CritChance);
	StatsText_CritChance->SetText(FText::FromString(CritChance_str));
	FString CritDamage_str = FString("CritDamage : ") + FString::FromInt((int32)StatsComp->CritDamage);
	StatsText_CritDamage->SetText(FText::FromString(CritDamage_str));
	FString DEF_str = FString("DEF : ") + FString::FromInt((int32)StatsComp->A_DEF.Current);
	StatsText_DEF->SetText(FText::FromString(DEF_str));
	FString MDEF_str = FString("MDEF : ") + FString::FromInt((int32)StatsComp->M_DEF.Current);
	StatsText_MDEF->SetText(FText::FromString(MDEF_str));
	FString MoveSpeed_str = FString("MoveSpeed : ") + FString::FromInt((int32)Player->GetCharacterMovement()->MaxWalkSpeed);
	StatsText_MoveSpeed->SetText(FText::FromString(MoveSpeed_str));
	auto EquipmentComp = Player->FindComponentByClass<UEquipmentComponent>();
	if (EquipmentComp)
	{
		FString AttackSpeed_str = FString("AttackSpeed : ") + FString::FromInt((int32)EquipmentComp->GetAttackSpeed());
		StatsText_AttackSpeed->SetText(FText::FromString(AttackSpeed_str));
	}
}