// Fill out your copyright notice in the Description page of Project Settings.


#include "HUDUI_Enemy.h"
#include "Components/TextBlock.h"
#include "Components/ProgressBar.h"
#include "KilsuARPG/Characters/EnemyCharacter.h"
#include "KilsuARPG/Components/StatsComponent.h"

void UHUDUI_Enemy::NativeConstruct()
{
	Super::NativeConstruct();
	NameText->TextDelegate.BindUFunction(this, "GetNameText");
	NameText->SynchronizeProperties();
	HPBar->PercentDelegate.BindUFunction(this, "GetHPPer");
	HPBar->SynchronizeProperties();
}

FText UHUDUI_Enemy::GetNameText()
{	
	auto Enemy = Cast<AEnemyCharacter>(OwningActor);
	FString resultName = TEXT("");
	if (Enemy)
		resultName = Enemy->AIName.ToString();
	return FText::FromString(resultName);
}

float UHUDUI_Enemy::GetHPPer()
{
	if (OwningActor == nullptr)  return 0.f;
	auto StatsComp = OwningActor->FindComponentByClass<UStatsComponent>();
	if (StatsComp == nullptr) return 0.f;
	return StatsComp->HP.Current / StatsComp->HP.Max;
}

void UHUDUI_Enemy::PlayFadeAnim(bool Reverse)
{
	Reverse ? PlayAnimationForward(Fade) : PlayAnimationReverse(Fade);
}