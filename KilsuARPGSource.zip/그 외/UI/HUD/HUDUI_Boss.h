// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HUDUI_Boss.generated.h"

/**
 * 
 */
UCLASS()
class KILSUARPG_API UHUDUI_Boss : public UUserWidget
{
	GENERATED_BODY()
	
protected:
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float DeltaTime) override;
	
public:
	UPROPERTY(meta = (BindWidget)) class UTextBlock* NameText;
	UPROPERTY(meta = (BindWidget)) class UProgressBar* HPBar;
	UPROPERTY(meta = (BindWidgetAnim)) UWidgetAnimation* HPBarShow;
	UPROPERTY(meta = (BindWidgetAnim)) UWidgetAnimation* HPBarHide;

	UFUNCTION() float GetHPPer();
	UFUNCTION() void BindHPPer();
};
