// Fill out your copyright notice in the Description page of Project Settings.


#include "HUDUI_Boss.h"
#include "Components/TextBlock.h"
#include "Components/ProgressBar.h"
#include "KilsuARPG/Characters/EnemyCharacter.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "KilsuARPG/Characters/PlayerCharacter.h"
#include "Kismet/GameplayStatics.h"

void UHUDUI_Boss::NativeConstruct()
{
	Super::NativeConstruct();
	//HPBar->PercentDelegate.BindUFunction(this, "GetHPPer");
}
void UHUDUI_Boss::NativeTick(const FGeometry& MyGeometry, float DeltaTime)
{
	Super::NativeTick(MyGeometry, DeltaTime);	
	auto Player = Cast<APlayerCharacter>(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0));
	if (Player)
	{		
		if (Player->BossTarget != nullptr)
		{
			auto Enemy = Cast<AEnemyCharacter>(Player->BossTarget);
			if (Enemy && Enemy->AIType == EAIType::Boss)
			{				
				auto Stats = Enemy->FindComponentByClass<UStatsComponent>();
				if (Stats)
				{
					HPBar->SetPercent(Stats->HP.Current / Stats->HP.Max);					
				}
			}
		}
	}
}

float UHUDUI_Boss::GetHPPer()
{	
	auto Player = Cast<APlayerCharacter>(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0));
	if (Player)
	{		
		if (Player->BossTarget != nullptr)
		{			
			auto Enemy = Cast<AEnemyCharacter>(Player->BossTarget);
			if (Enemy && Enemy->AIType == EAIType::Boss)
			{
				auto Stats = Enemy->FindComponentByClass<UStatsComponent>();
				if (Stats)
					return (Stats->HP.Current / Stats->HP.Max);
			}
		}
	}
	return 0.f;
}

void UHUDUI_Boss::BindHPPer()
{
	//HPBar->PercentDelegate.BindUFunction(this, "GetHPPer");	
}
