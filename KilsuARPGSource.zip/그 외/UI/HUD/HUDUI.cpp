// Fill out your copyright notice in the Description page of Project Settings.


#include "HUDUI.h"
#include "Components/ProgressBar.h"
#include "Components/TextBlock.h"
#include "Components/Border.h"
#include "Kismet/GameplayStatics.h"
#include "KilsuARPG/Characters/PlayerCharacter.h"
#include "KilsuARPG/Components/StatsComponent.h"

void UHUDUI::NativeConstruct()
{
	Super::NativeConstruct();	
	HPBar->PercentDelegate.BindUFunction(this, "GetHPPer");
	HPBar->SynchronizeProperties();
	MPBar->PercentDelegate.BindUFunction(this, "GetMPPer");
	MPBar->SynchronizeProperties();
	StaminaBar->PercentDelegate.BindUFunction(this, FName("GetStaminaPer"));
	StaminaBar->SynchronizeProperties();
	HPBarBorder->SetRenderOpacity(0.f);
	SpecialAttackText->VisibilityDelegate.BindUFunction(this, "ReadyforSpecialAttack");
	SpecialAttackText->SynchronizeProperties();
}

float UHUDUI::GetHPPer()
{
	auto Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (Player)
	{
		auto Stats = Player->FindComponentByClass<UStatsComponent>();
		if (Stats)
		{			
			return Stats->HP.Current / Stats->HP.Max;
		}
	}
	return 0.f;
}

float UHUDUI::GetMPPer()
{
	auto Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (Player)
	{
		auto Stats = Player->FindComponentByClass<UStatsComponent>();
		if (Stats)
		{			
			return Stats->MP.Current / Stats->MP.Max;
		}
	}
	return 0.f;
}

float UHUDUI::GetStaminaPer()
{
	auto Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (Player)
	{
		auto Stats = Player->FindComponentByClass<UStatsComponent>();
		if (Stats)
		{
			return Stats->Stamina.Current / Stats->Stamina.Max;
		}
	}
	return 0.f;
}

ESlateVisibility UHUDUI::ReadyforSpecialAttack()
{
	auto Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (Player)
	{
		auto Stats = Player->FindComponentByClass<UStatsComponent>();
		if (Stats)
		{
			if (Stats->MP.Current == Stats->MP.Max)
			{
				return ESlateVisibility::Visible;
			}
		}
	}
	return ESlateVisibility::Hidden;
}
