// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HUDUI.generated.h"

UCLASS()
class KILSUARPG_API UHUDUI : public UUserWidget
{
	GENERATED_BODY()
	
protected:
	virtual void NativeConstruct() override;
public:
	UPROPERTY(meta = (BindWidget)) class UProgressBar* HPBar;
	UPROPERTY(meta = (BindWidget)) class UProgressBar* StaminaBar;
	UPROPERTY(meta = (BindWidget)) class UProgressBar* MPBar;
	UPROPERTY(meta = (BindWidget)) class UBorder* HPBarBorder;
	UPROPERTY(meta = (BindWidgetAnim)) UWidgetAnimation* HPBorderHitAnim;
	UPROPERTY(meta = (BindWidgetAnim)) UWidgetAnimation* Fade;
	UPROPERTY(meta = (BindWidget)) class UTextBlock* SpecialAttackText;

	//UPROPERTY(meta = (BindWidget)) class UTextBlock* LevelText;
	//UPROPERTY(meta = (BindWidget)) UTextBlock* HPValue;

	UFUNCTION() float GetHPPer();
	UFUNCTION() float GetStaminaPer();
	UFUNCTION() float GetMPPer();
	UFUNCTION() ESlateVisibility ReadyforSpecialAttack();
};
