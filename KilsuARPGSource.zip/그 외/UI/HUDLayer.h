// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Data/Interface/UIInterface.h"
#include "Blueprint/UserWidget.h"
#include "HUDLayer.generated.h"

UCLASS()
class KILSUARPG_API UHUDLayer : public UUserWidget, public IUIInterface
{
	GENERATED_BODY()
	
protected:
	//virtual void NativePreConstruct() override;
	//virtual void NativeConstruct() override;
	virtual bool NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;

public:
	UPROPERTY(meta = (BindWidget)) class UInventoryWidget* WBP_InventoryWidget;
	UPROPERTY(meta = (BindWidget)) class UEquipmentWidget* WBP_EquipmentWidget;
	UPROPERTY(meta = (BindWidget)) class UHUDUI* WBP_HUDUI_Player;
	UPROPERTY(meta = (BindWidget)) class UCanvasPanel* LayerCanvas;
	UPROPERTY(meta = (BindWidget)) class UUserWidget* InGameMenu;
	//UPROPERTY(meta = (BindWidget)) class UHUDUI_Boss* BossHPUI;

	UPROPERTY(meta = (BindWidgetAnim)) class UWidgetAnimation* FadeHUDLayer;

	//IUIInterface
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetVisible(bool Visible, EUIType UIType);
	virtual void SetVisible_Implementation(bool Visible, EUIType UIType) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void FadePlayerUI(bool Reverse);
	virtual void FadePlayerUI_Implementation(bool Reverse) override;
};
