// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "TestBlueprintGeneratedClass.generated.h"

/**
 * 
 */
UCLASS(Blueprintable)
class KILSUARPG_API UTestBlueprintGeneratedClass : public UWidgetBlueprintGeneratedClass
{
	GENERATED_BODY()
	
};
