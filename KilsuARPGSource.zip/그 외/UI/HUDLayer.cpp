// Fill out your copyright notice in the Description page of Project Settings.


#include "HUDLayer.h"
#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "KilsuARPG/UI/DragDrop/DragDropOperation_Widget.h"
#include "KilsuARPG/UI/DragDrop/DragDropOperation_Slot.h"
#include "KilsuARPG/UI/InventoryUI/InventoryWidget.h"
#include "KilsuARPG/UI/EquipmentUI/EquipmentWidget.h"
#include "KilsuARPG/UI/HUD/HUDUI.h"

//void UHUDLayer::NativeConstruct()
//{
//	Super::NativePreConstruct();	
//}

bool UHUDLayer::NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{	
	Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);

	auto DDWidget = Cast<UDragDropOperation_Widget>(InOperation);	
	if (DDWidget == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Error::DDWidget == nullptr"));		
		return false;
	}
	UE_LOG(LogTemp, Warning, TEXT("OnDrop"));
	auto CanvasChild = LayerCanvas->AddChildToCanvas(DDWidget->DragWidget);
	CanvasChild->SetSize(DDWidget->DragWidget->GetDesiredSize());
	FVector2D NewPosition = InGeometry.AbsoluteToLocal(InDragDropEvent.GetScreenSpacePosition()) - DDWidget->DragWindowOffset;
	CanvasChild->SetPosition(NewPosition);
	return true;
}

void UHUDLayer::SetVisible_Implementation(bool Visible, EUIType UIType)
{
	if (WBP_InventoryWidget == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("HUDLayer::WBP_InventoryWidget is not valid"));
		return;
	}
	switch (UIType)
	{
	case EUIType::Inventory:	
		if (Visible == false)
			WBP_InventoryWidget->SetVisibility(ESlateVisibility::Hidden);
		else
			WBP_InventoryWidget->SetVisibility(ESlateVisibility::Visible);
		break;	
	case EUIType::Equipment:
		if (Visible == false)
			WBP_EquipmentWidget->SetVisibility(ESlateVisibility::Hidden);
		else
			WBP_EquipmentWidget->SetVisibility(ESlateVisibility::Visible);
		break;
	case EUIType::Menu:
		if (Visible == false)
			InGameMenu->SetVisibility(ESlateVisibility::Hidden);
		else
			InGameMenu->SetVisibility(ESlateVisibility::Visible);
		break;
	}
}

void UHUDLayer::FadePlayerUI_Implementation(bool Reverse)
{
	auto IsReverse = Reverse ? EUMGSequencePlayMode::Reverse : EUMGSequencePlayMode::Forward;
	WBP_HUDUI_Player->PlayAnimation(WBP_HUDUI_Player->Fade, 0.f, 1, IsReverse);
	auto HUDLayerReverse = Reverse ? EUMGSequencePlayMode::Forward : EUMGSequencePlayMode::Reverse;
	PlayAnimation(FadeHUDLayer, 0.f, 1, HUDLayerReverse);
}
