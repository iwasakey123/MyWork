// Fill out your copyright notice in the Description page of Project Settings.


#include "InventorySlotWidget.h"
#include "Components/TextBlock.h"
#include "Components/Image.h"
#include "KilsuARPG/Item/Item.h"
#include "KilsuARPG/Item/Weapon/Weapon.h"
#include "KilsuARPG/Item/Armor/Armor.h"
#include "Blueprint/WidgetBlueprintLibrary.h"

#include "KilsuARPG/Components/InventoryComponent.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/UI/DragDrop/DragDropOperation_Slot.h"
#include "KilsuARPG/UI/DragDrop/DragDropOperation_EquipmentSlot.h"
#include "KilsuARPG/UI/InventoryUI/DraggedInventorySlotWidget.h"
#include "KilsuARPG/Controllers/MyPlayerController.h"


void UInventorySlotWidget::UpdateSlot()
{
	if (SlotItemClass == nullptr)
	{
		//UE_LOG(LogTemp, Warning, TEXT("null"));
		if (Icon)
			Icon = nullptr;
		AmountText->SetVisibility(ESlateVisibility::Collapsed);
		//ToolTipWidget = nullptr;
	}
	else
	{
		if (SlotItemClass.GetDefaultObject()->ItemInfo.CanStack == false)
			AmountText->SetVisibility(ESlateVisibility::Collapsed);
		else
		{
			AmountText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			FString amount = FString::FromInt(SlotItemAmount);
			AmountText->SetText(FText::FromString(amount));
		}
		if (Icon)
		{
			Icon->SetVisibility(ESlateVisibility::Visible);
			auto IconImage = SlotItemClass.GetDefaultObject()->ItemInfo.Icon;
			Icon->SetBrushFromTexture(IconImage);
		}
	}
}

FReply UInventorySlotWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	FEventReply reply;
	reply.NativeReply = Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);

	if (InMouseEvent.IsMouseButtonDown(FKey("RightMouseButton")))
	{
		auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
		auto EquipmentComp = GetOwningPlayerPawn()->FindComponentByClass<UEquipmentComponent>();
		
		if (SlotItemClass == nullptr)
			return reply.NativeReply;

		if (SlotItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Weapon)
		{			
			auto temp = EquipmentComp->GetCurrentWeapon();
			auto Weapon = Cast<AWeapon>(SlotItemClass.GetDefaultObject());
			EquipmentComp->UnEquipWeapon();
			InventoryComp->RemoveItem(SlotIndex, 1);
			EquipmentComp->EquipWeapon(Weapon->GetClass(), false);
			if (temp != nullptr)
				InventoryComp->AddItemAtidx(SlotIndex, temp);
			return reply.NativeReply.Handled();
		}
		else if (SlotItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Armor)
		{
			auto Armor = Cast<AArmor>(SlotItemClass.GetDefaultObject());
			TSubclassOf<AArmor>temp;
			switch (Armor->ArmorInfo.ArmorType)
			{
			case EArmorType::Head:
				temp = EquipmentComp->GetCurrentHead();
				break;
			case EArmorType::Upper:				
				temp = EquipmentComp->GetCurrentUpper();
				break;
			case EArmorType::Lower:				
				temp = EquipmentComp->GetCurrentLower();
				break;
			case EArmorType::Hand:
				temp = EquipmentComp->GetCurrentHand();
				break;
			case EArmorType::Shoes:
				temp = EquipmentComp->GetCurrentShoes();
				break;
			case EArmorType::Cape:
				temp = EquipmentComp->GetCurrentCape();
				break;
			}

			EquipmentComp->UnEquipArmor(Armor->ArmorInfo.ArmorType);
			InventoryComp->RemoveItem(SlotIndex, 1);
			EquipmentComp->EquipArmor(Armor->GetClass());
			if (temp != nullptr)
				InventoryComp->AddItemAtidx(SlotIndex, temp);
			return reply.NativeReply.Handled();
		}
		else
		{
			InventoryComp->UseItemAtidx(SlotIndex, 1);
		}
		return reply.NativeReply.Handled();
	}
	else
	{
		reply = UWidgetBlueprintLibrary::DetectDragIfPressed(InMouseEvent, this, FKey("LeftMouseButton"));
		//UE_LOG(LogTemp, Warning, TEXT("thisSlotIndex : %d"), SlotIndex);
		return reply.NativeReply;
	}	
	return reply.NativeReply;
}

void UInventorySlotWidget::NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation)
{
	Super::NativeOnDragDetected(InGeometry, InMouseEvent, OutOperation);
	if (SlotItemClass == nullptr) return;

	auto PC = Cast<AMyPlayerController>(GetOwningPlayer());
	auto DraggedSlot = CreateWidget<UDraggedInventorySlotWidget>(PC, PC->GetDraggedSlotClass());	
	DraggedSlot->DraggedItemClass = SlotItemClass;
	DraggedSlot->DraggedAmount = SlotItemAmount;
	
	auto DDSlot = Cast<UDragDropOperation_Slot>(UWidgetBlueprintLibrary::CreateDragDropOperation(UDragDropOperation_Slot::StaticClass()));

	DDSlot->DragSlotItemClass = SlotItemClass;
	DDSlot->DragSlotIdx = SlotIndex;
	DDSlot->DefaultDragVisual = DraggedSlot;
	DDSlot->Pivot = EDragPivot::CenterCenter;
	OutOperation = DDSlot;
	UE_LOG(LogTemp, Warning, TEXT("Item DragDeteced"));	
}

bool UInventorySlotWidget::NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{
	Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);

	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	auto EquipmentComp = GetOwningPlayerPawn()->FindComponentByClass<UEquipmentComponent>();

	auto DDSlot = Cast<UDragDropOperation_Slot>(InOperation);
	auto DDSlotE = Cast<UDragDropOperation_EquipmentSlot>(InOperation);
	//UE_LOG(LogTemp, Warning, TEXT("thisSlotIndex : %d, DragIndex : %d"), SlotIndex, DDSlot->DragSlotIdx);
	if (DDSlot && DDSlot->DragSlotItemClass)
	{
		if (InventoryComp)
		{
			if (DDSlot->DragSlotIdx != SlotIndex)
			{
				InventoryComp->DragSlotByInventory(DDSlot->DragSlotIdx, SlotIndex);
				UE_LOG(LogTemp, Warning, TEXT("OnDropSlot"));
				return true;
			}
		}
	}
	else if (DDSlotE)
	{
		if (IsValid(SlotItemClass))//������ ��������ʴٸ�
		{
			if (SlotItemClass.GetDefaultObject()->ItemInfo.ItemType == DDSlotE->EquipmentClass.GetDefaultObject()->ItemInfo.ItemType)
			{
				if (SlotItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Weapon)
				{
					auto tempWeapon = Cast<AWeapon>(SlotItemClass.GetDefaultObject());
					EquipmentComp->UnEquipWeapon();
					InventoryComp->RemoveItem(SlotIndex, 1);
					EquipmentComp->EquipWeapon(tempWeapon->GetClass(), false);
					InventoryComp->AddItemAtidx(SlotIndex, DDSlotE->EquipmentClass, 1);
					return true;
				}
				else if (SlotItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Armor)
				{
					auto Armor = Cast<AArmor>(DDSlotE->EquipmentClass.GetDefaultObject());
					auto SlotArmor = Cast<AArmor>(SlotItemClass.GetDefaultObject());
					if (Armor->ArmorInfo.ArmorType == SlotArmor->ArmorInfo.ArmorType)
					{
						EquipmentComp->UnEquipArmor(Armor->ArmorInfo.ArmorType);
						InventoryComp->RemoveItem(SlotIndex, 1);
						EquipmentComp->EquipArmor(Armor->GetClass());
						InventoryComp->AddItemAtidx(SlotIndex, DDSlotE->EquipmentClass, 1);
						return true;
					}
				}
			}
			else return false;
		}
		else//������ ����ִٸ�
		{				
			if (InventoryComp->AddItemAtidx(SlotIndex, DDSlotE->EquipmentClass, 1))
			{
				if (DDSlotE->EquipmentClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Weapon)
					EquipmentComp->UnEquipWeapon();
				else if (DDSlotE->EquipmentClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Armor)
				{
					auto Armor = Cast<AArmor>(DDSlotE->EquipmentClass.GetDefaultObject());
					EquipmentComp->UnEquipArmor(Armor->ArmorInfo.ArmorType);
				}
				return true;
			}
		}
	}	
	return false;
}