// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "KilsuARPG/Data/Interface/UIInterface.h"
#include "InventoryWidget.generated.h"

UCLASS()
class KILSUARPG_API UInventoryWidget : public UUserWidget, public IUIInterface
{
	GENERATED_BODY()
	
protected:
	virtual void NativeConstruct() override;
public:
	UPROPERTY(meta = (BindWidget)) class UButton* CloseButton;		
	UPROPERTY(meta = (BindWidget)) class UTextBlock* MoneyText;
	UPROPERTY(meta = (BindWidget)) class UUniformGridPanel* SlotGrid;
	UPROPERTY(meta = (BindWidget)) UButton* B_ALL;
	UPROPERTY(meta = (BindWidget)) UButton* B_Weapon;
	UPROPERTY(meta = (BindWidget)) UButton* B_Armor;
	UPROPERTY(meta = (BindWidget)) UButton* B_Consumable;
	UPROPERTY(meta = (BindWidget)) UButton* B_Quest;
	UPROPERTY(meta = (BindWidget)) UButton* B_ETC;

	UPROPERTY() int32 SlotPerRaw = 4;

	UFUNCTION() void CloseInventoryUI();
	UFUNCTION() void ShowALL();
	UFUNCTION() void ShowWeapon();
	UFUNCTION() void ShowArmor();
	UFUNCTION() void ShowConsumable();
	UFUNCTION() void ShowQuest();
	UFUNCTION() void ShowETC();

	UFUNCTION() void UpdateMoneyText();
	
	//Draghandle
	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	virtual void NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation) override;
	virtual bool NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;

	//UIStateInterface
	UFUNCTION(blueprintNativeEvent, BlueprintCallable) void GenerateSlots();
	virtual void GenerateSlots_Implementation() override;
};
