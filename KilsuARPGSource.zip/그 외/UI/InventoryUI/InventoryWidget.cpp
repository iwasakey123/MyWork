// Fill out your copyright notice in the Description page of Project Settings.

#include "InventoryWidget.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Components/CanvasPanel.h"
#include "Components/TextBlock.h"
#include "Components/Image.h"
#include "Components/Button.h"
#include "Components/UniformGridPanel.h"

#include "KilsuARPG/UI/DragDrop/DragDropOperation_Widget.h"
#include "KilsuARPG/UI/DragDrop/DragDropOperation_Slot.h"
#include "KilsuARPG/Controllers/MyPlayerController.h"
#include "KilsuARPG/Components/InventoryComponent.h"
#include "KilsuARPG/UI/InventoryUI/InventorySlotWidget.h"

void UInventoryWidget::NativeConstruct()
{
	CloseButton->OnClicked.AddDynamic(this, &UInventoryWidget::CloseInventoryUI);
	B_Weapon->OnClicked.AddDynamic(this, &UInventoryWidget::ShowWeapon);
	B_ALL->OnClicked.AddDynamic(this, &UInventoryWidget::ShowALL);
	B_Armor->OnClicked.AddDynamic(this, &UInventoryWidget::ShowArmor);
	B_Consumable->OnClicked.AddDynamic(this, &UInventoryWidget::ShowConsumable);
	UpdateMoneyText();
}

FReply UInventoryWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	FEventReply reply;
	reply.NativeReply = Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
	if (InMouseEvent.IsMouseButtonDown(FKey("LeftMouseButton")))
	{
		reply = UWidgetBlueprintLibrary::DetectDragIfPressed(InMouseEvent, this, FKey("LeftMouseButton"));
		return reply.NativeReply;
	}
	return reply.NativeReply;
}

void UInventoryWidget::NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation)
{
	Super::NativeOnDragDetected(InGeometry, InMouseEvent, OutOperation);

	auto DDWidget = Cast<UDragDropOperation_Widget>(UWidgetBlueprintLibrary::CreateDragDropOperation(UDragDropOperation_Widget::StaticClass()));
	if (DDWidget == nullptr)
		return;
	DDWidget->DragWidget = this;
	DDWidget->DragWindowOffset = InGeometry.AbsoluteToLocal(InMouseEvent.GetScreenSpacePosition());
	DDWidget->DefaultDragVisual = this;
	DDWidget->Pivot = EDragPivot::MouseDown;
	OutOperation = DDWidget;
	UE_LOG(LogTemp, Warning, TEXT("Widget DragDeteced"));
	this->RemoveFromParent();
}

void UInventoryWidget::CloseInventoryUI()
{
	auto PC = Cast<AMyPlayerController>(GetOwningPlayer());
	if (PC)
		PC->OpenUI(EUIType::Inventory);
}

void UInventoryWidget::GenerateSlots_Implementation()
{
	SlotGrid->ClearChildren();
	if (GetOwningPlayerPawn())
	{		
		auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
		if (InventoryComp)
		{
			auto Items = InventoryComp->InventoryItems;
			for (int32 i = 0; i < Items.Num(); i++)
			{
				auto PC = Cast<AMyPlayerController>(GetOwningPlayer());
				if (PC && PC->GetSlotClass() != nullptr)
				{					
					auto MakedSlot = CreateWidget<UInventorySlotWidget>(PC, PC->GetSlotClass());
					MakedSlot->SlotItemClass = InventoryComp->GetItemClassAtidx(i);					
					MakedSlot->SlotItemAmount = InventoryComp->GetAmountAtidx(i);
					MakedSlot->SlotIndex = i;					
					SlotGrid->AddChildToUniformGrid(MakedSlot, i / SlotPerRaw, i%SlotPerRaw);	
					MakedSlot->UpdateSlot();
				}
			}
		}
	}
}

bool UInventoryWidget::NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{
	Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);

	//auto DragSlot = Cast<UDragDropOperation_Slot>(InOperation);	
	//return (DragSlot) ? true : false;
	return false;
}

void UInventoryWidget::UpdateMoneyText()
{
	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp == nullptr)
		return;
	MoneyText->SetText(FText::AsNumber(InventoryComp->GetGold()));
}
void UInventoryWidget::ShowALL()
{
	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp != nullptr)
		InventoryComp->Sort_All();
}
void UInventoryWidget::ShowWeapon()
{
	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp != nullptr)
		InventoryComp->Sort(EItemType::Weapon);
}
void UInventoryWidget::ShowArmor()
{
	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp != nullptr)
		InventoryComp->Sort(EItemType::Armor);
}
void UInventoryWidget::ShowConsumable()
{
	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp != nullptr)
		InventoryComp->Sort(EItemType::Consumable);
}
void UInventoryWidget::ShowQuest()
{
	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp != nullptr)
		InventoryComp->Sort(EItemType::Quest);
}
void UInventoryWidget::ShowETC()
{
	auto InventoryComp = GetOwningPlayerPawn()->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp != nullptr)
		InventoryComp->Sort(EItemType::ETC);
}
