// Fill out your copyright notice in the Description page of Project Settings.


#include "DraggedInventorySlotWidget.h"
#include "Components/Border.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "KilsuARPG/Item/Item.h"

void UDraggedInventorySlotWidget::NativeConstruct()
{
	if (DraggedItemClass != nullptr)
	{
		if (DraggedItemClass.GetDefaultObject()->ItemInfo.CanStack == false)
			AmountText->SetVisibility(ESlateVisibility::Collapsed);
		else
		{
			AmountText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			FString amount = FString::FromInt(DraggedAmount);
			AmountText->SetText(FText::FromString(amount));
		}
		auto ItemInfo = DraggedItemClass.GetDefaultObject()->ItemInfo;
		Icon->SetBrushFromTexture(ItemInfo.Icon);
		Icon->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}