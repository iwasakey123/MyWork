// Fill out your copyright notice in the Description page of Project Settings.


#include "ItemToolTip.h"
#include "KilsuARPG/Item/Item.h"
#include "Components/TextBlock.h"
#include "Components/Image.h"

void UItemToolTip::NativeConstruct()
{
	Super::NativeConstruct();
	//Description->SetAutoWrapText(true);	
	UpdateToolTip();
}

void UItemToolTip::UpdateToolTip()
{
	if (IsValid(ItemClass))
	{
		auto ItemName = ItemClass.GetDefaultObject()->ItemInfo.ItemName; 
		auto ItemDescription = ItemClass.GetDefaultObject()->ItemInfo.Description;
		auto IconImage = ItemClass.GetDefaultObject()->ItemInfo.Icon;
		NameText->SetText(FText::FromString(ItemName));
		Description->SetText(FText::FromString(ItemDescription));
		Icon->SetBrushFromTexture(IconImage);
	}
}