// Fill out your copyright notice in the Description page of Project Settings.


#include "ItemInteractionWidget.h"
#include "Components/TextBlock.h"

void UItemInteractionWidget::NativeConstruct()
{
	Super::NativeConstruct();
}
