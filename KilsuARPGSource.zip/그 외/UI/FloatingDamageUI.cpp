// Fill out your copyright notice in the Description page of Project Settings.


#include "FloatingDamageUI.h"
#include "Components/TextBlock.h"

//void UFloatingDamageUI::NativeConstruct()
//{
//	Super::NativeConstruct();
//	//DamageText->SetText(FText::FromName(FName("ds")));
//}

void UFloatingDamageUI::SetDamageText(FDamage Damage)
{
	if (Damage.bEnchant)
	{
		DamageText->SetColorAndOpacity(FLinearColor(0.75f, 0.13f, 0.f, 1.f));		
	}
	int32 IDamage = (int32)Damage.Damage;
	if (Damage.bIsCrit)
	{
		DamageText->SetText(FText::FromString(FString(TEXT("CRITICAL!"))));		
	}
	else
		DamageText->SetText(FText::FromString(FString::FromInt(IDamage)));
}