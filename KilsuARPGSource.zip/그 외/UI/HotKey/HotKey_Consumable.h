// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HotKey_Consumable.generated.h"

UCLASS()
class KILSUARPG_API UHotKey_Consumable : public UUserWidget
{
	GENERATED_BODY()
	
protected:
	virtual void NativeConstruct() override;

public:
	UPROPERTY(meta = (BindWidget)) class UImage* Icon;
	UPROPERTY(meta = (BindWidget)) class UTextBlock* AmountText;
	UFUNCTION() ESlateVisibility Icon_visible();
	UFUNCTION() FText AmountText_Set();
};
