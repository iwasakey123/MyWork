// Fill out your copyright notice in the Description page of Project Settings.


#include "HotKey_Consumable.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Components/InventoryComponent.h"
#include "Kismet/GameplayStatics.h"
#include "KilsuARPG/Item/Consumable/Potion.h"

void UHotKey_Consumable::NativeConstruct()
{
	Super::NativeConstruct();
	//Icon->SetVisibility(ESlateVisibility::Visible);
	this->VisibilityDelegate.BindUFunction(this, "Icon_visible");
	this->SynchronizeProperties();
	Icon->VisibilityDelegate.BindUFunction(this, "Icon_visible");
	Icon->SynchronizeProperties();
	AmountText->VisibilityDelegate.BindUFunction(this, "Icon_visible");
	AmountText->TextDelegate.BindUFunction(this, "AmountText_Set");
	AmountText->SynchronizeProperties();
}

ESlateVisibility UHotKey_Consumable::Icon_visible()
{	
	auto PlayerCha = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (PlayerCha == nullptr) return ESlateVisibility::Hidden;
	auto InventoryComp = PlayerCha->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp == nullptr) return ESlateVisibility::Hidden;
	for (auto Item : InventoryComp->InventoryItems)
	{
		if (IsValid(Item.ItemClass))
		{
			auto ItemOb = Cast<APotion>(Item.ItemClass.GetDefaultObject());
			if (IsValid(ItemOb))
				return ESlateVisibility::Visible;
		}
	}
	return ESlateVisibility::Hidden;
}

FText UHotKey_Consumable::AmountText_Set()
{
	int32 Amount = 0;
	auto PlayerCha = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (PlayerCha == nullptr) return FText::FromString("");
	auto InventoryComp = PlayerCha->FindComponentByClass<UInventoryComponent>();
	if (InventoryComp)
	{
		for (auto Item : InventoryComp->InventoryItems)
		{
			if (IsValid(Item.ItemClass))
			{
				auto ItemOb = Cast<APotion>(Item.ItemClass.GetDefaultObject());
				if (IsValid(ItemOb))
					Amount += Item.Amount;
			}
		}
		return FText::FromString(FString::FromInt(Amount));
	}else return FText::FromString("");
}