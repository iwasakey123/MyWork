// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Camera/CameraShake.h"
#include "CamShake_StrongEnemyAttack.generated.h"

/**
 * 
 */
UCLASS()
class KILSUARPG_API UCamShake_StrongEnemyAttack : public UCameraShake
{
	GENERATED_BODY()
	
public:
	UCamShake_StrongEnemyAttack();
};
