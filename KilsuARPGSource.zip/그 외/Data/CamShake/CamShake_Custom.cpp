// Fill out your copyright notice in the Description page of Project Settings.


#include "CamShake_Custom.h"

UCamShake_Custom::UCamShake_Custom()
{
	OscillationDuration = _Custom_OscillationDuration;
	OscillationBlendInTime = _Custom_OscillationBlendInTime;
	OscillationBlendOutTime = _Custom_OscillationBlendOutTime;

	LocOscillation.X.Amplitude = _Custom_LocOscillation_X_Amplitude;
	LocOscillation.X.Frequency = _Custom_LocOscillation_X_Frequency;
	LocOscillation.Y.Amplitude = _Custom_LocOscillation_Y_Amplitude;
	LocOscillation.Y.Frequency = _Custom_LocOscillation_Y_Frequency;
	LocOscillation.Z.Amplitude = _Custom_LocOscillation_Z_Amplitude;
	LocOscillation.Z.Frequency = _Custom_LocOscillation_Z_Frequency;
}								