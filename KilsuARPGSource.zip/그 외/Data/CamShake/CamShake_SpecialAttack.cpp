// Fill out your copyright notice in the Description page of Project Settings.


#include "CamShake_SpecialAttack.h"

UCamShake_SpecialAttack::UCamShake_SpecialAttack()
{
	OscillationDuration = 0.2f;//0.015f
	OscillationBlendInTime = 0.1f;
	OscillationBlendOutTime = 0.1f;

	LocOscillation.X.Amplitude = 50.f;//10.f
	LocOscillation.X.Frequency = 400.f;
	//LocOscillation.X.InitialOffset = EInitialOscillatorOffset::EOO_OffsetRandom;
	//LocOscillation.X.Waveform = EOscillatorWaveform::SineWave;
	LocOscillation.Y.Amplitude = 55.f;//11.f
	LocOscillation.Y.Frequency = 80.f;
	LocOscillation.Z.Amplitude = 60.f;//12.f
	LocOscillation.Z.Frequency = 80.f;
}