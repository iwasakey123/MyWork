// Fill out your copyright notice in the Description page of Project Settings.


#include "CamShake_GS.h"

UCamShake_GS::UCamShake_GS()
{
	OscillationDuration = 0.15f;
	OscillationBlendInTime = 0.15f;
	OscillationBlendOutTime = 0.15f;

	LocOscillation.X.Amplitude = 50.f;//10.f
	LocOscillation.X.Frequency = 10.f;
	//LocOscillation.X.InitialOffset = EInitialOscillatorOffset::EOO_OffsetRandom;
	//LocOscillation.X.Waveform = EOscillatorWaveform::SineWave;

	LocOscillation.Z.Amplitude = 50.f;//12.f
	LocOscillation.Z.Frequency = 10.f;
}