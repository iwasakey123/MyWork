// Fill out your copyright notice in the Description page of Project Settings.


#include "CamShake_DefaultAttack.h"

UCamShake_DefaultAttack::UCamShake_DefaultAttack()
{
	OscillationDuration = 0.16f;//0.015f
	OscillationBlendInTime = 0.07f;
	OscillationBlendOutTime = 0.07f;

	LocOscillation.X.Amplitude = 15.f;//10.f
	LocOscillation.X.Frequency = 300.f;
	//LocOscillation.X.InitialOffset = EInitialOscillatorOffset::EOO_OffsetRandom;
	//LocOscillation.X.Waveform = EOscillatorWaveform::SineWave;
	LocOscillation.Y.Amplitude = 16.f;//11.f
	LocOscillation.Y.Frequency = 70.f;
	LocOscillation.Z.Amplitude = 18.f;//12.f
	LocOscillation.Z.Frequency = 70.f;
}