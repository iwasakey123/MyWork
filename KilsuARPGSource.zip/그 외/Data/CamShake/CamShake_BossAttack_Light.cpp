// Fill out your copyright notice in the Description page of Project Settings.


#include "CamShake_BossAttack_Light.h"

UCamShake_BossAttack_Light::UCamShake_BossAttack_Light()
{
	OscillationDuration = 0.5f;
	OscillationBlendInTime = 0.2f;
	OscillationBlendOutTime = 0.2f;

	LocOscillation.X.Amplitude = 10.f;
	LocOscillation.X.Frequency = 30.f;
	LocOscillation.Y.Amplitude = 11.f;
	LocOscillation.Y.Frequency = 30.f;
	LocOscillation.Z.Amplitude = 12.f;
	LocOscillation.Z.Frequency = 30.f;
}