// Fill out your copyright notice in the Description page of Project Settings.


#include "CamShake_StrongEnemyAttack.h"

UCamShake_StrongEnemyAttack::UCamShake_StrongEnemyAttack()
{
	OscillationDuration = 0.5f;
	OscillationBlendInTime = 0.2f;
	OscillationBlendOutTime = 0.2f;

	LocOscillation.X.Amplitude = 30.f;
	LocOscillation.X.Frequency = 30.f;
	LocOscillation.Y.Amplitude = 33.f;
	LocOscillation.Y.Frequency = 30.f;
	LocOscillation.Z.Amplitude = 36.f;
	LocOscillation.Z.Frequency = 30.f;
}