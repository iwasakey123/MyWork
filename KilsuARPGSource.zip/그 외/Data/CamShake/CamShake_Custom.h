// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Camera/CameraShake.h"
#include "CamShake_Custom.generated.h"

UCLASS()
class KILSUARPG_API UCamShake_Custom : public UCameraShake
{
	GENERATED_BODY()
	
public:
	UCamShake_Custom();

	UPROPERTY(EditAnywhere) float _Custom_OscillationDuration = 0.15f;
	UPROPERTY(EditAnywhere) float _Custom_OscillationBlendInTime = 0.07f;
	UPROPERTY(EditAnywhere) float _Custom_OscillationBlendOutTime = 0.07f;

	UPROPERTY(EditAnywhere) float _Custom_LocOscillation_X_Amplitude = 10.f;
	UPROPERTY(EditAnywhere) float _Custom_LocOscillation_X_Frequency = 300.f;

	UPROPERTY(EditAnywhere) float _Custom_LocOscillation_Y_Amplitude = 11.f;
	UPROPERTY(EditAnywhere) float _Custom_LocOscillation_Y_Frequency = 70.f;
	UPROPERTY(EditAnywhere) float _Custom_LocOscillation_Z_Amplitude = 12.f;
	UPROPERTY(EditAnywhere) float _Custom_LocOscillation_Z_Frequency = 70.f;
};																		    
