// Fill out your copyright notice in the Description page of Project Settings.


#include "GhostTrail.h"
#include "Components/PoseableMeshComponent.h"
#include "Kismet/KismetMaterialLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "KilsuARPG/Characters/PlayerCharacter.h"
#include "KilsuARPG/Components/EquipmentComponent.h"

AGhostTrail::AGhostTrail()
{ 
	MainPoseableMesh = CreateDefaultSubobject<UPoseableMeshComponent>(TEXT("PoseableMesh"));
	InitialLifeSpan = 0.35f;
	
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Combines/SK_GhostLadyS2_Weapons1.SK_GhostLadyS2_Weapons1'"));
	if (Mannequin.Succeeded())
	{
		MainPoseableMesh->SetSkeletalMesh(Mannequin.Object);
		SetRootComponent(MainPoseableMesh);
		MainPoseableMesh->SetWorldLocationAndRotation(FVector(0.f, 0.f, -90.f), FRotator(0.f, -90.f, 0.f));
	}

	//PoseableMeshs.SetNum(6);
	//PoseableMeshs[0] = CreateDefaultSubobject<UPoseableMeshComponent>(TEXT("PoseableMesh_0"));
	//PoseableMeshs[0]->SetupAttachment(MainPoseableMesh);
	//PoseableMeshs[1] = CreateDefaultSubobject<UPoseableMeshComponent>(TEXT("PoseableMesh_1"));
	//PoseableMeshs[1]->SetupAttachment(MainPoseableMesh);
	//PoseableMeshs[2] = CreateDefaultSubobject<UPoseableMeshComponent>(TEXT("PoseableMesh_2"));
	//PoseableMeshs[2]->SetupAttachment(MainPoseableMesh);
	//PoseableMeshs[3] = CreateDefaultSubobject<UPoseableMeshComponent>(TEXT("PoseableMesh_3"));
	//PoseableMeshs[3]->SetupAttachment(MainPoseableMesh);
	//PoseableMeshs[4] = CreateDefaultSubobject<UPoseableMeshComponent>(TEXT("PoseableMesh_4"));
	//PoseableMeshs[4]->SetupAttachment(MainPoseableMesh);
	//PoseableMeshs[5] = CreateDefaultSubobject<UPoseableMeshComponent>(TEXT("PoseableMesh_5"));
	//PoseableMeshs[5]->SetupAttachment(MainPoseableMesh);
	
	static ConstructorHelpers::FObjectFinder<UMaterial>Mat(TEXT("Material'/Game/Reource_AddNew/Materials/M_GhostTrail.M_GhostTrail'"));
	if (Mat.Succeeded())
	{
		GhostTrailMat = Mat.Object;			
	}
}

void AGhostTrail::BeginPlay()
{
	Super::BeginPlay();
	//auto Player = Cast<APlayerCharacter>(GetOwner());
	//if (Player)
	//{
		//MainPoseableMesh->SetSkeletalMesh(Player->GetMesh()->SkeletalMesh);		
	//}
	//auto EquipmentComp = GetOwner()->FindComponentByClass<UEquipmentComponent>();
	//if (EquipmentComp)
	//{				
	//	PoseableMeshs[0]->SetSkeletalMesh(EquipmentComp->HeadComp->SkeletalMesh);		
	//	PoseableMeshs[1]->SetSkeletalMesh(EquipmentComp->UpperComp->SkeletalMesh);			
	//	PoseableMeshs[2]->SetSkeletalMesh(EquipmentComp->LowerComp->SkeletalMesh);			
	//	PoseableMeshs[3]->SetSkeletalMesh(EquipmentComp->HandComp->SkeletalMesh);		
	//	PoseableMeshs[4]->SetSkeletalMesh(EquipmentComp->ShoesComp->SkeletalMesh);
	//	PoseableMeshs[5]->SetSkeletalMesh(EquipmentComp->CapeComp->SkeletalMesh);
	//}
	//auto Mats = MainPoseableMesh->GetMaterials();
	//for (auto Mat : Mats)
	//{
	//	int32 i = 0;
	//	MainPoseableMesh->SetMaterial(i, GhostTrailMat);
	//	i++;
	//}
	PlayGhostTrail();
}

void AGhostTrail::PlayGhostTrail()
{
	auto Player = Cast<APlayerCharacter>(GetOwner());
	auto Mats = MainPoseableMesh->GetMaterials();
	for (auto Mat : Mats)
	{
		int32 i = 0;
		auto CreateMat = UKismetMaterialLibrary::CreateDynamicMaterialInstance(GetWorld(), GhostTrailMat);
		DynamicMats.Add(CreateMat);
		MainPoseableMesh->SetMaterial(i, CreateMat);
		MainPoseableMesh->CopyPoseFromSkeletalComponent(Player->GetMesh());	
		i++;
	}
	//if(PoseableMeshs.Num() > 0)
	//{
	//	auto Mats_ = PoseableMeshs[0]->GetMaterials();
	//	for (auto Mat_ : Mats_)
	//	{
	//		int32 idx = 0; 
	//		PoseableMeshs[0]->CopyPoseFromSkeletalComponent(Player->EquipmentComp->HeadComp);
	//		idx++;
	//	}
	//}
	//if (PoseableMeshs.Num() > 1)
	//{
	//	auto Mats_ = PoseableMeshs[1]->GetMaterials();
	//	for (auto Mat_ : Mats_)
	//	{
	//		int32 idx = 0;
	//		PoseableMeshs[1]->CopyPoseFromSkeletalComponent(Player->EquipmentComp->UpperComp);
	//		idx++;
	//	}
	//}
	//if (PoseableMeshs.Num() > 2)
	//{
	//	auto Mats_ = PoseableMeshs[2]->GetMaterials();
	//	for (auto Mat_ : Mats_)
	//	{
	//		int32 idx = 0;
	//		PoseableMeshs[2]->CopyPoseFromSkeletalComponent(Player->EquipmentComp->LowerComp);
	//		idx++;
	//	}
	//}
	//if (PoseableMeshs.Num() > 3)
	//{
	//	auto Mats_ = PoseableMeshs[3]->GetMaterials();
	//	for (auto Mat_ : Mats_)
	//	{
	//		int32 idx = 0;
	//		PoseableMeshs[3]->CopyPoseFromSkeletalComponent(Player->EquipmentComp->HandComp);
	//		idx++;
	//	}
	//}
	//if (PoseableMeshs.Num() > 4)
	//{
	//	auto Mats_ = PoseableMeshs[4]->GetMaterials();
	//	for (auto Mat_ : Mats_)
	//	{
	//		int32 idx = 0;
	//		PoseableMeshs[4]->CopyPoseFromSkeletalComponent(Player->EquipmentComp->ShoesComp);
	//		idx++;
	//	}
	//}
	//if (PoseableMeshs.Num() > 5)
	//{
	//	auto Mats_ = PoseableMeshs[5]->GetMaterials();
	//	for (auto Mat_ : Mats_)
	//	{
	//		int32 idx = 0;
	//		PoseableMeshs[5]->CopyPoseFromSkeletalComponent(Player->EquipmentComp->CapeComp);
	//		idx++;
	//	}
	//}
}
