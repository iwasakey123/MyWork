// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GhostTrail.generated.h"

UCLASS()
class KILSUARPG_API AGhostTrail : public AActor
{
	GENERATED_BODY()
	
public:	
	AGhostTrail();

protected:
	virtual void BeginPlay() override;
	
private:
	UPROPERTY() class UPoseableMeshComponent* MainPoseableMesh;
	UPROPERTY() class UMaterial* GhostTrailMat;
	UPROPERTY() TArray<class UMaterialInstanceDynamic*>DynamicMats;
	UPROPERTY() TArray<UPoseableMeshComponent*>PoseableMeshs;

public:
	UFUNCTION() void PlayGhostTrail();
};
