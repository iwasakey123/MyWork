// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

UENUM(BlueprintType)
enum class EAIBehavior : uint8
{
	Idle UMETA(DisplayName = "Idle"),
	Patrol UMETA(DisplayName = "Patrol"),
	Chase UMETA(DisplayName = "Chase"),
	MeleeAttack UMETA(DisplayName = "MeleeAttack"),
	RangeAttack UMETA(DisplayName = "RangeAttack"),
	Dead UMETA(DisplatName = "Dead"),
	Hit UMETA(DisplayName = "Hit"),
	Strafe UMETA(DisplayName = "Strafe"),
};

UENUM(BlueprintType)
enum class EAIMovement : uint8
{
	Stop UMETA(DisplayName = "Stop"),
	SlowWalk UMETA(DisplayName = "SlowWalk"),
	Walk UMETA(DisplayName = "Walk"),
	Run UMETA(DisplayName= "Run"),
	Sprint UMETA(DisplayName = "Sprint"),
};

UENUM(BlueprintType)
enum class EAIType : uint8
{
	Monster UMETA(DisplayName = "Monster"),
	Boss UMETA(DisplayName = "Boss"),
	NPC UMETA(DisplayName = "NPC"),
};