// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

UENUM()
enum class EStat : uint8
{
	HP UMETA(DisplayName = "HP"),
	MP UMETA(DisplayName = "MP"),
	Stamina UMETA(DisplayName = "Stamina"),
	STR UMETA(DisplayName = "STR"),
	INT UMETA(DisplayName = "INT"),
	ATT UMETA(DisplayName = "ATT"),
	MTT UMETA(DisplayName = "MTT"),
	A_DEF UMETA(DisplayName = "ADEF"),
	M_DEF UMETA(DisplayName = "MDEF"),
	CritChance UMETA(DisplayName = "CritChance"),
	CritDamage UMETA(DisplayName = "CritDamage"),
	MoveSpeed UMETA(DisplayName = "MoveSpeed"),
	AttackSpeed UMETA(DisplayName = "AttackSpeed"),
};