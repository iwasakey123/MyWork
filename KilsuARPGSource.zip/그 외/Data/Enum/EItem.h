// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

UENUM(BLUEPRINTTYPE)
enum class EItemType : uint8
{
	Weapon UMETA(DisplayName = "Weapon"),
	Armor UMETA(DisplayName = "Armor"),
	Consumable UMETA(DisplayName = "Consumable"),
	ETC UMETA(DisplayName = "ETC"),
	Quest UMETA(DisplayName = "Quest"),
};

UENUM(BLUEPRINTTYPE)
enum class EWeaponType : uint8
{
	NoWeapon UMETA(DisplayName = "NoWeapon"),
	Sword UMETA(DisplayName = "Sword"),
	GreatSword UMETA(DisplayName = "GreatSword"),
	Bow UMETA(DisplayName = "Bow"),
	Scythe UMETA(DisplayName = "Scythe"),
};

UENUM(BLUEPRINTTYPE)
enum class EArmorType : uint8
{
	NoArmor UMETA(DisplayName = "NoArmor"),
	Head UMETA(DisplayName = "Head"),
	Upper UMETA(DisplayName = "Upper"),
	Lower UMETA(DisplayName = "Lower"),
	Hand UMETA(DisplayName = "Hand"),
	Shoes UMETA(DisplayName = "Shoes"),
	Cape UMETA(DisplayName = "Cape"),
};

UENUM(BLUEPRINTTYPE)
enum class EQuality : uint8
{
	Normal UMETA(DisplayName = "Normal"),
	Rare UMETA(DisplayName = "Rare"),
	Unique UMETA(DisplayName = "Unique"),
	Legendary UMETA(DisplayName = "Legendary"),
};

UENUM(blueprintType)
enum class EConsumableType : uint8
{
	None UMETA(DisplayName = "None"),
	Potion UMETA(DisplayName = "Potion"),
	Food UMETA(DisplayName = "Food"),
	Scroll UMETA(DisplayName = "Scroll"),
	SkillBook UMETA(DisplayName = "SkillBook"),
};

UENUM(BlueprintType)
enum class EEquipmentType : uint8
{
	MainWeapon UMETA(DisplayName = "MainWeapon"),
	SubWeapon UMETA(DisplayName = "SubWeapon"),
	Head UMETA(DisplayName = "Head"),
	Hand UMETA(DisplayName = "Hand"),
	Shoes UMETA(DisplayName = "Shoes"),
	Upper UMETA(DisplayName = "Upper"),
	Lower UMETA(DisplayName = "Lower"),
	Cape UMETA(DisplayName = "Cape"),
};

UENUM(blueprintType)
enum class EPotionType : uint8
{
	HPPotion UMETA(DisplayName = "HPPotion"),
	MPPotion UMETA(DisplayName = "MPPotion"),
	EXPPotion UMETA(DisplayName = "EXPPotion"),
};