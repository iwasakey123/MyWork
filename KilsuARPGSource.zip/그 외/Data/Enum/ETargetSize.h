// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

UENUM()
enum class ETargetSize : uint8
{
	Small UMETA(DisplayName = "Small"),
	Normal UMETA(DisplayName = "Normal"),
	Big UMETA(DisplayName = "Big"),
};