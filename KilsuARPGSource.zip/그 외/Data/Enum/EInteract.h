// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

UENUM(blueprinttype)
enum class EInteractType : uint8
{
	Item UMETA(DisplayName = "Item"),
	NPC UMETA(DisplayName = "NPC"),
	Door UMETA(DisplayName = "Door"),
};
