// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "KilsuARPG/Data/Struct/FDamage.h"
#include "KilsuARPG/Data/Enum/EAI.h"
#include "CombatInterface.generated.h"

UINTERFACE(MinimalAPI)
class UCombatInterface : public UInterface
{
	GENERATED_BODY()
};

class KILSUARPG_API ICombatInterface
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) FRotator GetDesiredRotation();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) FName GetTag();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool CheckEnemy(const FName& Tag);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void TakeDamaged(const FDamage& Damage, AActor* Causer);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetEnemyTarget(AActor* Enemy, EAIType AIType);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void Target_ParrySuccess(AActor* Target);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void CanFinishExecute(bool on);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetExecutionMode();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void CallResetAttack();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) class UArrowComponent* GetBehindArrowPos();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetGuardHit();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetSpecialHit(bool on);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void GhostTailOnOff(bool on);
};
