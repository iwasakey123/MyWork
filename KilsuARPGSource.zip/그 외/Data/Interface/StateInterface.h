// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "KilsuARPG/Data/Enum/EAI.h"
#include "StateInterface.generated.h"

// This class does not need to be modified.
UINTERFACE(MinimalAPI)
class UStateInterface : public UInterface
{
	GENERATED_BODY()
};

class KILSUARPG_API IStateInterface
{
	GENERATED_BODY()

		// Add interface functions to this class. This is the class that will be inherited to implement this interface.
public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsAlive();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsWalk();
	UFUNCTION(BlueprintNativeEvent, blueprintCallable) bool IsSprint();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsImmotal();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsSuperArmor();
	UFUNCTION(BlueprintNativeEvent, blueprintCallable) void SetImmotal(bool on);
	UFUNCTION(BlueprintNativeEvent, blueprintCallable) bool IsCombat();
	UFUNCTION(BlueprintNativeEvent, blueprintCallable) void SetCombat(bool Combat);
	UFUNCTION(BlueprintNativeEvent, blueprintcallable) float GetAttackSpeed();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetRolling(bool on);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetSliding(bool on);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetMovement(EAIMovement MovementType);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetCanGuard(bool on);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetCanWalk(bool on);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetCanSprint(bool on);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetIsParry(bool on);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetCanAttack_Guard(bool canAttack, bool canGuard);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetSuperArmor(bool on);
};
