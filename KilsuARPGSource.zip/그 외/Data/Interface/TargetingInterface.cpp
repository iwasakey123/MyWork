// Fill out your copyright notice in the Description page of Project Settings.


#include "TargetingInterface.h"

// Add default functionality here for any ITargetingInterface functions that are not pure virtual.
