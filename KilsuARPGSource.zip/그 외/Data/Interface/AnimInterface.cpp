// Fill out your copyright notice in the Description page of Project Settings.


#include "AnimInterface.h"

// Add default functionality here for any IAnimInterface functions that are not pure virtual.
