// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "FSkill.generated.h"

UENUM()
enum class ESkillType : uint8
{
	MeleePassive UMETA(DisplayName = "MeleePassive"),
	MagicPassive UMETA(DisplayName = "MagicPassive"),
	MeleeActive UMETA(DisplayName = "MeleeActive"),
	MagicActive UMETA(DisplayName = "MagicActive"),
	Buff,
	Ultimate,
};

USTRUCT(BlueprintType)
struct FSkillInfo
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere) FName SkillName;
	UPROPERTY(EditAnywhere) FString Description;
	UPROPERTY(EditAnywhere) class UTexture2D* Icon;
	UPROPERTY(EditAnywhere) float Cooldown;
	UPROPERTY(EditAnywhere) int32 MaxLevel;	
	UPROPERTY(EditAnywhere) ESkillType SkillType;
	UPROPERTY(EditAnywhere) class UAnimMontage* SkillMontage;
};
