// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "FDamage.generated.h"

UENUM(BlueprintType)
enum class EDamageType : uint8
{
	CustomDamage UMETA(DisplayName = "CustomDamage"),
	Normal UMETA(DisplayName = "Normal"),
	Heavy UMETA(DisplayName = "Heavy"),
	TakeDown UMETA(DisplayName = "TakeDown"),
	Special UMETA(DisplayName = "Special"),
	InstantDeath UMETA(DisplayName = "InstantDeath"),
};

USTRUCT(BlueprintType)
struct FDamage
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere) bool bSetCustom = false;
	UPROPERTY(EditAnywhere) EDamageType DamageType = EDamageType::Normal;
	UPROPERTY(EditAnywhere) float Damage = 0.f;
	UPROPERTY(EditAnywhere) bool bCanParry = false;
	UPROPERTY(EditAnywhere) bool bCanGuard = false;
	UPROPERTY(EditAnywhere) bool bIsCrit = false;
	UPROPERTY(EditAnywhere) bool bEnchant = false;
};