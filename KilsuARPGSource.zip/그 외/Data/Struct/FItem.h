// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Data/Enum/EItem.h"
#include "KilsuARPG/Data/Enum/EStat.h"
#include "FItem.generated.h"

USTRUCT(Atomic, blueprintType)
struct FItemInfo
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite) EItemType ItemType;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) EQuality Quality;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool CanUse;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool CanStack;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) UTexture2D* Icon;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) UStaticMesh* ItemMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) USkeletalMesh* ItemMeshSK;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) FString ItemName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) FString Description;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TMap<EStat, float> Stats;
};

USTRUCT(blueprinttype)
struct FInventoryItem
{
	GENERATED_BODY()

public:
	UPROPERTY() TSubclassOf<class AItem> ItemClass = nullptr;
	UPROPERTY() int32 Amount = 0;
};

USTRUCT(BLUEPRINTTYPE)
struct FWeaponInfo
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere) FName MontageID;
	UPROPERTY(EditAnywhere) FName SocketName;
	UPROPERTY(EditAnywhere) FName UnArmSocketName;
	UPROPERTY(EditAnywhere) EWeaponType WeaponType;
	UPROPERTY(EditAnywhere) float AttackSpeed;
};

USTRUCT(BLUEPRINTTYPE)
struct FArmorInfo
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere) EArmorType ArmorType;
};

USTRUCT(BlueprintType)
struct FConsumableInfo
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere) EConsumableType ConsumableType;
};

USTRUCT(BlueprintType)
struct FPotionInfo
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere) EPotionType PotionType;
};