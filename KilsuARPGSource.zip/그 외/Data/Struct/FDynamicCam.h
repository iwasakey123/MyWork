// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "FDynamicCam.generated.h"

USTRUCT()
struct FDynamicCam
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere) FVector Location;
	UPROPERTY(EditAnywhere) FVector SocketOffset;
	UPROPERTY(EditAnywhere) FRotator Rotation;
	UPROPERTY(EditAnywhere) float ArmLength;
	UPROPERTY(EditAnywhere) float FOV;
	UPROPERTY(EditAnywhere) float CamLagSpeed;
};