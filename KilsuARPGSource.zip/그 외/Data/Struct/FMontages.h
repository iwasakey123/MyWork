// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"
#include "FMontages.generated.h"

UENUM(blueprintType)
enum class EMontageType : uint8
{
	DefaultAttack UMETA(DisplayName = "DefaultAttack"),
	HeavyAttack UMETA(DisplayName = "HeavyAttack"),
	SpecialAttack UMETA(DisplayName = "SpecialAttack"),
	UltimateAttack UMETA(DisplayName = "UltimateAttack"),
	CustomAttack UMETA(DisplayName = "CustomAttack"),
	Skills UMETA(DisplayName = "Skills"),
	CombatOn UMETA(DisplayName = "CombatOn"),	
	CombatOff UMETA(DisplayName = "CombatOff"),	
	Die UMETA(DisplayName = "Die"),
	Stun UMETA(DisplayName = "Stun"),
	Parry UMETA(DisplayName = "Parry"),
	ParryFaild UMETA(DisplayName = "ParryFaild"),
	ParrySuccess UMETA(DisplayName = "ParrySuccess"),
	Guard UMETA(DisplayName = "Guard"),
	GuardBreak UMETA(DisplayName = "GuardBreak"),
	GuardSuccess UMETA(DisplayName = "GuardSuccess"),
	Execution UMETA(DisplayName = "Execution"),
	Executed UMETA(DisplayName = "Executed"),
	Groggy UMETA(DisplayName = "Groggy"),
	Damaged UMETA(DisplayName = "Damaged"),
	HeavyDamaged UMETA(DisplayName = "HeavyDamaged"),
	TakeDown UMETA(DisplayName = "TakeDown"),
	Rolling_NT UMETA(DisplayName = "Rolling_NT"),
	Rolling_F UMETA(DisplayName = "Rolling_F"),
	Rolling_B UMETA(DisplayName = "Rolling_B"),
	Rolling_L UMETA(DisplayName = "Rolling_L"),
	Rooling_R UMETA(DisplayName = "Rolling_R"),
	Slide_NT UMETA(DisplayName = "Slide_NT"),
	Slide_F UMETA(DisplayName = "Slide_F"),
	Slide_B UMETA(DisplayName = "Slide_B"), 
	Slide_L UMETA(DisplayName = "Slide_L"),
	Slide_R UMETA(DisplayName = "Slide_R"),
	Taunt UMETA(DisplayName = "Taunt"),
	Roar UMETA(DisplayName = "Roar"),
	Drink UMETA(DisplayName = "Drink"),
	Interaction UMETA(DisplayName = "Interaction"),
	MagicWeapon UMETA(DisplayName ="MagicWeapon"),
};

class UAnimMontage;
USTRUCT(blueprintType)
struct FMontages : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere) TArray<UAnimMontage*> DefaultAttack;
	UPROPERTY(EditAnywhere) TArray<UAnimMontage*> HeavyAttack;
	UPROPERTY(EditAnywhere) TArray<UAnimMontage*> SpecialAttack;
	UPROPERTY(EditAnywhere) TArray<UAnimMontage*> UltimateAttack;
	UPROPERTY(EditAnywhere) TArray<UAnimMontage*> CustomAttack;
	UPROPERTY(EditAnywhere) TMap<FName, UAnimMontage*> Skills;
	UPROPERTY(EditAnywhere) UAnimMontage* CombatOn;
	UPROPERTY(EditAnywhere) UAnimMontage* CombatOff;
	UPROPERTY(EditAnywhere) UAnimMontage* Die;
	UPROPERTY(EditAnywhere) UAnimMontage* Stun;
	UPROPERTY(EditAnywhere) UAnimMontage* Parry;
	UPROPERTY(EditAnywhere) UAnimMontage* ParryFaild;
	UPROPERTY(EditAnywhere) UAnimMontage* ParrySuccess;
	UPROPERTY(EditAnywhere) UAnimMontage* Guard;
	UPROPERTY(EditAnywhere) UAnimMontage* GuardBreak;
	UPROPERTY(EditAnywhere) UAnimMontage* GuardSuccess;
	UPROPERTY(EditAnywhere) UAnimMontage* Execution;
	UPROPERTY(EditAnywhere) UAnimMontage* Executed;
	UPROPERTY(EditAnywhere) UAnimMontage* Groggy;
	UPROPERTY(EditAnywhere) UAnimMontage* Damaged;
	UPROPERTY(EditAnywhere) UAnimMontage* HeavyDamaged;
	UPROPERTY(EditAnywhere) UAnimMontage* TakeDown;
	UPROPERTY(EditAnywhere) UAnimMontage* Rolling_NT;
	UPROPERTY(EditAnywhere) UAnimMontage* Rolling_F;
	UPROPERTY(EditAnywhere) UAnimMontage* Rolling_B;
	UPROPERTY(EditAnywhere) UAnimMontage* Rolling_L;
	UPROPERTY(EditAnywhere) UAnimMontage* Rooling_R;
	UPROPERTY(EditAnywhere) UAnimMontage* Slide_NT;
	UPROPERTY(EditAnywhere) UAnimMontage* Slide_F;
	UPROPERTY(EditAnywhere) UAnimMontage* Slide_B;
	UPROPERTY(EditAnywhere) UAnimMontage* Slide_L;
	UPROPERTY(EditAnywhere) UAnimMontage* Slide_R;
	UPROPERTY(EditAnywhere) UAnimMontage* Taunt;
	UPROPERTY(EditAnywhere) UAnimMontage* Roar;
	UPROPERTY(EditAnywhere) UAnimMontage* Drink;
	UPROPERTY(EditAnywhere) TArray<UAnimMontage*> Interactions;
	UPROPERTY(EditAnywhere) UAnimMontage* Enchant;
}; 
