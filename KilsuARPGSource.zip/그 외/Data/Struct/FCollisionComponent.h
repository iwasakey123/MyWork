// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "FCollisionComponent.generated.h"

UENUM()
enum class ECollisionParts : uint8
{
	Weapon UMETA(DisplayName = "Weapon"),
	SubWeapon UMETA(DisplayName = "SubWeapon"),
	Hand_L UMETA(DisplayName = "Hand_L"),
	Hand_R UMETA(DisplayName = "Hand_R"),
	Leg_L UMETA(DisplayName = "Leg_L"),
	Leg_R UMETA(DisplayName = "Leg_R"),
	Custom1 UMETA(DisplayName = "Custom1"),
	Custom2 UMETA(DisplayName = "Custom2"),
	Custom3 UMETA(DisplayName = "Custom3"),
};

USTRUCT()
struct FCollisionComp
{
	GENERATED_BODY()

	UPROPERTY() class UPrimitiveComponent* WeaponComp;
	UPROPERTY() TArray<FName>SocketNames;
};