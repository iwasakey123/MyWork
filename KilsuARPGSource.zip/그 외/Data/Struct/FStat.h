// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Data/Enum/EStat.h"
#include "FStat.generated.h"

USTRUCT()
struct FStat
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere) EStat StatType;
	UPROPERTY(EditAnywhere) float Current;
	UPROPERTY(EditAnywhere) float Max;
		
};
