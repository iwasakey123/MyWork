// Fill out your copyright notice in the Description page of Project Settings.


#include "FloatingDamageActor.h"
#include "Components/WidgetComponent.h"
#include "KilsuARPG/UI/FloatingDamageUI.h"

AFloatingDamageActor::AFloatingDamageActor()
{ 
	PrimaryActorTick.bCanEverTick = true;
	
	static ConstructorHelpers::FObjectFinder<UClass>widgetOb(TEXT("WidgetBlueprint'/Game/BP/UI/WBP_FloatDamage.WBP_FloatDamage_C'"));	
	if (widgetOb.Succeeded())
	{
		DamageUIClass = widgetOb.Object;			
	}	

	static ConstructorHelpers::FObjectFinder<UClass>RedWidgetOb(TEXT("WidgetBlueprint'/Game/BP/UI/WBP_FloatDamage_Red.WBP_FloatDamage_Red_C'"));
	if (RedWidgetOb.Succeeded())
		DamageRedUIClass = RedWidgetOb.Object;

	DamageUIComp = CreateDefaultSubobject<UWidgetComponent>(TEXT("FDamageUIComp"));
	DamageUIComp->SetupAttachment(GetRootComponent());
	DamageUIComp->SetWidgetSpace(EWidgetSpace::Screen);
	DamageUIComp->SetWidgetClass(DamageUIClass);
	DamageUIComp->SetDrawAtDesiredSize(true);

	InitialLifeSpan = 2.f;
}

void AFloatingDamageActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	AddActorWorldOffset(FVector(0.f, 0.f, 0.5f));
}

void AFloatingDamageActor::FloatingDamage(FDamage Damage, bool isRed)
{
	if (isRed)
	{
		//auto widgetob = LoadObject<UClass>(nullptr, TEXT("WidgetBlueprint'/Game/BP/UI/WBP_FloatDamage_Red.WBP_FloatDamage_Red_C'"));	
		DamageUIComp->SetWidgetClass(DamageRedUIClass);
	}
	UFloatingDamageUI* UIOb = Cast<UFloatingDamageUI>(DamageUIComp->GetUserWidgetObject());
	if (UIOb)
		UIOb->SetDamageText(Damage);

}

