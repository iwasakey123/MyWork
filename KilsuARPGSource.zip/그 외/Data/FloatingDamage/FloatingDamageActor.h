// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "KilsuARPG/Data/Struct/FDamage.h"
#include "FloatingDamageActor.generated.h"

UCLASS()
class KILSUARPG_API AFloatingDamageActor : public AActor
{
	GENERATED_BODY()
	
public:	
	AFloatingDamageActor();

protected:
	UPROPERTY() class UWidgetComponent* DamageUIComp;
	UPROPERTY() TSubclassOf<class UFloatingDamageUI> DamageUIClass;
	UPROPERTY() TSubclassOf<class UFloatingDamageUI> DamageRedUIClass;	

public:	
	virtual void Tick(float DeltaTime) override;

	UFUNCTION() void FloatingDamage(FDamage Damage, bool isRed);
};
