// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "KilsuARPG/Data/Enum/EItem.h"
#include "MeshCaptureActor.generated.h"

class UStaticMeshComponent;
UCLASS()
class KILSUARPG_API AMeshCaptureActor : public AActor
{
	GENERATED_BODY()
	
protected:
	virtual void BeginPlay() override;
public:	
	AMeshCaptureActor();

	UPROPERTY(VisibleAnywhere) class USkeletalMeshComponent* MainMesh;
	UPROPERTY(VisibleAnywhere) class USpringArmComponent* SpringArm;
	UPROPERTY(VisibleAnywhere) class USceneCaptureComponent2D* SceneCaptureComp;
	UPROPERTY(VisibleAnywhere) class UAnimSequence* IdleAnim;
	UPROPERTY(VisibleAnywhere) UStaticMeshComponent* BackGround;
	
	UPROPERTY(VisibleAnywhere) UStaticMeshComponent* MainWeapon;
	UPROPERTY(VisibleAnywhere) UStaticMeshComponent* SubWeapon;
	UPROPERTY(visibleAnywhere) USkeletalMeshComponent* Hair;
	//UPROPERTY() USkeletalMesh* Hair_NoEquip;
	//UPROPERTY() USkeletalMesh* Hair_EquipHead;
	UPROPERTY(VisibleAnywhere) USkeletalMeshComponent* Head;
	UPROPERTY(VisibleAnywhere) USkeletalMeshComponent* Hand;
	UPROPERTY(VisibleAnywhere) USkeletalMeshComponent* Shoes;
	UPROPERTY(VisibleAnywhere) USkeletalMeshComponent* Upper;
	UPROPERTY(VisibleAnywhere) USkeletalMeshComponent* Lower;
	UPROPERTY(VisibleAnywhere) USkeletalMeshComponent* Cape;

	UPROPERTY() USkeletalMesh* Head_Default;
	UPROPERTY() USkeletalMesh* Upper_Default;
	UPROPERTY() USkeletalMesh* Lower_Default;
	UPROPERTY() USkeletalMesh* Hand_Default;
	UPROPERTY() USkeletalMesh* Shoes_Default;
	UPROPERTY() USkeletalMesh* Cape_Default;

	UFUNCTION() void UpdateMeshCapture(EEquipmentType EquipmentType, FName AttachBoneName, UStaticMesh* Mesh, USkeletalMesh* SKMesh);
	FORCEINLINE USkeletalMeshComponent* GetMesh() { return MainMesh; }
};
