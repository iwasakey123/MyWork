// Fill out your copyright notice in the Description page of Project Settings.


#include "MeshCaptureActor.h"
#include "Engine/SkeletalMesh.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Materials/Material.h"
#include "Animation/AnimSequence.h"

AMeshCaptureActor::AMeshCaptureActor()
{
	//PrimaryActorTick.bCanEverTick = true;
	
	MainMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("MainMesh_MeshCapture"));
	MainMesh->SetupAttachment(GetRootComponent());
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/Humanoid/Kilsu/Mesh/SK_Mannequin_Kilsu.SK_Mannequin_Kilsu'"));
	if (Mannequin.Succeeded())
	{
		MainMesh->SetSkeletalMesh(Mannequin.Object);
		MainMesh->SetAnimationMode(EAnimationMode::AnimationSingleNode);		
	}
	static ConstructorHelpers::FObjectFinder<UAnimSequence>IdleAnimOb(TEXT("AnimSequence'/Game/Resource_DynamicAnimation/Unarmed/U_Idle.U_Idle'"));
	if (IdleAnimOb.Succeeded())
		IdleAnim = IdleAnimOb.Object;
	
	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm_MeshCapture"));
	SpringArm->SetupAttachment(MainMesh);
	SpringArm->SetWorldLocationAndRotation(FVector(0.f, 0.f, 90.f), FRotator(0.f, -90.f, 0.f));

	SceneCaptureComp = CreateDefaultSubobject<USceneCaptureComponent2D>(TEXT("SceneCaptureComp2D_MeshCapture"));
	SceneCaptureComp->SetupAttachment(SpringArm);
	SceneCaptureComp->FOVAngle = 43.f;
	
	static ConstructorHelpers::FObjectFinder<UTextureRenderTarget2D>PlayerRenderTargetOb(TEXT("TextureRenderTarget2D'/Game/BP/Data/MeshRenderCapture/PlayerRenderTarget_Test.PlayerRenderTarget_Test'"));
	if (PlayerRenderTargetOb.Succeeded())
		SceneCaptureComp->TextureTarget = PlayerRenderTargetOb.Object;	

	BackGround = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BackGround_MeshCapture"));
	BackGround->SetupAttachment(MainMesh);
	BackGround->SetRelativeLocation(FVector(30.f, -400.f, -470.f));
	BackGround->SetWorldScale3D(FVector(10.f, 1.f, 10.f));
	static ConstructorHelpers::FObjectFinder<UStaticMesh>BackGroundMesh(TEXT("StaticMesh'/Game/StarterContent/Shapes/Shape_Cube.Shape_Cube'"));
	if (BackGroundMesh.Succeeded())
		BackGround->SetStaticMesh(BackGroundMesh.Object);
	static ConstructorHelpers::FObjectFinder<UMaterial>BackGroundMat(TEXT("Material'/Engine/MapTemplates/Sky/M_BlackBackground.M_BlackBackground'"));
	if (BackGroundMat.Succeeded())
		BackGround->SetMaterial(0, BackGroundMat.Object);
	
	MainWeapon = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MainWeapon_MeshCapture"));
	SubWeapon = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("SubWeapon_MeshCapture"));

	//Hair = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Hair"));	
	//Hair->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), FName("HAIR"));
	//Hair->SetMasterPoseComponent(GetMesh());
	//Hair->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);
	Head = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Head_MeshCapture"));
	Head->SetupAttachment(GetMesh(), FName("HAIR"));	
	//Head->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), FName("HAIR"));

	Upper = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Upper_MeshCapture"));
	Upper->SetupAttachment(GetMesh());
	//Upper->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	Upper->SetMasterPoseComponent(GetMesh());

	Lower = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Lower_MeshCapture"));
	Lower->SetupAttachment(GetMesh());
	//Lower->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	Lower->SetMasterPoseComponent(GetMesh());

	Hand = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Hand_MeshCapture"));
	Hand->SetupAttachment(GetMesh());
	//Hand->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	Hand->SetMasterPoseComponent(GetMesh());

	Shoes = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Shoes_MeshCapture"));
	Shoes->SetupAttachment(GetMesh());
	//Shoes->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	Shoes->SetMasterPoseComponent(GetMesh());

	Cape = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Cape_MeshCapture"));
	Cape->SetupAttachment(GetMesh());
	//Cape->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	Cape->SetMasterPoseComponent(GetMesh());
}

void AMeshCaptureActor::BeginPlay()
{
	Super::BeginPlay();
	if (IdleAnim)
		MainMesh->PlayAnimation(IdleAnim, true);
}

void AMeshCaptureActor::UpdateMeshCapture(EEquipmentType EquipmentType, FName AttachBoneName, UStaticMesh* Mesh, USkeletalMesh* SKMesh)
{
	UStaticMeshComponent* localMeshComp = nullptr;
	USkeletalMeshComponent* localSK = nullptr;

	switch (EquipmentType)
	{
	case EEquipmentType::MainWeapon:
		MainWeapon->SetStaticMesh(Mesh);
		localMeshComp = MainWeapon;
		break;
	case EEquipmentType::SubWeapon:
		SubWeapon->SetStaticMesh(Mesh);
		localMeshComp = SubWeapon;
		break;
	case EEquipmentType::Head:
		//if (SKMesh != nullptr)
		//	Hair->SetSkeletalMesh(Hair_EquipHead);
		//else if (SKMesh == nullptr)
		//	Hair->SetSkeletalMesh(Hair_NoEquip);
		Head->SetSkeletalMesh(SKMesh);
		localSK = Head;
		break;
	case EEquipmentType::Hand:
		Hand->SetSkeletalMesh(SKMesh);
		localSK = Hand;
		break;
	case EEquipmentType::Shoes:
		Shoes->SetSkeletalMesh(SKMesh);
		localSK = Shoes;
		break;
	case EEquipmentType::Upper:
		Upper->SetSkeletalMesh(SKMesh);
		localSK = Upper;
		break;
	case EEquipmentType::Lower:
		Lower->SetSkeletalMesh(SKMesh);
		localSK = Lower;
		break;
	case EEquipmentType::Cape:
		Cape->SetSkeletalMesh(SKMesh);
		localSK = Cape;
		break;
	default:
		localMeshComp = nullptr;
		localSK = nullptr;
		break;
	}
	
	if (Mesh)
		localMeshComp->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), AttachBoneName);
	else if (SKMesh && EquipmentType == EEquipmentType::Head)
		localSK->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), FName("HAIR"));

	if ((EquipmentType != EEquipmentType::MainWeapon && EquipmentType != EEquipmentType::SubWeapon && Mesh == nullptr && SKMesh == nullptr))
	{		
		if (EquipmentType == EEquipmentType::Head && Head_Default != nullptr)
			Head->SetSkeletalMesh(Head_Default);
		else if (EquipmentType == EEquipmentType::Upper && Upper_Default != nullptr)
			Upper->SetSkeletalMesh(Upper_Default);
		else if (EquipmentType == EEquipmentType::Lower && Lower_Default != nullptr)
			Lower->SetSkeletalMesh(Lower_Default);
		else if (EquipmentType == EEquipmentType::Hand && Hand_Default != nullptr)
			Hand->SetSkeletalMesh(Hand_Default);
		else if (EquipmentType == EEquipmentType::Shoes && Shoes_Default != nullptr)
			Shoes->SetSkeletalMesh(Shoes_Default);
		else if (EquipmentType == EEquipmentType::Cape && Cape_Default != nullptr)
			Cape->SetSkeletalMesh(Cape_Default);
	}
}

