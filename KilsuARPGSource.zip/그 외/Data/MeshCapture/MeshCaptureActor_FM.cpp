// Fill out your copyright notice in the Description page of Project Settings.


#include "MeshCaptureActor_FM.h"

AMeshCaptureActor_FM::AMeshCaptureActor_FM()
{
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Heads/SK_HeadA.SK_HeadA'"));
	if (Mannequin.Succeeded())
	{
		MainMesh->SetSkeletalMesh(Mannequin.Object);
		MainMesh->SetAnimationMode(EAnimationMode::AnimationSingleNode);
	}
	static ConstructorHelpers::FObjectFinder<UAnimSequence>IdleAnimOb(TEXT("AnimSequence'/Game/Model/GhostLady_S2/Animations/In-Place/MoveBasic/Anim_Idle.Anim_Idle'"));
	if (IdleAnimOb.Succeeded())
		IdleAnim = IdleAnimOb.Object;

	//custom
	//Hair_NoEquip
	//static ConstructorHelpers::FObjectFinder<USkeletalMesh>HairOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Hairs/SK_LongHair.SK_LongHair'"));
	//if (HairOb.Succeeded())
	//{
	//	Hair_NoEquip = HairOb.Object;
	//	Hair->SetSkeletalMesh(HairOb.Object);
	//	Hair->SetMasterPoseComponent(GetMesh());
	//}
	////Hair_HeadEquip
	//static ConstructorHelpers::FObjectFinder<USkeletalMesh>Hair_HeadEquipOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Hairs/SK_LongHair4Helmet.SK_LongHair4Helmet'"));
	//if (Hair_HeadEquipOb.Succeeded())
	//	Hair_EquipHead = Hair_HeadEquipOb.Object;
	//Upper_Default
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Upper_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/TopBodies/SK_TopBody_A.SK_TopBody_A'"));
	if (Upper_DefaultOb.Succeeded())
		Upper_Default = Upper_DefaultOb.Object;
	//Lower_Default
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Lower_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/BotBodies/SK_BotBody_A.SK_BotBody_A'"));
	if (Lower_DefaultOb.Succeeded())
		Lower_Default = Lower_DefaultOb.Object;
	//Hand_Default
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Hand_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Gauntlets/SK_HandsMerge.SK_HandsMerge'"));
	if (Hand_DefaultOb.Succeeded())
		Hand_Default = Hand_DefaultOb.Object;
	//Shoes_Default
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Shoes_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Shoes/SK_Feet.SK_Feet'"));
	if (Shoes_DefaultOb.Succeeded())
		Shoes_Default = Shoes_DefaultOb.Object;
}

void AMeshCaptureActor_FM::BeginPlay()
{
	Super::BeginPlay();

	//Head->SetSkeletalMesh(Head_Default);
	Upper->SetSkeletalMesh(Upper_Default);
	Lower->SetSkeletalMesh(Lower_Default);
	Hand->SetSkeletalMesh(Hand_Default);
	Shoes->SetSkeletalMesh(Shoes_Default);
	//Cape->SetSkeletalMesh(Cape_Default);
}