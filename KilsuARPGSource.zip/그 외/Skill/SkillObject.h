// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "KilsuARPG/Data/Struct/FSkill.h"
#include "SkillObject.generated.h"

UCLASS()
class KILSUARPG_API ASkillObject : public AActor
{
	GENERATED_BODY()
	
public:
	ASkillObject();
	UPROPERTY(EditAnywhere) FSkillInfo SkillInfo;
	virtual void UseSkill();
};
