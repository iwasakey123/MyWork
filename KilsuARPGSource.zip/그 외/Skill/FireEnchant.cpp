// Fill out your copyright notice in the Description page of Project Settings.


#include "FireEnchant.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"

AFireEnchant::AFireEnchant()
{
	SkillInfo.SkillName = FName("FireEnchant");
	SkillInfo.Description = "SkillDescription";
	SkillInfo.Cooldown = 1.f;
	SkillInfo.SkillType = ESkillType::MeleeActive;

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/VFX/Cascade/GrenadePack/Textures/Fire_Aspect.Fire_Aspect'"));
	if (IconOb.Succeeded())
		SkillInfo.Icon = IconOb.Object;
	static ConstructorHelpers::FObjectFinder<UAnimMontage>SkillMontageOb(TEXT("AnimMontage'/Game/BP/Montages/FM/FM_Enhance.FM_Enhance'"));
	if (SkillMontageOb.Succeeded())
		SkillInfo.SkillMontage = SkillMontageOb.Object;
}

void AFireEnchant::UseSkill()
{
	auto CharacterRef = Cast<ACharacter>(GetOwner());
	auto EquipmentComp = GetOwner()->FindComponentByClass<UEquipmentComponent>();

	if (CharacterRef && CharacterRef->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) && EquipmentComp && EquipmentComp->GetCurrentWeapon()) 
		if (IStateInterface::Execute_IsCombat(CharacterRef))
		{
			CharacterRef->PlayAnimMontage(SkillInfo.SkillMontage, EquipmentComp->GetAttackSpeed());
		}	
	Destroy();
}
