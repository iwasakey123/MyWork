// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Skill/SkillObject.h"
#include "FireEnchant.generated.h"

UCLASS()
class KILSUARPG_API AFireEnchant : public ASkillObject
{
	GENERATED_BODY()
	
public:
	AFireEnchant();

	virtual void UseSkill() override;
};
