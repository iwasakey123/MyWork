// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "FireBall.generated.h"

UCLASS()
class KILSUARPG_API AFireBall : public AActor
{
	GENERATED_BODY()
	
public:	
	AFireBall();

	virtual void Tick(float DeltaTime) override;

	UFUNCTION() void AttackHit(FHitResult Hit);
	UFUNCTION() void CollisionActivated(ECollisionParts CollisionType);

protected:
	virtual void BeginPlay() override;

	UPROPERTY() class UProjectileMovementComponent* ProjectileMovement;
	UPROPERTY() class UMeleeCombatComponent* CombatComp;

	UPROPERTY() UStaticMeshComponent* CollisionSphere;
	UPROPERTY() class UParticleSystemComponent* EffectComp;

	UPROPERTY() bool bUpdateHomingProjectile;
	UPROPERTY() AActor* HomingTarget;
};
