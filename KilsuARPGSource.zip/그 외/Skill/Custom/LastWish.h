// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "LastWish.generated.h"

UCLASS()
class KILSUARPG_API ALastWish : public AActor
{
	GENERATED_BODY()
public:	
	ALastWish();

protected:
	virtual void BeginPlay() override;

public:	
	UFUNCTION() void AttackHit(FHitResult Hit);
	UFUNCTION() void CollisionActivated(ECollisionParts CollisionType);
	UFUNCTION() void EnableHoming();
	UFUNCTION() void DisableHoming();
	UFUNCTION() void UpdatingHomingProjectile();

private:
	UPROPERTY() UStaticMeshComponent* CollisionSphere;
	UPROPERTY() class UParticleSystemComponent* ParticleComp;
	UPROPERTY() class UProjectileMovementComponent* ProjectileMovement;
	UPROPERTY() class UMeleeCombatComponent* CombatComp;

	UPROPERTY() FTimerHandle handle;
	UPROPERTY() AActor* HomingTarget;
};
