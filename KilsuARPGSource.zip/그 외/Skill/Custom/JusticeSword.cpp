// Fill out your copyright notice in the Description page of Project Settings.


#include "JusticeSword.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "Gameframework/Character.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "Perception/AISenseConfig_Damage.h"

AJusticeSword::AJusticeSword()
{
	//PrimaryActorTick.bCanEverTick = true;
	InitialLifeSpan = 1.0f;

	CollisionSphere = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CollisionSphere_JS"));
	SetRootComponent(CollisionSphere);
	CombatComp = CreateDefaultSubobject<UMeleeCombatComponent>(TEXT("CombatComp_JS"));


	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/Reource_AddNew/MagicModule/Meshes/SM_CollisionSphere.SM_CollisionSphere'"));
	if (MeshOb.Succeeded())
		CollisionSphere->SetStaticMesh(MeshOb.Object);
}

void AJusticeSword::BeginPlay()
{
	Super::BeginPlay();
	CombatComp->AttackHit.AddUFunction(this, FName("AttackHit"));
	CombatComp->MeleeCollisionActivate.AddUFunction(this, FName("CollisionActivated"));
	FDamage Damage;
	CombatComp->ActivateCollision(ECollisionParts::Weapon, 400.f, Damage);
}

void  AJusticeSword::CollisionActivated(ECollisionParts CollisionType)
{
	switch (CollisionType)
	{
	case ECollisionParts::Weapon:
		CombatComp->SetCollisionComponent(CollisionSphere, CollisionSphere->GetAllSocketNames());
		break;
	}
}

void  AJusticeSword::AttackHit(FHitResult Hit)
{
	if (IsValid(Hit.Actor.Get()) && Hit.Actor.Get() != GetOwner() && Hit.Actor.Get() != this)
	{
		//IsEnemy
		if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true && ICombatInterface::Execute_CheckEnemy(GetOwner(), ICombatInterface::Execute_GetTag(Hit.Actor.Get())))
		{
			//IsAlive and NoImmotal
			if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(Hit.Actor.Get()) && IStateInterface::Execute_IsImmotal(Hit.Actor.Get()) == false)
			{
				auto StatsComp = GetOwner()->FindComponentByClass<UStatsComponent>();
				//auto Damage = (StatsComp == nullptr || CombatComp->GetCustomDamage().bSetCustom) ? CombatComp->GetCustomDamage() : StatsComp->MakeDamage(EDamageType::Heavy);
				auto Damage = StatsComp->MakeDamage(EDamageType::Heavy);
				Damage.bCanGuard = false;
				Damage.bCanParry = false;
				ICombatInterface::Execute_TakeDamaged(Hit.Actor.Get(), Damage, GetOwner());
				UAISense_Damage::ReportDamageEvent(GetWorld(), Hit.Actor.Get(), GetOwner(), Damage.Damage, Hit.Location, Hit.Location);	
				Destroy();
			}
		}
	}
}