// Fill out your copyright notice in the Description page of Project Settings.


#include "MassacreFire.h"
#include "Particles/ParticleSystemComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "Perception/AISenseConfig_Damage.h"

AMassacreFire::AMassacreFire()
{
	PrimaryActorTick.bCanEverTick = true;
	CollisionSphere = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CollisionSphere_MassacreFire"));
	SetRootComponent(CollisionSphere);
	CollisionSphere->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	CollisionSphere->bHiddenInGame = true;	

	MassacreParticle = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("Particle_MassacreFire"));
	MassacreParticle->SetupAttachment(CollisionSphere);
	MassacreParticle->SetRelativeScale3D(FVector(0.55f));

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/Reource_AddNew/MagicModule/Meshes/SM_CollisionSphere.SM_CollisionSphere'"));
	if (MeshOb.Succeeded())
		CollisionSphere->SetStaticMesh(MeshOb.Object);

	static ConstructorHelpers::FObjectFinder<UParticleSystem>ParticleOb(TEXT("ParticleSystem'/Game/VFX/Cascade/ParagonGideon/FX/Particles/Gideon/Abilities/Burden/FX/SwordBack.SwordBack'"));
	if (ParticleOb.Succeeded())
		MassacreParticle->SetTemplate(ParticleOb.Object);

	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement_MassacreFire"));
	ProjectileMovement->InitialSpeed = 0.f;
	ProjectileMovement->MaxSpeed = 2500.f;
	ProjectileMovement->bRotationFollowsVelocity = true;
	ProjectileMovement->bRotationRemainsVertical = false;
	ProjectileMovement->bInitialVelocityInLocalSpace = true;
	ProjectileMovement->ProjectileGravityScale = 0.f;
	ProjectileMovement->Velocity = FVector(1.f, 0.f, 0.f);

	CombatComp = CreateDefaultSubobject<UMeleeCombatComponent>(TEXT("CombatComp_MassacreFire"));
	InitialLifeSpan = 10.f;
}

void AMassacreFire::BeginPlay()
{
	Super::BeginPlay();
	CombatComp->AttackHit.AddUFunction(this, FName("AttackHit"));
	CombatComp->MeleeCollisionActivate.AddUFunction(this, FName("CollisionActivated"));

	ProjectileMovement->Velocity = GetActorForwardVector() * 2000.f;

	auto EC = Cast<AEnemyController>(Cast<ACharacter>(GetOwner())->GetController());
	if (EC && EC->Target)
	{
		HomingTarget = EC->Target;
	}
	//EnableHoming();
	bUpdateHomingProjectile = true;
	FDamage Damage;
	Damage.bSetCustom = true;
	Damage.bCanGuard = true;
	Damage.bCanParry = false;	
	Damage.DamageType = EDamageType::CustomDamage;	
	Damage.Damage = UKismetMathLibrary::RandomFloatInRange(10.f, 20.f) + 105.f;
	CombatComp->ActivateCollision(ECollisionParts::Weapon, 15.f, Damage);
	
}

void AMassacreFire::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
	if (bUpdateHomingProjectile)
	{		
		if (HomingTarget)
		{
			float Distance = GetDistanceTo(HomingTarget);

			FVector TargetVec = HomingTarget->GetActorLocation() + (HomingTarget->GetVelocity() * (Distance / 2000.f));
			FRotator TargetRot = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), TargetVec);
			FRotator InterpRot = (UKismetMathLibrary::RInterpTo_Constant(GetActorRotation(), TargetRot, UGameplayStatics::GetWorldDeltaSeconds(GetWorld()), 80.f));
		
			ProjectileMovement->Velocity = InterpRot.Vector() * 2000.f;
		}
		else
		{
			bUpdateHomingProjectile = false;
			return;
		}
	}
}

void AMassacreFire::CollisionActivated(ECollisionParts CollisionType)
{
	switch (CollisionType)
	{
	case ECollisionParts::Weapon:
		CombatComp->SetCollisionComponent(CollisionSphere, CollisionSphere->GetAllSocketNames());
		break;
	}
}

void AMassacreFire::AttackHit(FHitResult Hit)
{
	if (IsValid(Hit.Actor.Get()) && Hit.Actor.Get() != GetOwner() && Hit.Actor.Get() != this)
	{
		//IsEnemy
		if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true && ICombatInterface::Execute_CheckEnemy(GetOwner(), ICombatInterface::Execute_GetTag(Hit.Actor.Get())))
		{
			//IsAlive and NoImmotal
			if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(Hit.Actor.Get()) && IStateInterface::Execute_IsImmotal(Hit.Actor.Get()) == false)
			{
				auto StatsComp = GetOwner()->FindComponentByClass<UStatsComponent>();
				auto Damage = (StatsComp == nullptr || CombatComp->GetCustomDamage().bSetCustom) ? CombatComp->GetCustomDamage() : StatsComp->MakeDamage(EDamageType::CustomDamage);
				ICombatInterface::Execute_TakeDamaged(Hit.Actor.Get(), Damage, GetOwner());
				UAISense_Damage::ReportDamageEvent(GetWorld(), Hit.Actor.Get(), GetOwner(), Damage.Damage, Hit.Location, Hit.Location);
				auto Soundsorce = LoadObject<USoundBase>(nullptr, TEXT("SoundCue'/Game/SFX/CUE/CUE_FireballHit.CUE_FireballHit'"));
				auto HitEffect = LoadObject<UParticleSystem>(nullptr, TEXT("ParticleSystem'/Game/VFX/MagicModule_VFX/P_FireballHit.P_FireballHit'"));
				UGameplayStatics::PlaySoundAtLocation(GetWorld(), Soundsorce, Hit.Location);
				FTransform Tr;
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), HitEffect, Tr);
				Destroy();
			}
		}
	}
}
