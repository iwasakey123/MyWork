// Fill out your copyright notice in the Description page of Project Settings.


#include "LastWish.h"
#include "Particles/ParticleSystemComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "GameFramework/Character.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "Perception/AISenseConfig_Damage.h"

ALastWish::ALastWish()
{
	//PrimaryActorTick.bCanEverTick = true;
	CollisionSphere = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CollisionSphere"));
	SetRootComponent(CollisionSphere);

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/Reource_AddNew/MagicModule/Meshes/SM_CollisionSphere.SM_CollisionSphere'"));
	if (MeshOb.Succeeded())
	{
		CollisionSphere->SetStaticMesh(MeshOb.Object);
		CollisionSphere->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		CollisionSphere->bHiddenInGame = false;
	}
	
	ParticleComp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleComp_LastWish"));
	ParticleComp->SetupAttachment(GetRootComponent());
	ParticleComp->SetWorldScale3D(FVector(2.5f));

	static ConstructorHelpers::FObjectFinder<UParticleSystem>ParticleOb(TEXT("ParticleSystem'/Game/VFX/Cascade/ParagonGideon/FX/Particles/Gideon/Abilities/Burden/FX/SwordBack.SwordBack'"));
	if (ParticleOb.Succeeded())
		ParticleComp->SetTemplate(ParticleOb.Object);

	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement_LastWish"));
	ProjectileMovement->InitialSpeed = 7000.f;
	ProjectileMovement->MaxSpeed = 7000.f;
	ProjectileMovement->bRotationFollowsVelocity = true;
	ProjectileMovement->bRotationRemainsVertical = false;
	ProjectileMovement->bInitialVelocityInLocalSpace = true;
	ProjectileMovement->ProjectileGravityScale = 0.f;
	ProjectileMovement->Velocity = FVector(1.f, 0.f, 0.f);

	CombatComp = CreateDefaultSubobject<UMeleeCombatComponent>(TEXT("CombatComp_LastWish"));
	//CombatComp->SetTraceSize(15.f);
	InitialLifeSpan = 10.f;
}

void ALastWish::BeginPlay()
{
	Super::BeginPlay();	
	CombatComp->AttackHit.AddUFunction(this, FName("AttackHit"));
	CombatComp->MeleeCollisionActivate.AddUFunction(this, FName("CollisionActivated"));

	ProjectileMovement->Velocity = GetOwner()->GetActorForwardVector() * 7000.f;
	auto EC = Cast<AEnemyController>(Cast<ACharacter>(GetOwner())->GetController());
	if (EC && EC->Target)
	{
		HomingTarget = EC->Target;
	}
	//EnableHoming();
	FDamage Damage;
	Damage.bSetCustom = true;
	Damage.Damage = 255.f;
	Damage.DamageType = EDamageType::Heavy;
	Damage.bCanGuard = true;
	Damage.bCanParry = false;
	CombatComp->ActivateCollision(ECollisionParts::Weapon, 255.f, Damage);
}

void ALastWish::CollisionActivated(ECollisionParts CollisionType)
{
	switch (CollisionType)
	{
	case ECollisionParts::Weapon:	
		CombatComp->SetCollisionComponent(CollisionSphere, CollisionSphere->GetAllSocketNames());
		break;
	}
}

void ALastWish::AttackHit(FHitResult Hit)
{
	if (IsValid(Hit.Actor.Get()) && Hit.Actor.Get() != GetOwner() && Hit.Actor.Get() != this)
	{
		//IsEnemy
		if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true && ICombatInterface::Execute_CheckEnemy(GetOwner(), ICombatInterface::Execute_GetTag(Hit.Actor.Get())))
		{
			//IsAlive and NoImmotal
			if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(Hit.Actor.Get()) && IStateInterface::Execute_IsImmotal(Hit.Actor.Get()) == false)
			{
				auto StatsComp = GetOwner()->FindComponentByClass<UStatsComponent>();					
				auto Damage = (StatsComp == nullptr || CombatComp->GetCustomDamage().bSetCustom) ? CombatComp->GetCustomDamage() : StatsComp->MakeDamage(EDamageType::Heavy);
				ICombatInterface::Execute_TakeDamaged(Hit.Actor.Get(), Damage, GetOwner());
				UAISense_Damage::ReportDamageEvent(GetWorld(), Hit.Actor.Get(), GetOwner(), Damage.Damage, Hit.Location, Hit.Location);
				auto Soundsorce = LoadObject<USoundBase>(nullptr, TEXT("SoundCue'/Game/SFX/CUE/CUE_FireballHit.CUE_FireballHit'"));
				auto HitEffect = LoadObject<UParticleSystem>(nullptr, TEXT("ParticleSystem'/Game/VFX/MagicModule_VFX/P_FireballHit.P_FireballHit'"));
				UGameplayStatics::PlaySoundAtLocation(GetWorld(), Soundsorce, Hit.Location);
				FTransform Tr;
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), HitEffect, Tr);
				Destroy();
			}
		}
	}
}

void ALastWish::EnableHoming()
{	
	if (HomingTarget)
	{
		FTimerDelegate TimerDel;
		TimerDel.BindUFunction(this, FName("UpdatingHomingProjectile"));
		GetWorld()->GetTimerManager().SetTimer(handle, TimerDel, 0.016f, true);
	}
}

void ALastWish::DisableHoming()
{
	GetWorld()->GetTimerManager().ClearTimer(handle);	
}

void ALastWish::UpdatingHomingProjectile()
{
	if (HomingTarget == nullptr) 
		DisableHoming();

	float Distance = (HomingTarget->GetActorLocation() - GetActorLocation()).Size();
	if (Distance <= 300.f)
	{
		DisableHoming();
	}
	else
	{
		auto Rot = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), HomingTarget->GetActorLocation() + HomingTarget->GetVelocity() * (Distance / 7000.f));
		auto RotVector = UKismetMathLibrary::RInterpTo_Constant(GetActorRotation(), Rot, UGameplayStatics::GetWorldDeltaSeconds(GetWorld()), 1500.f).Vector();
		ProjectileMovement->Velocity = RotVector * 7000.f;
	}
}

