// Fill out your copyright notice in the Description page of Project Settings.


#include "FireBall.h"
#include "Particles/ParticleSystemComponent.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "Kismet/GameplayStatics.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "Perception/AISenseConfig_Damage.h"
#include "Kismet/KismetMathLibrary.h"

AFireBall::AFireBall()
{
	//PrimaryActorTick.bCanEverTick = true;
	InitialLifeSpan = 10.f;

	CollisionSphere = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CollisionSphere_FireBall"));
	SetRootComponent(CollisionSphere);
	CollisionSphere->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	CollisionSphere->bHiddenInGame = true;
	EffectComp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("EffectComp_FireBall"));
	EffectComp->SetupAttachment(CollisionSphere);
	EffectComp->SetWorldScale3D(FVector(1.5, 2.f, 2.f));

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/Reource_AddNew/MagicModule/Meshes/SM_CollisionSphere.SM_CollisionSphere'"));
	if (MeshOb.Succeeded())
		CollisionSphere->SetStaticMesh(MeshOb.Object);

	static ConstructorHelpers::FObjectFinder<UParticleSystem>EffectOb(TEXT("ParticleSystem'/Game/VFX/MagicModule_VFX/P_Fireball.P_Fireball'"));
	if (EffectOb.Succeeded())
		EffectComp->SetTemplate(EffectOb.Object);

	CombatComp = CreateDefaultSubobject<UMeleeCombatComponent>(TEXT("CombatComp_FireBall"));
	
	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement_FireBall"));
	ProjectileMovement->MaxSpeed = 2000.f;
	ProjectileMovement->bRotationFollowsVelocity = true;
	ProjectileMovement->ProjectileGravityScale = 0.f;
}

void AFireBall::BeginPlay()
{
	Super::BeginPlay();
	CombatComp->AttackHit.AddUFunction(this, FName("AttackHit"));
	CombatComp->MeleeCollisionActivate.AddUFunction(this, FName("CollisionActivated"));

	ProjectileMovement->Velocity = GetActorForwardVector() * 1500.f;

	//auto EC = Cast<AEnemyController>(Cast<ACharacter>(GetOwner())->Controller);
	//if (EC && EC->Target)
	//	HomingTarget = EC->Target;
	//bUpdateHomingProjectile = true;

	FDamage Damage;
	CombatComp->ActivateCollision(ECollisionParts::Weapon, 180.f, Damage);	
}


void AFireBall::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//if (bUpdateHomingProjectile)
	//{
	//	if (HomingTarget)
	//	{
	//		float Distance = GetDistanceTo(HomingTarget);

	//		FVector TargetVec = HomingTarget->GetActorLocation() + (HomingTarget->GetVelocity() * (Distance / 2000.f));
	//		FRotator TargetRot = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), TargetVec);
	//		FRotator InterpRot = (UKismetMathLibrary::RInterpTo_Constant(GetActorRotation(), TargetRot, UGameplayStatics::GetWorldDeltaSeconds(GetWorld()), 80.f));

	//		ProjectileMovement->Velocity = InterpRot.Vector() * 2000.f;
	//	}
	//	else
	//	{
	//		bUpdateHomingProjectile = false;
	//		return;
	//	}
	//}
}

void AFireBall::CollisionActivated(ECollisionParts CollisionType)
{
	switch (CollisionType)
	{
	case ECollisionParts::Weapon:
		CombatComp->SetCollisionComponent(CollisionSphere, CollisionSphere->GetAllSocketNames());
		break;
	}
}
void AFireBall::AttackHit(FHitResult Hit)
{
	if (IsValid(Hit.Actor.Get()) && Hit.Actor.Get() != GetOwner() && Hit.Actor.Get() != this)
	{
		//IsEnemy
		if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true && ICombatInterface::Execute_CheckEnemy(GetOwner(), ICombatInterface::Execute_GetTag(Hit.Actor.Get())))
		{
			//IsAlive and NoImmotal
			if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(Hit.Actor.Get()) && IStateInterface::Execute_IsImmotal(Hit.Actor.Get()) == false)
			{
				auto StatsComp = GetOwner()->FindComponentByClass<UStatsComponent>();
				auto Damage = (StatsComp == nullptr || CombatComp->GetCustomDamage().bSetCustom) ? CombatComp->GetCustomDamage() : StatsComp->MakeDamage(EDamageType::Normal);
				ICombatInterface::Execute_TakeDamaged(Hit.Actor.Get(), Damage, GetOwner());
				UAISense_Damage::ReportDamageEvent(GetWorld(), Hit.Actor.Get(), GetOwner(), Damage.Damage, Hit.Location, Hit.Location);
				auto Soundsorce = LoadObject<USoundBase>(nullptr, TEXT("SoundCue'/Game/SFX/CUE/CUE_FireballHit.CUE_FireballHit'"));
				auto HitEffect = LoadObject<UParticleSystem>(nullptr, TEXT("ParticleSystem'/Game/VFX/MagicModule_VFX/P_FireballHit.P_FireballHit'"));
				UGameplayStatics::PlaySoundAtLocation(GetWorld(), Soundsorce, Hit.Location);
				FTransform Tr;
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), HitEffect, Tr);
				Destroy();
			}
		}
	}
}

