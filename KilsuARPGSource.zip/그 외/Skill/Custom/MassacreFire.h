// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "MassacreFire.generated.h"

UCLASS()
class KILSUARPG_API AMassacreFire : public AActor
{
	GENERATED_BODY()

public:	

	AMassacreFire();

protected:
	virtual void BeginPlay() override;
	
	UPROPERTY() UStaticMeshComponent* CollisionSphere;
	UPROPERTY() class UParticleSystemComponent* MassacreParticle;
	UPROPERTY() class UProjectileMovementComponent* ProjectileMovement;
	UPROPERTY() class UMeleeCombatComponent* CombatComp;

	//UPROPERTY() FTimerHandle handle;
	UPROPERTY() AActor* HomingTarget;

	UPROPERTY() bool bUpdateHomingProjectile;

public:
	virtual void Tick(float DeltaTime) override;

	UFUNCTION() void AttackHit(FHitResult Hit);
	UFUNCTION() void CollisionActivated(ECollisionParts CollisionType);
};
