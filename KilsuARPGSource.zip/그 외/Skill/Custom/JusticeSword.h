// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "JusticeSword.generated.h"

UCLASS()
class KILSUARPG_API AJusticeSword : public AActor
{
	GENERATED_BODY()
	
public:	
	AJusticeSword();

	UFUNCTION() void AttackHit(FHitResult Hit);
	UFUNCTION() void CollisionActivated(ECollisionParts CollisionType);

protected:
	virtual void BeginPlay() override;

	UPROPERTY() class UMeleeCombatComponent* CombatComp;
	UPROPERTY() UStaticMeshComponent* CollisionSphere;
};
