// Fill out your copyright notice in the Description page of Project Settings.


#include "Boss_Reaper.h"
#include "Particles/ParticleSystemComponent.h"
#include "Components/CapsuleComponent.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Components/ArrowComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Perception/AISenseConfig_Damage.h"
//Boss Weapon
#include "KilsuARPG/Item/Weapon/Scythe/Scythe.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Components/MontageComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"
//BossSkill
#include "KilsuARPG/Skill/Custom/LastWish.h"
#include "KilsuARPG/Skill/Custom/MassacreFire.h"
#include "kilsuARPG/Skill/Custom/JusticeSword.h"
#include "KilsuARPG/Skill/Custom/FireBall.h"

ABoss_Reaper::ABoss_Reaper()
{
	AIType = EAIType::Boss;
	AIName = FName("Reaper");
	AITag = FName("Boss");
	AISize = ETargetSize::Big;

	//Stat Setting
	StatsComp->HP.Max = 7000.f;
	StatsComp->HP.Current = 7000;	
	StatsComp->Stamina.Max = 100.f;
	StatsComp->Stamina.Current = 100;
	StatsComp->MP.Current = 6000.f;
	StatsComp->MP.Max = 6000.f;
	StatsComp->ATT.Current = 176.f;
	StatsComp->MTT.Current = 60.f;
	StatsComp->CritChance = 10.f;
	StatsComp->CritDamage = 200.f;

	MontageComp->SetMontageID(FName("Reaper"));

	EnemySense.SightRadius = 1800.f;
	EnemySense.LoseSightRadius = 5500.f;
	EnemySense.SightMaxAge = 200.f;
	EnemySense.PeripheralVisionAngleDegrees = 70.f;
	EnemySense.DamageMaxAge = 200.f;

	//����ü �̻��ϵ��� �����ϱ����� �ʱ�ȭ�۾�
	FString MassacrePosStr = TEXT("MassacrePos");
	MassacrePos.SetNum(19);
	for (int32 i = 0; i < MassacrePos.Num(); i++)
	{
		MassacrePos[i] = CreateDefaultSubobject<UArrowComponent>(FName(*(MassacrePosStr + FString::FromInt(i))));
		MassacrePos[i]->SetupAttachment(GetRootComponent());
	}
	MassacrePos[0]->SetRelativeLocationAndRotation(FVector(-252.f, 143.f, 208.f), FRotator(-10.f, 15.f, 0.f));
	MassacrePos[1]->SetRelativeLocationAndRotation(FVector(-254.f, 354.f, 206.f), FRotator(-10.f, 10.f, 1.f));
	MassacrePos[2]->SetRelativeLocationAndRotation(FVector(-276.f, 552.f, 204.f), FRotator(-10.f, 15.f, 1.7f));
	MassacrePos[3]->SetRelativeLocationAndRotation(FVector(-267.f, 544.f, 358.f), FRotator(0.f, 15.f, 0.86f));
	MassacrePos[4]->SetRelativeLocationAndRotation(FVector(-243.f, 346.f, 372.f), FRotator(0.f, 10.f, 0.f));
	MassacrePos[5]->SetRelativeLocationAndRotation(FVector(-243.f, 147.f, 370.f), FRotator(0.f, 15.f, 0.f));
	MassacrePos[6]->SetRelativeLocationAndRotation(FVector(-261.f, 140.f, 573.f), FRotator(10.f, 15.f, 0.f));
	MassacrePos[7]->SetRelativeLocationAndRotation(FVector(-263.f, 361.f, 551.f), FRotator(10.f, 10.f, 0.f));
	MassacrePos[8]->SetRelativeLocationAndRotation(FVector(-275.f, 547.f, 505.f), FRotator(10.f, 15.f, 1.f));
	MassacrePos[9]->SetRelativeLocationAndRotation(FVector(-273.f, -520.f, 206.f), FRotator(-10.f, -20.f, 1.f));
	MassacrePos[10]->SetRelativeLocationAndRotation(FVector(-243.f, -343.f, 207.f), FRotator(-10.f, -10.f, -1.f));
	MassacrePos[11]->SetRelativeLocationAndRotation(FVector(-246.5f, -164.f, 207.f), FRotator(-10.f, -15.f, 0.f));
	MassacrePos[12]->SetRelativeLocationAndRotation(FVector(-234.f, -147.f, 366.f), FRotator(0.f, -15.f, 0.f));
	MassacrePos[13]->SetRelativeLocationAndRotation(FVector(-234.f, -333.f, 365.f), FRotator(0.f, -10.f, 0.f));
	MassacrePos[14]->SetRelativeLocationAndRotation(FVector(-265.f, -527.f, 360.f), FRotator(0.f, -20.f, 0.f));
	MassacrePos[15]->SetRelativeLocationAndRotation(FVector(-265.f, -524.f, 505.f), FRotator(10.f, -20.f, -1.7f));
	MassacrePos[16]->SetRelativeLocationAndRotation(FVector(-250.f, -355.f, 551.f), FRotator(10.f, -10.f, 0.f));
	MassacrePos[17]->SetRelativeLocationAndRotation(FVector(-250.f, -152.f, 563.f), FRotator(9.f, -15.f, 5.f));
	MassacrePos[18]->SetRelativeLocationAndRotation(FVector(-227.f, -2.5f, 468.f), FRotator(10.f, 0.f, -3.f));

	Magic_RH_Name = FName("magic_right_hand");
	Magic_LH_Name = FName("magic_left_hand");

	//AI Mesh
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/Humanoid/TheReaper/Meshes/Characters/Combines/SK_ReaperB.SK_ReaperB'"));
	if (Mannequin.Succeeded())
		GetMesh()->SetSkeletalMesh(Mannequin.Object);
	GetMesh()->SetRelativeLocationAndRotation(FVector(0.f, 0.f, -90.f), FRotator(0.f, -90.f, 0.f));
	GetCapsuleComponent()->SetWorldScale3D(FVector(1.7f));
	GetCapsuleComponent()->SetCapsuleRadius(33.f);

	//BehaviorTree
	static ConstructorHelpers::FObjectFinder<UBehaviorTree>BossBehaviorTree(TEXT("BehaviorTree'/Game/BP/AI/BT/BT_MagicBossAI.BT_MagicBossAI'"));
	if (BossBehaviorTree.Succeeded())
		BehaviorTree = BossBehaviorTree.Object;

	//AnimBP
	static ConstructorHelpers::FObjectFinder<UClass>AnimBP(TEXT("AnimBlueprint'/Game/BP/AnimInstance/ABP_Reaper.ABP_Reaper_C'"));
	if (AnimBP.Succeeded())
		GetMesh()->SetAnimInstanceClass(AnimBP.Object);

	EyeTrailComp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("EyeTrailComp"));
	EyeTrailComp->SetupAttachment(GetMesh(), FName("Eye_l"));
	EyeTrailComp->SetWorldLocation(FVector(0.f, 2.353f, 0.f));
	EyeTrailComp->SetWorldScale3D(FVector(0.2f));
	//Eyetrail
	static ConstructorHelpers::FObjectFinder<UParticleSystem>RedEyeOb(TEXT("ParticleSystem'/Game/VFX/Cascade/VFX_Toolkit_V1/ParticleSystems/356Days/EyeBoss.EyeBoss'"));
	if (RedEyeOb.Succeeded())
	{
		RedEyeTrail = RedEyeOb.Object;
		EyeTrailComp->SetTemplate(RedEyeTrail);
	}
	MagicSwordEffect_1Comp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("SwordEffect_1Comp"));
	MagicSwordEffect_1Comp->SetupAttachment(GetMesh());
	MagicSwordEffect_1Comp->SetRelativeLocationAndRotation(FVector(74.f, 0.f, 114.f), FRotator(-90.f, 0.f, 0.f));
	MagicSwordEffect_1Comp->SetWorldScale3D(FVector(0.4f));
	
	MagicSwordEffect_2Comp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("SwordEffect_2Comp"));
	MagicSwordEffect_2Comp->SetupAttachment(GetMesh());
	MagicSwordEffect_2Comp->SetRelativeLocationAndRotation(FVector(-74.f, 0.f, 75.f), FRotator(-90.f, 0.f, 0.f));
	MagicSwordEffect_2Comp->SetWorldScale3D(FVector(0.4f));

	MagicSwordEffect_3Comp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("SwordEffect_3Comp"));
	MagicSwordEffect_3Comp->SetupAttachment(GetMesh());
	MagicSwordEffect_3Comp->SetRelativeLocationAndRotation(FVector(0.f, -46.f, 100.f), FRotator(-90.f, 0.f, 0.f));
	MagicSwordEffect_3Comp->SetWorldScale3D(FVector(0.4f));

	//MagicSwordEffect
	static ConstructorHelpers::FObjectFinder<UParticleSystem>SwordBackOb(TEXT("ParticleSystem'/Game/VFX/Cascade/ParagonGideon/FX/Particles/Gideon/Abilities/Burden/FX/SwordBack.SwordBack'"));
	if(SwordBackOb.Succeeded())
	{
		MagicSwordEffect = SwordBackOb.Object;
		MagicSwordEffect_1Comp->SetTemplate(MagicSwordEffect);
		MagicSwordEffect_2Comp->SetTemplate(MagicSwordEffect);
		MagicSwordEffect_3Comp->SetTemplate(MagicSwordEffect);
	}

	//JusticeSwordEffect
	static ConstructorHelpers::FObjectFinder<UParticleSystem>JusticeSwordEffectOb(TEXT("ParticleSystem'/Game/VFX/Cascade/VFX_Toolkit_V1/ParticleSystems/356Days/Par_BurstArrow_01.Par_BurstArrow_01'"));
	if (JusticeSwordEffectOb.Succeeded())
		JusticeSwordEffect = JusticeSwordEffectOb.Object;
	//JusticeSwordSound
	static ConstructorHelpers::FObjectFinder<USoundBase>JSSoundOb(TEXT("SoundCue'/Game/SFX/CUE/CUE_GroundExplosion.CUE_GroundExplosion'"));
	if (JSSoundOb.Succeeded())
		JSSound = JSSoundOb.Object;

	//Massacre Fire
	static ConstructorHelpers::FClassFinder<AMassacreFire>MassacreFireClass(TEXT("Class'/Script/KilsuARPG.MassacreFire'"));
	if (MassacreFireClass.Succeeded())
		MassacreFire = MassacreFireClass.Class;
	//Massacre Effect
	static ConstructorHelpers::FObjectFinder<UParticleSystem>MassacreOb(TEXT("ParticleSystem'/Game/VFX/Cascade/ParagonGideon/FX/Particles/Gideon/Abilities/Portal/FX/P_Portal_Entrance.P_Portal_Entrance'"));
	if (MassacreOb.Succeeded())
		MassacreParticle = MassacreOb.Object;

	//WeaponClass c++
	static ConstructorHelpers::FClassFinder<AWeapon>WeaponOb(TEXT("Class'/Script/KilsuARPG.Scythe'"));
	if (WeaponOb.Succeeded())
		WeaponClass = WeaponOb.Class;		
}

void ABoss_Reaper::BeginPlay()
{
	Super::BeginPlay();

	//��������
	if (WeaponClass != nullptr)
	{
		EquipmentComp->EquipWeapon(WeaponClass);
		EquipmentComp->UnArmWeapon();
	}
}

void ABoss_Reaper::Die()
{
	Super::Die();
	EyeTrailComp->SetTemplate(nullptr);
}

void ABoss_Reaper::LastWish()
{	
	//Super::LastWish();	
	if (EnemyController->Target == nullptr) return;
	auto Rot = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), EnemyController->Target->GetActorLocation());	
	FVector SpawnLoc = GetActorLocation();
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Owner = this;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	auto Lastwish = LoadClass<ALastWish>(nullptr, TEXT("Class'/Script/KilsuARPG.LastWish'"));
	auto LastwishActor = GetWorld()->SpawnActor<ALastWish>(SpawnLoc, Rot, SpawnInfo);
}

void ABoss_Reaper::Massacre()
{
	//1,2,6,10,14,18    3,7,11,15,19   4,8,12,16   5,9,13,17�� ������ �߻�(�����Լ��� Delay����)
	if (MassacreParticle)
	{
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[0]->GetComponentLocation(), MassacrePos[0]->GetComponentRotation(), FVector(0.7f), true);
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[1]->GetComponentLocation(), MassacrePos[1]->GetComponentRotation(), FVector(0.7f), true);
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[5]->GetComponentLocation(), MassacrePos[5]->GetComponentRotation(), FVector(0.7f), true);
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[9]->GetComponentLocation(), MassacrePos[9]->GetComponentRotation(), FVector(0.7f), true);
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[13]->GetComponentLocation(), MassacrePos[13]->GetComponentRotation(), FVector(0.7f), true);
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[17]->GetComponentLocation(), MassacrePos[17]->GetComponentRotation(), FVector(0.7f), true);		
		GetWorld()->GetTimerManager().SetTimer(Massacrehandle, FTimerDelegate::CreateLambda([&]() {			
			FActorSpawnParameters SpawnInfo;		
			SpawnInfo.Owner = this;
			SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;			
			FTransform SpawnTr = MassacrePos[0]->GetComponentTransform();
			GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr, SpawnInfo);
			SpawnTr = MassacrePos[1]->GetComponentTransform();
			GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr, SpawnInfo);
			SpawnTr = MassacrePos[5]->GetComponentTransform();
			GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr, SpawnInfo);
			SpawnTr = MassacrePos[9]->GetComponentTransform();
			GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr, SpawnInfo);
			SpawnTr = MassacrePos[13]->GetComponentTransform();
			GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr, SpawnInfo);
			SpawnTr = MassacrePos[17]->GetComponentTransform();
			GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr, SpawnInfo);

			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[2]->GetComponentLocation(), MassacrePos[2]->GetComponentRotation(), FVector(0.7f), true);
			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[6]->GetComponentLocation(), MassacrePos[6]->GetComponentRotation(), FVector(0.7f), true);
			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[10]->GetComponentLocation(), MassacrePos[10]->GetComponentRotation(), FVector(0.7f), true);
			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[14]->GetComponentLocation(), MassacrePos[14]->GetComponentRotation(), FVector(0.7f), true);
			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[18]->GetComponentLocation(), MassacrePos[18]->GetComponentRotation(), FVector(0.7f), true);

			GetWorld()->GetTimerManager().SetTimer(Massacrehandle_, FTimerDelegate::CreateLambda([&]() {
				FActorSpawnParameters SpawnInfo_;
				SpawnInfo_.Owner = this;
				SpawnInfo_.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;				
				FTransform SpawnTr_ = MassacrePos[2]->GetComponentTransform();
				GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr_, SpawnInfo_);
				SpawnTr_ = MassacrePos[6]->GetComponentTransform();
				GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr_, SpawnInfo_);
				SpawnTr_ = MassacrePos[10]->GetComponentTransform();
				GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr_, SpawnInfo_);
				SpawnTr_ = MassacrePos[14]->GetComponentTransform();
				GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr_, SpawnInfo_);
				SpawnTr_ = MassacrePos[18]->GetComponentTransform();
				GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr_, SpawnInfo_);

				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[3]->GetComponentLocation(), MassacrePos[3]->GetComponentRotation(), FVector(0.7f), true);
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[7]->GetComponentLocation(), MassacrePos[7]->GetComponentRotation(), FVector(0.7f), true);
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[11]->GetComponentLocation(), MassacrePos[11]->GetComponentRotation(), FVector(0.7f), true);
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[15]->GetComponentLocation(), MassacrePos[15]->GetComponentRotation(), FVector(0.7f), true);
				
				GetWorld()->GetTimerManager().SetTimer(Massacrehandle__, FTimerDelegate::CreateLambda([&]() {
					FActorSpawnParameters SpawnInfo__;
					SpawnInfo__.Owner = this;
					SpawnInfo__.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
					FTransform SpawnTr__ = MassacrePos[3]->GetComponentTransform();
					GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr__, SpawnInfo__);
					SpawnTr__ = MassacrePos[7]->GetComponentTransform();
					GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr__, SpawnInfo__);
					SpawnTr__ = MassacrePos[11]->GetComponentTransform();
					GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr__, SpawnInfo__);
					SpawnTr__ = MassacrePos[15]->GetComponentTransform();
					GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr__, SpawnInfo__);

					UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[4]->GetComponentLocation(), MassacrePos[4]->GetComponentRotation(), FVector(0.7f), true);
					UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[8]->GetComponentLocation(), MassacrePos[8]->GetComponentRotation(), FVector(0.7f), true);
					UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[12]->GetComponentLocation(), MassacrePos[12]->GetComponentRotation(), FVector(0.7f), true);
					UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MassacreParticle, MassacrePos[16]->GetComponentLocation(), MassacrePos[16]->GetComponentRotation(), FVector(0.7f), true);

					GetWorld()->GetTimerManager().SetTimer(Massacrehandle___, FTimerDelegate::CreateLambda([&]() {
						FActorSpawnParameters SpawnInfo___;
						SpawnInfo___.Owner = this;
						SpawnInfo___.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
						FTransform SpawnTr___ = MassacrePos[4]->GetComponentTransform();
						GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr___, SpawnInfo___);
						SpawnTr___ = MassacrePos[8]->GetComponentTransform();
						GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr___, SpawnInfo___);
						SpawnTr___ = MassacrePos[12]->GetComponentTransform();
						GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr___, SpawnInfo___);
						SpawnTr___ = MassacrePos[16]->GetComponentTransform();
						GetWorld()->SpawnActor<AMassacreFire>(MassacreFire, SpawnTr___, SpawnInfo___);
						GetWorld()->GetTimerManager().ClearTimer(Massacrehandle);
						GetWorld()->GetTimerManager().ClearTimer(Massacrehandle_);
						GetWorld()->GetTimerManager().ClearTimer(Massacrehandle__);
						GetWorld()->GetTimerManager().ClearTimer(Massacrehandle___);
					}), 0.3f, false);
				}), 0.3f, false);
			}), 0.3f, false);
		}), 0.3f, false);
	}
}

void ABoss_Reaper::JusticeSword()
{
	auto EC = EnemyController;
	float Range = 2000.f;
	if (EC && EC->Target)
	{
		//�������� ����� ������ġ
		FVector GroundLocation = EC->Target->GetActorLocation() + EC->Target->GetVelocity() / UKismetMathLibrary::RandomFloatInRange(1.f, 2.f);
		//������ġ�� ������ġ���� �Ÿ�
		float toDist = (GetActorLocation() - GroundLocation).Size();
		toDist = UKismetMathLibrary::FClamp(toDist, 0.f, Range);
		FRotator rot = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), GroundLocation);

		FVector StartLoc = GetActorLocation() + rot.Vector() * toDist;
		TArray<TEnumAsByte<EObjectTypeQuery>>ObjectTypes; ObjectTypes.Empty();
		ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_WorldStatic));
		TArray<AActor*>IgnoreActors; IgnoreActors.Empty();
		FHitResult Hit;
		UKismetSystemLibrary::LineTraceSingleForObjects(GetWorld(), StartLoc, StartLoc - FVector(0.f, 0.f, 2000.f), ObjectTypes, false, IgnoreActors, EDrawDebugTrace::None, Hit, true);
		GroundLocation = Hit.Location;
		SaveLocation = GroundLocation;

		//auto Effect = LoadObject<UParticleSystem>(nullptr, TEXT("ParticleSystem'/Game/VFX/Cascade/VFX_Toolkit_V1/ParticleSystems/356Days/Par_BurstArrow_01.Par_BurstArrow_01'"));		
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), JusticeSwordEffect, FTransform(FRotator::ZeroRotator, GroundLocation, FVector(2.f)));
		
		FTimerHandle handle, handle_;
		GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]() {
			//auto Soundsorce = LoadObject<USoundBase>(nullptr, TEXT("SoundCue'/Game/SFX/CUE/CUE_GroundExplosion.CUE_GroundExplosion'"));
			UGameplayStatics::PlaySoundAtLocation(GetWorld(), JSSound, SaveLocation);
			
			auto JusticeSwordActor = LoadClass<AJusticeSword>(nullptr, TEXT("Class'/Script/KilsuARPG.JusticeSword'"));
			FActorSpawnParameters SpawnInfo;
			SpawnInfo.Owner = this;
			GetWorld()->SpawnActor<AJusticeSword>(SaveLocation, rot, SpawnInfo);
			GetWorld()->GetTimerManager().ClearTimer(handle);
			GetWorld()->GetTimerManager().ClearTimer(handle_);
		}), 2.2f, false);
	}
}

void ABoss_Reaper::Reaper_FireBall(bool leftright)
{	
	FVector socketloc = leftright ? GetMesh()->GetSocketLocation(Magic_LH_Name) : GetMesh()->GetSocketLocation(Magic_RH_Name);
	FVector targetloc = EnemyController->Target != nullptr ? EnemyController->Target->GetActorLocation() : FVector::ZeroVector;
	FRotator rot = UKismetMathLibrary::FindLookAtRotation(socketloc, targetloc);
	auto FireballClass = LoadClass<AFireBall>(nullptr, TEXT("Class'/Script/KilsuARPG.FireBall'"));
	FTransform SpawnTr = FTransform(rot, socketloc + rot.Vector(), FVector(1.f));
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Owner = this;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	GetWorld()->SpawnActor<AFireBall>(FireballClass, SpawnTr, SpawnInfo);
}

void ABoss_Reaper::ShockWave()
{
	TArray<TEnumAsByte<EObjectTypeQuery>>ObjectTypes;
	ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
	TArray<AActor*>IgnoreActors; IgnoreActors.Add(this);
	TArray<AActor*>OutActors;
	UKismetSystemLibrary::SphereOverlapActors(GetWorld(), GetActorLocation(), 700.f, ObjectTypes, nullptr, IgnoreActors, OutActors);
	if (OutActors.Num() > 0)
	{
		for (auto OutActor : OutActors)
		{
			//IsEnemy
			if (IsValid(OutActor) && OutActor->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true && ICombatInterface::Execute_CheckEnemy(this, ICombatInterface::Execute_GetTag(OutActor)))
			{
				//IsAlive
				if (OutActor->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(OutActor) && IStateInterface::Execute_IsImmotal(OutActor) == false)
				{
					FDamage Damage;
					Damage.Damage = 250.f;
					Damage.bCanGuard = true;
					Damage.bCanParry = false;
					Damage.bSetCustom = true;
					Damage.DamageType = EDamageType::Heavy;					
					ICombatInterface::Execute_TakeDamaged(OutActor, Damage, this);
					UAISense_Damage::ReportDamageEvent(GetWorld(), OutActor, this, Damage.Damage, OutActor->GetActorLocation(), OutActor->GetActorLocation());					
				}
			}
		}
	}
}

