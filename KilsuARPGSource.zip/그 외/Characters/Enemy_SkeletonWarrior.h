// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Characters/EnemyCharacter.h"
#include "Enemy_SkeletonWarrior.generated.h"

UCLASS()
class KILSUARPG_API AEnemy_SkeletonWarrior : public AEnemyCharacter
{
	GENERATED_BODY()
	
protected:
	virtual void BeginPlay() override;
	UPROPERTY() TSubclassOf<class AWeapon> WeaponClass = nullptr;

public:
	AEnemy_SkeletonWarrior();
};
