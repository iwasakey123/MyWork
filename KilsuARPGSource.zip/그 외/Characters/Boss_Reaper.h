// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Characters/EnemyCharacter.h"
#include "Boss_Reaper.generated.h"

class UArrowComponent;
UCLASS()
class KILSUARPG_API ABoss_Reaper : public AEnemyCharacter
{
	GENERATED_BODY()
	
protected:
	UPROPERTY() class UParticleSystem* RedEyeTrail;
	UPROPERTY() class UParticleSystemComponent* EyeTrailComp;
	UPROPERTY() class UParticleSystem* MagicSwordEffect;
	UPROPERTY() class UParticleSystemComponent* MagicSwordEffect_1Comp;
	UPROPERTY() class UParticleSystemComponent* MagicSwordEffect_2Comp;
	UPROPERTY() class UParticleSystemComponent* MagicSwordEffect_3Comp;

	UPROPERTY() UParticleSystem* JusticeSwordEffect;
	UPROPERTY() class USoundBase* JSSound;

	UPROPERTY() TArray<UArrowComponent*>MassacrePos;
	UPROPERTY() class UParticleSystem* MassacreParticle;
	UPROPERTY() TSubclassOf<class AMassacreFire> MassacreFire;
	UPROPERTY() FTimerHandle Massacrehandle;
	UPROPERTY() FTimerHandle Massacrehandle_;
	UPROPERTY() FTimerHandle Massacrehandle__;
	UPROPERTY() FTimerHandle Massacrehandle___;

	UPROPERTY() FName Magic_RH_Name;
	UPROPERTY() FName Magic_LH_Name;

	UPROPERTY() FVector SaveLocation;

	UPROPERTY() TSubclassOf<class AWeapon> WeaponClass;
	virtual void BeginPlay() override;
public:
	ABoss_Reaper();
	   
	virtual void Die() override;	
	virtual void LastWish() override;

	UFUNCTION() void Massacre();
	UFUNCTION() void JusticeSword();
	UFUNCTION() void Reaper_FireBall(bool leftright);
	UFUNCTION() void ShockWave();

	FORCEINLINE TArray<UArrowComponent*> GetMassacrePos() { return MassacrePos; }
};
