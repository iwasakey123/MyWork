// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemyCharacter.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/CapsuleComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Perception/AISenseConfig_Damage.h"
#include "KilsuARPG/Data/FloatingDamage/FloatingDamageActor.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Components/ArrowComponent.h"
#include "KilsuARPG/Item/Item.h"
#include "EnvironmentQuery/EnvQuery.h"
#include "EnvironmentQuery/EnvQueryManager.h"
#include "Components/WidgetComponent.h"
#include "KilsuARPG/UI/HUD/HUDUI_Enemy.h"

#include "KilsuARPG/Components/MontageComponent.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"
#include "KilsuARPG/Components/RotateComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "KilsuARPG/Components/DissolveComponent.h"

AEnemyCharacter::AEnemyCharacter()
{
	//EnemyCharacter�� �⺻��
	



	//AIName = FName("Boss");
	AIType = EAIType::Monster;
	AITag = FName("Enemy");
	FriendTags.Add("Enemy");
	FriendTags.Add("Boss");
	EnemyTags.Add("Player");
	//EAISize = ETargetSize::Normal;

	Roots.Empty();

	bUseControllerRotationPitch = false;
	bUseControllerRotationRoll = false;
	bUseControllerRotationYaw = false;
	AIControllerClass = AEnemyController::StaticClass();	
	AutoPossessAI = EAutoPossessAI::PlacedInWorldOrSpawned;
	GetMesh()->SetCollisionObjectType(ECollisionChannel::ECC_PhysicsBody);
	GetMesh()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);
	GetCapsuleComponent()->SetCollisionObjectType(ECollisionChannel::ECC_Pawn);
	GetCapsuleComponent()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);

	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.f, 540.f, 0.f);
	GetCharacterMovement()->MaxWalkSpeed = 300.f;
	
	//custom Components Create
	MontageComp = CreateDefaultSubobject<UMontageComponent>(TEXT("MontageComp"));	
	EquipmentComp = CreateDefaultSubobject<UEquipmentComponent>(TEXT("EquipmentComp"));
	MeleeCombatComp = CreateDefaultSubobject<UMeleeCombatComponent>(TEXT("MeleeCombatComp"));
	RotateComp = CreateDefaultSubobject<URotateComponent>(TEXT("RotateComp"));
	StatsComp = CreateDefaultSubobject<UStatsComponent>(TEXT("StatsComp"));
	DissolveComp = CreateDefaultSubobject<UDissolveComponent>(TEXT("DissolveComp"));

	BehindPos = CreateDefaultSubobject<UArrowComponent>(TEXT("BehindPos"));
	BehindPos->SetupAttachment(GetRootComponent());
	BehindPos->SetRelativeLocationAndRotation(FVector(-40.f, 0.f, -90.f), FRotator(0.f));

	EnemyHUDWidgetComp = CreateDefaultSubobject<UWidgetComponent>(TEXT("EnemyHUDWidgetComp"));
	EnemyHUDWidgetComp->SetupAttachment(GetMesh());
	EnemyHUDWidgetComp->SetRelativeLocation(FVector(0.f, 0.f, 250.f));
	EnemyHUDWidgetComp->SetWidgetSpace(EWidgetSpace::Screen);
	EnemyHUDWidgetComp->SetDrawAtDesiredSize(true);		
	//EnemyHUDWidgetComp->GetUserWidgetObject()->SetOwningActor

	//EnemyHUD Widget BP
	static ConstructorHelpers::FObjectFinder<UClass>EnemyHUDOb(TEXT("WidgetBlueprint'/Game/BP/UI/HUD/WBP_EnemyHP.WBP_EnemyHP_C'"));
	if (EnemyHUDOb.Succeeded())
	{		
		EnemyHUDWidgetComp->SetWidgetClass(EnemyHUDOb.Object);		
	}

	//AI test Mesh
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/Humanoid/Kilsu/Mesh/SK_Mannequin_Pink.SK_Mannequin_Pink'"));
	if (Mannequin.Succeeded())
		GetMesh()->SetSkeletalMesh(Mannequin.Object);
	GetMesh()->SetRelativeLocationAndRotation(FVector(0.f, 0.f, -90.f), FRotator(0.f, -90.f, 0.f));

	//AnimBP
	//static ConstructorHelpers::FObjectFinder<UClass>AnimBP(TEXT("AnimBlueprint'/Game/BP/AnimInstance/ABP_TestAI.ABP_TestAI_C'"));
	//if (AnimBP.Succeeded())
	//	GetMesh()->SetAnimInstanceClass(AnimBP.Object);

	//MontageTable
	static ConstructorHelpers::FObjectFinder<UDataTable>MontageTableOb(TEXT("DataTable'/Game/BP/Data/DataTable/MontagesDT_Enemy.MontagesDT_Enemy'"));
	if (MontageTableOb.Succeeded())
	{
		MontageComp->MontageTable = MontageTableOb.Object;
		MontageComp->MontageID = AIName;
	}

	//EQS SpawnSpot ���� �����ɽ� ������ġ�� ã���ִ� EQS
	static ConstructorHelpers::FObjectFinder<UEnvQuery>SpawnSpotOb(TEXT("EnvQuery'/Game/BP/AI/EQS/EQS_SummonSpot.EQS_SummonSpot'"));
	if (SpawnSpotOb.Succeeded())
		EQS_SpawnSpot = SpawnSpotOb.Object;
}

//BeinPlay
void AEnemyCharacter::BeginPlay()
{
	Super::BeginPlay();
	EnemyController = Cast<AEnemyController>(GetController());
	MeleeCombatComp->MeleeCollisionActivate.AddUFunction(this, FName("CollisionActivated"));
	MeleeCombatComp->AttackHit.AddUFunction(this, FName("AttackHit"));
	StatsComp->Die.AddUFunction(this, FName("Die"));
	DissolveComp->FinishDissolve.AddUFunction(this, FName("DissolveFinish"));
}

//DeclareBind
void AEnemyCharacter::CollisionActivated(ECollisionParts CollisionType)
{
	switch (CollisionType)
	{
	case ECollisionParts::Weapon:
		if (EquipmentComp->MainWeaponComp)
			MeleeCombatComp->SetCollisionComponent(EquipmentComp->MainWeaponComp, EquipmentComp->MainWeaponComp->GetAllSocketNames());
		break;
	}
}

//���� ������ �Ҷ�
void AEnemyCharacter::AttackHit(FHitResult Hit)
{
	if (IsValid(Hit.Actor.Get()) == false) return;
	//IsEnemy
	if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true && ICombatInterface::Execute_CheckEnemy(this, ICombatInterface::Execute_GetTag(Hit.Actor.Get())))
	{
		//IsAlive
		if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(Hit.Actor.Get()) && IStateInterface::Execute_IsImmotal(Hit.Actor.Get()) == false)
		{
			auto Damage = MeleeCombatComp->GetCustomDamage().bSetCustom ? MeleeCombatComp->GetCustomDamage() : StatsComp->MakeDamage(EDamageType::Normal);
			ICombatInterface::Execute_TakeDamaged(Hit.Actor.Get(), Damage, this);
			UAISense_Damage::ReportDamageEvent(GetWorld(), Hit.Actor.Get(), this, Damage.Damage, Hit.Location, Hit.Location);			
		}
	}
}

//�׾�����
void AEnemyCharacter::Die()
{
	bDead = true;
	if (IsValid(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0)) && UGameplayStatics::GetPlayerCharacter(GetWorld(), 0)->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()))
		ICombatInterface::Execute_SetEnemyTarget(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0), nullptr, AIType);
	ShowEnemyHUD(true);
	EnemyController->GetBrainComponent()->StopLogic(TEXT("Dead"));	
	FTimerHandle handle;	
	StopAnimMontage();
	float delay = MontageComp->PlayMontage(EMontageType::Die);	
	GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]() {
		DissolveComp->StartDissolve(GetMesh(), false);
		if (Roots.Num() > 0)
		{
			FActorSpawnParameters SpawnInfo;
			SpawnInfo.Owner = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);			
			for (int32 i = 0; i < Roots.Num(); i++)
			{				
				auto SpawnRoot = GetWorld()->SpawnActor<AItem>(Roots[i], GetActorLocation() + FVector(UKismetMathLibrary::RandomFloatInRange(-50.f, 50.f), UKismetMathLibrary::RandomFloatInRange(-50.f, 50.f), UKismetMathLibrary::RandomFloatInRange(25.f, 100.f)),FRotator::ZeroRotator, SpawnInfo);
				SpawnRoot->GetDisplayMesh()->AddImpulse(FVector(UKismetMathLibrary::RandomFloatInRange(-50.f, 50.f), UKismetMathLibrary::RandomFloatInRange(-50.f, 50.f), 600.f), NAME_None, true);
			}
			GetWorld()->GetTimerManager().ClearAllTimersForObject(this);
		}
	}), delay + 1.5f, false);
}
//�װ����� �޽��� ����ȭ
void AEnemyCharacter::DissolveFinish(bool Reverse)
{
	if (bDead == true)
	{
		Destroy();
	}	
}

//StateInterface::IsAlive
bool AEnemyCharacter::IsAlive_Implementation()
{
	return !bDead;
}
//StateInterface::IsCombat
bool AEnemyCharacter::IsCombat_Implementation()
{
	return bIsCombat;
}
//StateInterface::SetCombat
void AEnemyCharacter::SetCombat_Implementation(bool Combat)
{
	bIsCombat = Combat;
}
//StateInterface::IsImmotal
bool AEnemyCharacter::IsImmotal_Implementation()
{
	return bImmotal;
}
//StateInterface::SetImmotal
void AEnemyCharacter::SetImmotal_Implementation(bool on)
{
	bImmotal = on;
}
//StateInterface::IsSuperArmor
bool AEnemyCharacter::IsSuperArmor_Implementation()
{
	return bSuperArmor;
}
void AEnemyCharacter::SetSuperArmor_Implementation(bool on)
{
	bSuperArmor = on;
}
//StateInterface::GetAttackSpeed
float AEnemyCharacter::GetAttackSpeed_Implementation()
{
	return 1.f;
}

//CombatInterface::GetDesiredRotation
FRotator AEnemyCharacter::GetDesiredRotation_Implementation()
{
	if (EnemyController->Target)
	{
		float X = GetActorRotation().Roll;
		float Y = GetActorRotation().Pitch;
		float Z = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), EnemyController->Target->GetActorLocation()).Yaw;
		FRotator Rot = UKismetMathLibrary::MakeRotator(X, Y, Z);
		return Rot;
	}
	else return GetActorRotation();
}
//CombatInterface::GetTag;
FName AEnemyCharacter::GetTag_Implementation()
{
	return AITag;
}
//CombatInterface::CheckEnemy
bool AEnemyCharacter::CheckEnemy_Implementation(const FName& Tag)
{
	return EnemyTags.Contains(Tag);
}
//CombatInterface::SetMovement
void AEnemyCharacter::SetMovement_Implementation(EAIMovement MovementType)
{
	switch (MovementType)
	{
	case EAIMovement::Stop:
		GetCharacterMovement()->MaxWalkSpeed = 0.f;
		break;
	case EAIMovement::SlowWalk:
		GetCharacterMovement()->MaxWalkSpeed = 200.f;
		break;
	case EAIMovement::Walk:
		GetCharacterMovement()->MaxWalkSpeed = 300.f;
		break;
	case EAIMovement::Run:
		GetCharacterMovement()->MaxWalkSpeed = 400.f;
		break;
	case EAIMovement::Sprint:
		GetCharacterMovement()->MaxWalkSpeed = 600.f;
		break;
	}
}

//�������� �޾�����
//CombatInterface::TakeDamage
void AEnemyCharacter::TakeDamaged_Implementation(const FDamage& Damage, AActor* Causer)
{
	if (bImmotal) return;		
	if (!bSuperArmor && Damage.DamageType != EDamageType::TakeDown) 	
	{
		EnemyController->GetBlackboardComponent()->SetValueAsBool(EnemyController->HitKey, true);
	}
	MeleeCombatComp->HitChangeMats();
	StatsComp->Damaged(Damage);		

	if (Damage.DamageType == EDamageType::TakeDown)
		EnemyController->GetBlackboardComponent()->SetValueAsBool(EnemyController->TakeDownKey, true);
}
//CombatInterface::TargetParrySuceess
void AEnemyCharacter::Target_ParrySuccess_Implementation(AActor* Target)
{
	//SetGroggy
	Groggy();
	ICombatInterface::Execute_CanFinishExecute(Target, true);	
}
//CombatInterface::Executed
void AEnemyCharacter::SetExecutionMode_Implementation()
{
	FTimerHandle handle;
	GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]() {
		EnemyController->GetBlackboardComponent()->SetValueAsBool(EnemyController->ExecutedKey, true);	
		GetWorld()->GetTimerManager().ClearTimer(handle);
	}), 1.f, false);
}
//CombatInterface::GetBehindPos
UArrowComponent* AEnemyCharacter::GetBehindArrowPos_Implementation()
{
	return BehindPos;
}
//CombatInterface::SetGuardhit
void AEnemyCharacter::SetGuardHit_Implementation()
{
	EnemyController->GetBlackboardComponent()->SetValueAsBool(EnemyController->GuardHitKey, true);
}
//CombatInterface::SetSpecialHit
void AEnemyCharacter::SetSpecialHit_Implementation(bool on)
{
	EnemyController->GetBlackboardComponent()->SetValueAsBool(EnemyController->SpecialHitKey, on);
}

//TargetingInterface::
bool AEnemyCharacter::IsTargetable_Implementation()
{
	return true;
}
void AEnemyCharacter::OnSelected_Implementation()
{

}
void AEnemyCharacter::DeSelected_Implementation()
{

}
ETargetSize AEnemyCharacter::GetTargetSize_Implementation()
{
	return AISize;
}

void AEnemyCharacter::Groggy()
{
	EnemyController->GetBlackboardComponent()->SetValueAsBool(EnemyController->IsGroggyKey, true);
}

void AEnemyCharacter::LastWish()
{
	//LastWish;
}

//AI������Ű��
void AEnemyCharacter::SummonAI(TSubclassOf<AEnemyCharacter>SummonAIClass)
{
	if (SummonAIClass == nullptr || SummonAIClass == NULL) return;
	SummonAIclass = SummonAIClass;
	//auto EQS_SpawnSpot = LoadObject<UEnvQuery>(nullptr, TEXT("EnvQuery'/Game/BP/AI/EQS/EQS_SummonSpot.EQS_SummonSpot'"));
	if (EQS_SpawnSpot)
	{
		FEnvQueryRequest QueryRequest = FEnvQueryRequest(EQS_SpawnSpot, this);
		QueryRequest.Execute(EEnvQueryRunMode::RandomBest25Pct, this, &AEnemyCharacter::HandleQueryResult);
	}
}
//AI������Ű�� (��ġ�� ã����)
void AEnemyCharacter::HandleQueryResult(TSharedPtr<FEnvQueryResult> result)
{
	if (result->IsSuccsessful())
	{		
		FVector StartPos = result->GetItemAsLocation(0);
		FVector EndPos = StartPos - FVector(0.f, 0.f, 2000.f);
		TArray<TEnumAsByte<EObjectTypeQuery>>Objects;
		Objects.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_WorldStatic));
		TArray<AActor*>IgnoreActors;
		FHitResult Hit;
		if (UKismetSystemLibrary::LineTraceSingleForObjects(GetWorld(), StartPos, EndPos, Objects, false, IgnoreActors, EDrawDebugTrace::None, Hit, true))
		{
			//SpawnTransform
			FVector TrLoc = Hit.Location;
			FRotator TrRot = UKismetMathLibrary::MakeRotFromX(UKismetMathLibrary::GetDirectionUnitVector(GetActorLocation(), Hit.Location));			
			if (EnemyController->Target)
			{
				float RotYaw = UKismetMathLibrary::FindLookAtRotation(TrLoc, EnemyController->Target->GetActorLocation()).Yaw;		
				TrRot = UKismetMathLibrary::MakeRotator(0.f, 0.f, RotYaw);
			}
			FTransform Tr = FTransform(TrRot, TrLoc, ((FVector)(1.f)));
			FActorSpawnParameters SpawnInfo;
			SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
			SpawnInfo.Owner = this;
			auto SpawnedAIActor = GetWorld()->SpawnActor<AEnemyCharacter>(SummonAIclass, Tr, SpawnInfo);	

		}
	}
}

//�÷��̾ �߰��ϸ� �ڽ��� HP���¸� �����ش�.
void AEnemyCharacter::ShowEnemyHUD(bool Hide)
{
	auto EnemyUI = Cast<UHUDUI_Enemy>(EnemyHUDWidgetComp->GetUserWidgetObject());
	if (EnemyUI && AIType == EAIType::Monster)
	{
		EnemyUI->OwningActor = this;
		EnemyUI->PlayFadeAnim(Hide);
	}
}