// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Characters/PlayerCharacter.h"
#include "Player_Female.generated.h"

UCLASS()
class KILSUARPG_API APlayer_Female : public APlayerCharacter
{
	GENERATED_BODY()
	
public:
	APlayer_Female();
	
protected:
	void BeginPlay();

public:	
	virtual void Die() override;
};
