// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy_SkeletonWarrior.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "KilsuARPG/Components/MontageComponent.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Components/DissolveComponent.h"
#include "Components/WidgetComponent.h"
#include "KilsuARPG/UI/HUD/HUDUI_Enemy.h"
//Weapon
#include "KilsuARPG/Item/Weapon/Sword/CelticSword.h"

AEnemy_SkeletonWarrior::AEnemy_SkeletonWarrior()
{
	AIType = EAIType::Monster;
	AIName = FName("SkeletonWarrior");
	AITag = FName("Enemy");
	AISize = ETargetSize::Normal;

	//Stat Setting
	StatsComp->HP.Max = 400.f;
	StatsComp->HP.Current = 400;
	StatsComp->Stamina.Max = 100.f;
	StatsComp->Stamina.Current = 100;
	StatsComp->MP.Current = 100.f;
	StatsComp->MP.Max = 100.f;
	StatsComp->ATT.Current = 30.f;
	StatsComp->MTT.Current = 10.f;
	StatsComp->CritChance = 10.f;
	StatsComp->CritDamage = 200.f;
	
	MontageComp->SetMontageID(FName("SkeletonWarrior"));

	EnemySense.SightRadius = 5500.f;
	EnemySense.LoseSightRadius = 5500.f;
	EnemySense.SightMaxAge = 50.f;
	EnemySense.PeripheralVisionAngleDegrees = 70.f;
	EnemySense.DamageMaxAge = 50.f;
	
	//AI Mesh
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/Humanoid/SkeletonFootman/Character/SK_SkeletonFootman.SK_SkeletonFootman'"));
	if (Mannequin.Succeeded())
		GetMesh()->SetSkeletalMesh(Mannequin.Object);
	GetMesh()->SetRelativeLocationAndRotation(FVector(0.f, 0.f, -90.f), FRotator(0.f, -90.f, 0.f));

	//BehaviorTree
	static ConstructorHelpers::FObjectFinder<UBehaviorTree>BossBehaviorTree(TEXT("BehaviorTree'/Game/BP/AI/BT/BT_SimpleAI.BT_SimpleAI'"));
	if (BossBehaviorTree.Succeeded())
		BehaviorTree = BossBehaviorTree.Object;

	//AnimBP
	static ConstructorHelpers::FObjectFinder<UClass>AnimBP(TEXT("AnimBlueprint'/Game/BP/AnimInstance/ABP_SkeletonWarrior.ABP_SkeletonWarrior_C'"));
	if (AnimBP.Succeeded())
		GetMesh()->SetAnimInstanceClass(AnimBP.Object);

	//WeaponClass c++
	static ConstructorHelpers::FClassFinder<AWeapon>WeaponOb(TEXT("Class'/Script/KilsuARPG.CelticSword'"));
	if (WeaponOb.Succeeded())
		WeaponClass = WeaponOb.Class;
}

void AEnemy_SkeletonWarrior::BeginPlay()
{
	Super::BeginPlay();
	if (WeaponClass != nullptr)
	{
		EquipmentComp->EquipWeapon(WeaponClass);		
	}
	DissolveComp->StartDissolve(GetMesh(), true);
}
