// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "DissolveComponent.generated.h"

USTRUCT()
struct FDissolveComp
{
	GENERATED_BODY()
public:
	UPROPERTY() class UPrimitiveComponent* Comp;
	UPROPERTY() float Value;
	UPROPERTY() TArray<UMaterialInterface*> Materials;
	UPROPERTY() TArray<UMaterialInstanceDynamic*> DissolveMats;
	UPROPERTY() bool bRunning;
	UPROPERTY() bool bReverse;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API UDissolveComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UDissolveComponent();
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	DECLARE_EVENT_OneParam(ACharacter, FFinishDissolve, bool) FFinishDissolve FinishDissolve;

	UFUNCTION(BlueprintCallable) void StartDissolve(class UPrimitiveComponent* Comp, bool Reverse = false);
	UFUNCTION() void StopDissolve(UPrimitiveComponent* Comp);
	UFUNCTION() void DissolveComps();

private:
	UPROPERTY() UMaterialInstance* DissolveMat;
	UPROPERTY() FName DissolveValueName;
	UPROPERTY() FName DissolveColorName;
	UPROPERTY() FLinearColor DissolveColor;
	UPROPERTY() TArray<FDissolveComp> DComps;
	UPROPERTY() float DissolveSpeed;
	UPROPERTY() bool bStartDissolve;
	UPROPERTY() bool bKeepDissolve;
};
