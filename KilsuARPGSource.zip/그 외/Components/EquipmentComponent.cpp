// Fill out your copyright notice in the Description page of Project Settings.


#include "EquipmentComponent.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "KilsuARPG/Item/Weapon/Weapon.h"
#include "KilsuARPG/Item/Armor/Armor.h"
#include "KilsuARPG/Components/InventoryComponent.h"
#include "Particles/ParticleSystemComponent.h"

UEquipmentComponent::UEquipmentComponent()
{
	//PrimaryComponentTick.bCanEverTick = true;
	OwnerCharacter = Cast<ACharacter>(GetOwner());	
	
	//���� ��� ������Ʈ ���� �� �ʱ�ȭ
	HeadComp = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("HeadComp"));
	HeadComp->SetCollisionObjectType(ECollisionChannel::ECC_PhysicsBody);
	HeadComp->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);
	UpperComp = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("UpperComp"));
	UpperComp->SetCollisionObjectType(ECollisionChannel::ECC_PhysicsBody);
	UpperComp->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);
	LowerComp = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("LowerComp"));
	LowerComp->SetCollisionObjectType(ECollisionChannel::ECC_PhysicsBody);
	LowerComp->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);
	ShoesComp = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("ShoesComp"));
	ShoesComp->SetCollisionObjectType(ECollisionChannel::ECC_PhysicsBody);
	ShoesComp->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);
	HandComp = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("HandComp"));
	HandComp->SetCollisionObjectType(ECollisionChannel::ECC_PhysicsBody);
	HandComp->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);
	CapeComp = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("CapeComp"));
	CapeComp->SetCollisionObjectType(ECollisionChannel::ECC_PhysicsBody);
	CapeComp->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);

	static ConstructorHelpers::FObjectFinder<UParticleSystem>DefaultTrailOb(TEXT("ParticleSystem'/Game/VFX/Cascade/AdvancedMagicFX12/particles/P_ky_trail_primitive.P_ky_trail_primitive'"));
	if (DefaultTrailOb.Succeeded())
	{
		DefaultTrail = DefaultTrailOb.Object;		
	}
}
//���� ����
void UEquipmentComponent::EquipWeapon(TSubclassOf<AWeapon>WeaponClass, bool bAutoUnEquip)
{	
	auto Weapon = WeaponClass.GetDefaultObject();
	if (Weapon == nullptr) return;
	if (CurrentWeapon != nullptr && bAutoUnEquip == true)
	{
		UnEquipWeapon();
	}
	//�������� ������Ʈ�� �����Ͽ� ������ MainWeaponComponent�ּҿ� �����մϴ�..
	MainWeaponComp = NewObject<UStaticMeshComponent>(this);	
	CurrentWeapon = WeaponClass;
	MainWeaponComp->RegisterComponent();
	MainWeaponComp->SetStaticMesh(Weapon->ItemInfo.ItemMesh);
	MainWeaponComp->SetCollisionObjectType(ECollisionChannel::ECC_GameTraceChannel1);
	MainWeaponComp->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);
	MainWeaponComp->SetCollisionResponseToChannel(ECollisionChannel::ECC_Destructible, ECollisionResponse::ECR_Block);
	MainWeaponComp->SetNotifyRigidBodyCollision(true);
	MainWeaponComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), Weapon->WeaponInfo.SocketName);
	UpdatingMeshRender.Broadcast(EEquipmentType::MainWeapon, Weapon->WeaponInfo.UnArmSocketName, Weapon->ItemInfo.ItemMesh, nullptr);
	//���â UI����ȭ
	UpdateEquipmentUI.Broadcast(WeaponClass, EEquipmentType::MainWeapon);
	//��������
	if(UpdateStats.IsBound())
		UpdateStats.Execute(Weapon->ItemInfo.Stats, true);

	//TrailComp
	if (Weapon->WeaponInfo.WeaponType == EWeaponType::Sword || Weapon->WeaponInfo.WeaponType == EWeaponType::GreatSword)
	{
		CurrentTrail = DefaultTrail->GetClass();
		WeaponTrailComp = NewObject<UParticleSystemComponent>(this);
		WeaponTrailComp->RegisterComponent();
		WeaponTrailComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.SocketName);
		WeaponTrailComp->SetTemplate(DefaultTrail);
		WeaponTrailComp->Template = DefaultTrail;
	}
}
//���� ��������
bool UEquipmentComponent::UnEquipWeapon()
{
	if (CurrentWeapon != nullptr)
	{
		DeactiveEnchant();
		if(UpdateStats.IsBound())
			UpdateStats.Execute(CurrentWeapon.GetDefaultObject()->ItemInfo.Stats, false);
		if (ParticleComp && ParticleComp->Template != nullptr)
			ParticleComp->DestroyComponent();
		if (MainWeaponComp)
			MainWeaponComp->DestroyComponent();
		if (SubWeaponComp)
			SubWeaponComp->DestroyComponent();
		CurrentWeapon = nullptr;
		//IStateInterface::Execute_SetCombat(OwnerCharacter, false);
		UpdatingMeshRender.Broadcast(EEquipmentType::MainWeapon, NAME_None, nullptr, nullptr);
		UpdateEquipmentUI.Broadcast(nullptr, EEquipmentType::MainWeapon);		
		return true;
	}
	return false;
}
//�� ���� switch������ �������� ���������ϴ�.
void UEquipmentComponent::EquipArmor(TSubclassOf<AArmor>ArmorClass)
{
	auto Armor = ArmorClass.GetDefaultObject();
	if (Armor == nullptr) return;
	switch (Armor->ArmorInfo.ArmorType)
	{
	case EArmorType::Head:
		CurrentHead = ArmorClass;
		HeadComp->SetSkeletalMesh(Armor->ItemInfo.ItemMeshSK);
		HeadComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, false), FName("HAIR"));
		UpdatingMeshRender.Broadcast(EEquipmentType::Head, FName("HAIR"), nullptr, Armor->ItemInfo.ItemMeshSK);
		UpdateEquipmentUI.Broadcast(ArmorClass, EEquipmentType::Head);
		break;
	case EArmorType::Upper:
		CurrentUpper = ArmorClass;
		UpperComp->SetSkeletalMesh(Armor->ItemInfo.ItemMeshSK);
		UpperComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
		UpperComp->SetMasterPoseComponent(OwnerCharacter->GetMesh());
		UpdatingMeshRender.Broadcast(EEquipmentType::Upper, NAME_None, nullptr, Armor->ItemInfo.ItemMeshSK);
		UpdateEquipmentUI.Broadcast(ArmorClass, EEquipmentType::Upper);
		break;
	case EArmorType::Lower:
		CurrentLower = ArmorClass;	
		LowerComp->SetSkeletalMesh(Armor->ItemInfo.ItemMeshSK);
		LowerComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
		LowerComp->SetMasterPoseComponent(OwnerCharacter->GetMesh());
		UpdatingMeshRender.Broadcast(EEquipmentType::Lower, NAME_None, nullptr, Armor->ItemInfo.ItemMeshSK);
		UpdateEquipmentUI.Broadcast(ArmorClass, EEquipmentType::Lower);
		break;
	case EArmorType::Hand:
		CurrentHand = ArmorClass;
		HandComp->SetSkeletalMesh(Armor->ItemInfo.ItemMeshSK);
		HandComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
		HandComp->SetMasterPoseComponent(OwnerCharacter->GetMesh());
		UpdatingMeshRender.Broadcast(EEquipmentType::Hand, NAME_None, nullptr, Armor->ItemInfo.ItemMeshSK);
		UpdateEquipmentUI.Broadcast(ArmorClass, EEquipmentType::Hand);
		break;
	case EArmorType::Cape:
		CurrentCape = ArmorClass;
		CapeComp->SetSkeletalMesh(Armor->ItemInfo.ItemMeshSK);
		CapeComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
		CapeComp->SetMasterPoseComponent(OwnerCharacter->GetMesh());
		UpdatingMeshRender.Broadcast(EEquipmentType::Cape, NAME_None, nullptr, Armor->ItemInfo.ItemMeshSK);
		UpdateEquipmentUI.Broadcast(ArmorClass, EEquipmentType::Cape);
		break;
	case EArmorType::Shoes:
		CurrentShoes = ArmorClass;
		ShoesComp->SetSkeletalMesh(Armor->ItemInfo.ItemMeshSK);
		ShoesComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
		ShoesComp->SetMasterPoseComponent(OwnerCharacter->GetMesh());
		UpdatingMeshRender.Broadcast(EEquipmentType::Shoes, NAME_None, nullptr, Armor->ItemInfo.ItemMeshSK);
		UpdateEquipmentUI.Broadcast(ArmorClass, EEquipmentType::Shoes);
		break;
	}
	UpdateStats.ExecuteIfBound(Armor->ItemInfo.Stats, true);			
}
//�� ���� ����
bool UEquipmentComponent::UnEquipArmor(EArmorType ArmorType)
{
	switch (ArmorType)
	{
	case EArmorType::Head:
		if (CurrentHead != nullptr)
		{
			auto Head = CurrentHead.GetDefaultObject();
			UpdateStats.ExecuteIfBound(Head->ItemInfo.Stats, false);
			CurrentHead = nullptr;			
			UpdatingMeshRender.Broadcast(EEquipmentType::Head, NAME_None, nullptr, nullptr);
			UpdateEquipmentUI.Broadcast(nullptr, EEquipmentType::Head);			
			return true;
		}
		return false;
	case EArmorType::Upper:
		if (CurrentUpper != nullptr)
		{		
			auto Upper = CurrentUpper.GetDefaultObject();
			UpdateStats.ExecuteIfBound(Upper->ItemInfo.Stats, false);
			CurrentUpper = nullptr;
			UpdatingMeshRender.Broadcast(EEquipmentType::Upper, NAME_None, nullptr, nullptr);
			UpdateEquipmentUI.Broadcast(nullptr, EEquipmentType::Upper);
			return true;
		}
		return false;
	case EArmorType::Lower:		
		if (CurrentLower != nullptr)
		{			
			auto Lower = CurrentLower.GetDefaultObject();
			UpdateStats.ExecuteIfBound(Lower->ItemInfo.Stats, false);
			CurrentLower = nullptr;
			UpdatingMeshRender.Broadcast(EEquipmentType::Lower, NAME_None, nullptr, nullptr);
			UpdateEquipmentUI.Broadcast(nullptr, EEquipmentType::Lower);
			return true;
		}
		return false;
	case EArmorType::Hand:
		if (CurrentHand != nullptr)
		{	
			auto Hand = CurrentHand.GetDefaultObject();
			UpdateStats.ExecuteIfBound(Hand->ItemInfo.Stats, false);
			CurrentHand = nullptr;
			UpdatingMeshRender.Broadcast(EEquipmentType::Hand, NAME_None, nullptr, nullptr);
			UpdateEquipmentUI.Broadcast(nullptr, EEquipmentType::Hand);
			return true;
		}
		return false;
	case EArmorType::Shoes:
		if (CurrentShoes != nullptr)
		{			
			auto Shoes = CurrentShoes.GetDefaultObject();
			UpdateStats.ExecuteIfBound(Shoes->ItemInfo.Stats, false);
			CurrentShoes = nullptr;
			UpdatingMeshRender.Broadcast(EEquipmentType::Shoes, NAME_None, nullptr, nullptr);
			UpdateEquipmentUI.Broadcast(nullptr, EEquipmentType::Shoes);
			return true;
		}
		return false;
	case EArmorType::Cape:
		if (CurrentCape != nullptr)
		{		
			auto Cape = CurrentCape.GetDefaultObject();
			UpdateStats.ExecuteIfBound(Cape->ItemInfo.Stats, false);
			CurrentCape = nullptr;
			UpdatingMeshRender.Broadcast(EEquipmentType::Cape, NAME_None, nullptr, nullptr);
			UpdateEquipmentUI.Broadcast(nullptr, EEquipmentType::Cape);
			return true;
		}
		return false;
	}
	return false;
}
//�����غ�� ������Ϻ���
void UEquipmentComponent::ArmWeapon()
{
	if (CurrentWeapon)
	{		
		//IStateInterface::Execute_SetCombat(OwnerCharacter, true);
		if (ParticleComp && ParticleComp->Template != nullptr)
			ParticleComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.SocketName);
		if(MainWeaponComp)
			MainWeaponComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.SocketName);
		if (SubWeaponComp)
			SubWeaponComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.SocketName);
	}	
}
//�����غ� ������ ������� ����
void UEquipmentComponent::UnArmWeapon()
{
	if (CurrentWeapon)
	{
		//IStateInterface::Execute_SetCombat(OwnerCharacter, false);
		if (ParticleComp && ParticleComp->Template != nullptr)
			ParticleComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.UnArmSocketName);
		if (MainWeaponComp)
			MainWeaponComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.UnArmSocketName);
		if (SubWeaponComp)
			SubWeaponComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.UnArmSocketName);
	}
}
EWeaponType UEquipmentComponent::GetCurrentWeaponType()
{
	return (CurrentWeapon != nullptr) ? CurrentWeapon.GetDefaultObject()->WeaponInfo.WeaponType : EWeaponType::NoWeapon; 
}

float UEquipmentComponent::GetAttackSpeed() const
{
	return CurrentWeapon != nullptr ? CurrentWeapon.GetDefaultObject()->WeaponInfo.AttackSpeed : 1.f;
}

FName UEquipmentComponent::GetMontageID() const
{	
	return CurrentWeapon != nullptr ? CurrentWeapon.GetDefaultObject()->WeaponInfo.MontageID : FName("NoWeapon");
}
//���� �Ӽ��ο�
void UEquipmentComponent::EnchantWeapon(UParticleSystem* EnchantParticle, UParticleSystem* Trail, UParticleSystem* Hiteffect, UParticleSystem* Slasheffect, FTransform transform, bool Active)
{	
	if (CurrentWeapon == nullptr) return;
	if (Active)
	{
		//Enchant
		if (CurrentEnchant != nullptr)
		{
			if (ParticleComp && ParticleComp->Template != nullptr)
				ParticleComp->DestroyComponent();
		}
		if (EnchantParticle)
		{
			CurrentEnchant = EnchantParticle->GetClass();
			ParticleComp = NewObject<UParticleSystemComponent>(this);
			ParticleComp->RegisterComponent();
			ParticleComp->SetTemplate(EnchantParticle);
			ParticleComp->Template = EnchantParticle;
			ParticleComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.SocketName);
			ParticleComp->SetRelativeLocationAndRotation(FVector(170.f, 0.f, 0.f), FRotator(0.f, -90.f, 0.f));
			ParticleComp->SetRelativeScale3D(FVector(0.4f, 1.2f, 0.4f));
		}
		
		//Trail
		if (Trail)
		{
			if (CurrentTrail != nullptr)
			{
				CurrentTrail = Trail->GetClass();
				if (WeaponTrailComp && ParticleComp->Template != nullptr)
				{
					WeaponTrailComp->SetTemplate(Trail);
					WeaponTrailComp->Template = Trail;
				}
			}
			else
			{
				CurrentTrail = Trail->GetClass();
				WeaponTrailComp = NewObject<UParticleSystemComponent>(this);
				WeaponTrailComp->RegisterComponent();
				WeaponTrailComp->AttachToComponent(OwnerCharacter->GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), CurrentWeapon.GetDefaultObject()->WeaponInfo.SocketName);
				WeaponTrailComp->SetTemplate(Trail);
				WeaponTrailComp->Template = Trail;
			}			
		}
		
		//Hit , Slash		
		HitEffect = Hiteffect;
		SlashEffect = Slasheffect;
		//timer
		GetWorld()->GetTimerManager().SetTimer(Enchanthandle, this, &UEquipmentComponent::DeactiveEnchant, 30.f, false);
		bIsEnchant = true;
	}
	else
	{		
		DeactiveEnchant();
	}
	if (GetOwner()->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()))
		ICombatInterface::Execute_CallResetAttack(GetOwner());
}
//��þƮ ����
void UEquipmentComponent::DeactiveEnchant()
{
	if (CurrentEnchant != nullptr)
	{
		if (ParticleComp)
			ParticleComp->DestroyComponent();
		CurrentEnchant = nullptr;
		ParticleComp->Template = nullptr;
		CurrentTrail = DefaultTrail->GetClass();
		WeaponTrailComp->Template = DefaultTrail;
		WeaponTrailComp->SetTemplate(DefaultTrail);
		HitEffect = nullptr;
		SlashEffect = nullptr;
	}	
	GetWorld()->GetTimerManager().ClearTimer(Enchanthandle);
	bIsEnchant = false;
}