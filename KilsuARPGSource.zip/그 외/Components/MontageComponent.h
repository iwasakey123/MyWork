// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "KilsuARPG/Data/Struct/FMontages.h"
#include "Engine/DataTable.h"
#include "MontageComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API UMontageComponent : public UActorComponent
{
	GENERATED_BODY()

protected:
	UPROPERTY() class ACharacter* Owner;
	//virtual void BeginPlay() override;
public:	
	UMontageComponent();
	
	UPROPERTY(EditAnywhere) UDataTable* MontageTable;
	UPROPERTY(EditAnywhere) FName MontageID;
	UPROPERTY() int32 Count;

	FORCEINLINE FName GetMontageID() { return MontageID; }
	FORCEINLINE void SetMontageID(FName MontageName) { MontageID = MontageName; }
	FORCEINLINE FMontages& GetMontages()
	{
		FString Context = TEXT("Can't Find MontageDT");
		return *(MontageTable->FindRow<FMontages>(MontageID, Context));
	}
	
	UFUNCTION(BlueprintCallable) void InitializeMontageTable(UDataTable* Table);
	UFUNCTION() float PlayMontage(EMontageType MontageType);
	UFUNCTION() float PlayMontages(TArray<UAnimMontage*>Montages, float PlaySpeed);
	UFUNCTION() float PlayCustomAttacks(float PlaySpeed);
	UPROPERTY() int32 CustomCount;
	UFUNCTION() float PlayMontage_Skill(FName SkillName, float PlaySpeed = 1.f);
};
