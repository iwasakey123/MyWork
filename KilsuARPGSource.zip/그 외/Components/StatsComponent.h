// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "KilsuARPG/Data/Struct/FStat.h"
#include "KilsuARPG/Data/Struct/FDamage.h"
#include "StatsComponent.generated.h"

class ACharacter;
DECLARE_DELEGATE(FUpdateStatUI);
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API UStatsComponent : public UActorComponent
{
	GENERATED_BODY()

protected:
	virtual void BeginPlay() override;
	UPROPERTY() ACharacter* OwnerCharacter;
public:	
	UStatsComponent();
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UPROPERTY(EditAnywhere) FStat HP;
	UPROPERTY(EditAnywhere) FStat MP;
	UPROPERTY(EditAnywhere) FStat Stamina;
	UPROPERTY(EditAnywhere) FStat STR;
	UPROPERTY(EditAnywhere) FStat INT;
	UPROPERTY(EditAnywhere) FStat ATT;
	UPROPERTY(EditAnywhere) FStat MTT;
	UPROPERTY(EditAnywhere) FStat A_DEF;
	UPROPERTY(EditAnywhere) FStat M_DEF;

	UPROPERTY(EditAnywhere) float CritChance;
	UPROPERTY(EditAnywhere) float CritDamage;
	
	UPROPERTY(EditAnywhere) float MinDamage;
	UPROPERTY(EditAnywhere) float MaxDamage;
	//UPROPERTY(EditAnywhere) FDamage Damage;

	UPROPERTY() bool bStopStaminaGage;
	UPROPERTY() FTimerHandle StaminaTimerHandle;
	UFUNCTION() void StaminaUpTimerFunc();
	UFUNCTION() void StaminaStopTimerFunc();

	//UFUNCTION() void InitializeStat(FStat hp, FStat stamina);
	UFUNCTION() FDamage MakeDamage(EDamageType DamageType);

	//bind
	FUpdateStatUI UpdateStatUI;
	DECLARE_EVENT(ACharactor, FDie) FDie Die;
	DECLARE_EVENT(ACharactor, FSetSaveMoveSpeed) FSetSaveMoveSpeed SetSaveMoveSpeed;
	UFUNCTION() void UpdateStat(TMap<EStat, float> UpdateStat, bool UpDown);	

	UFUNCTION() void Damaged(FDamage Damage);
	UFUNCTION() void UpdateHPMPST(EStat StatType, float value, bool UpDown);
};
