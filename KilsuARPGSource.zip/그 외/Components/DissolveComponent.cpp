// Fill out your copyright notice in the Description page of Project Settings.


#include "DissolveComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

UDissolveComponent::UDissolveComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	
	DissolveColorName = FName("color");
	DissolveValueName = FName("amount");
	DissolveColor = FLinearColor(5.f, 0.f, 0.f, 0.f);
	DissolveSpeed = 0.7f;

	static ConstructorHelpers::FObjectFinder<UMaterialInstance>MatOb(TEXT("MaterialInstanceConstant'/Game/Reource_AddNew/Materials/MI_DissolveEffect.MI_DissolveEffect'"));
	if (MatOb.Succeeded())
		DissolveMat = MatOb.Object;
}

void UDissolveComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (bStartDissolve)
	{
		DissolveComps();		
	}
}

void UDissolveComponent::StartDissolve(UPrimitiveComponent* Comp, bool Reverse)
{
	int32 idx = -1;
	if (IsValid(Comp))
	{
		for (int32 i = 0; i < DComps.Num(); i++)
		{
			if (DComps[i].Comp == Comp)
			{
				idx = i;
				break;
			}
		}
	}
	if (idx >= 0)
	{
		DComps[idx].bReverse = Reverse;
		DComps[idx].bRunning = true;
		bStartDissolve = true;
	}
	else
	{
		TArray<UMaterialInterface*> L_Mats;
		TArray<UMaterialInstanceDynamic*>L_DissolveMats;
		if (IsValid(Comp))
		{
			for (int32 i = 0; i <= Comp->GetNumMaterials() - 1; i++)
			{
				L_Mats.Add(Comp->GetMaterial(i));
				auto L_dmat = Comp->CreateDynamicMaterialInstance(i, DissolveMat);
				L_dmat->SetVectorParameterValue(DissolveColorName, DissolveColor);
				L_DissolveMats.Add(L_dmat);

				FDissolveComp DissolveComp;
				DissolveComp.Comp = Comp;
				DissolveComp.Value = Reverse;
				DissolveComp.Materials = L_Mats;
				DissolveComp.DissolveMats = L_DissolveMats;
				DissolveComp.bRunning = true;
				DissolveComp.bReverse = Reverse;
				DComps.Add(DissolveComp);
				bStartDissolve = true;
			}
		}
	}
}
void UDissolveComponent::StopDissolve(UPrimitiveComponent* Comp)
{
	int32 idx = -1;
	for (int32 i = 0; i < DComps.Num(); i++)
	{
		if (DComps[i].Comp == Comp)
		{
			idx = 1;
			break;
		}
	}
	if (idx >= 0)
	{
		DComps[idx].bRunning = false;
		//bStartDissolve = false;
	}
}
void UDissolveComponent::DissolveComps()
{
	for (int32 i = 0; i <= DComps.Num()-1; i++)
	{
		if (IsValid(DComps[i].Comp))
		{
			if (DComps[i].bRunning)
			{
				float value = UKismetMathLibrary::FInterpTo_Constant(DComps[i].Value, !DComps[i].bReverse, UGameplayStatics::GetWorldDeltaSeconds(GetWorld()), DissolveSpeed);
				DComps[i].Value = value;
				if (UKismetMathLibrary::NearlyEqual_FloatFloat(value, !DComps[i].bReverse, 0.0001f))
				{
					if (DComps[i].bReverse)
					{
						for (int32 j = 0; j < DComps[i].Comp->GetNumMaterials() - 1; j++)
						{
							DComps[i].Comp->SetMaterial(j, DComps[i].Materials[j]);
						}
						FinishDissolve.Broadcast(DComps[i].bReverse);	
						bKeepDissolve = true;
						DComps.RemoveAt(i);						
					}
					else
					{
						DComps[i].bRunning = false;
						//bKeepDissolve = false;
						FinishDissolve.Broadcast(DComps[i].bReverse);
					}
				}
				else
				{
					bKeepDissolve = true;
					for (auto DMat : DComps[i].DissolveMats)
					{
						DMat->SetScalarParameterValue(DissolveValueName, value);							
					}
				}
			}
		}
		else
			DComps.RemoveAt(i);
	}	
	bStartDissolve = bKeepDissolve;
}