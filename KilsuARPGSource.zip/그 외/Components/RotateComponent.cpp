// Fill out your copyright notice in the Description page of Project Settings.

#include "RotateComponent.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"

URotateComponent::URotateComponent()
{
	PrimaryComponentTick.bCanEverTick = true;	
}

void URotateComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (bShouldRotate == true)
	{
		ElapsedTime += DeltaTime;
		if (ElapsedTime > RotateTime)
			bShouldRotate = false;
		else
		{
			FRotator NewRotation = FMath::RInterpConstantTo(GetOwner()->GetActorRotation(), ICombatInterface::Execute_GetDesiredRotation(GetOwner()), UGameplayStatics::GetWorldDeltaSeconds(GetWorld()), MaxDegreesPerSeconds);
			GetOwner()->SetActorRotation(NewRotation);
		}
	}
}

//Rotation Func
void URotateComponent::StartRotateWithTime(float _RotateTime, float _MaxDegreesPerSeconds)
{
	RotateTime = _RotateTime;
	MaxDegreesPerSeconds = _MaxDegreesPerSeconds;
	ElapsedTime = 0.f;
	bShouldRotate = true;
}
void URotateComponent::StopRotate()
{
	bShouldRotate = false;
	bInputRotate = false;
}
void URotateComponent::StartInputRotation(float MaxPossibleRotation, float _MaxDegreesPerSeconds)
{
	MaxDegreesPerSeconds = _MaxDegreesPerSeconds;
	RotateTime = MaxPossibleRotation / MaxDegreesPerSeconds;
	ElapsedTime = 0.f;
	bInputRotate = true;
}
void URotateComponent::InputRotation()
{
	auto OwnerCharacter = Cast<ACharacter>(GetOwner());
	FRotator TargetRot = (OwnerCharacter->GetLastMovementInputVector() != FVector::ZeroVector) ? UKismetMathLibrary::MakeRotFromX(OwnerCharacter->GetLastMovementInputVector()) : GetOwner()->GetActorRotation();
	FRotator InputRot = FMath::RInterpConstantTo(GetOwner()->GetActorRotation(), TargetRot, UGameplayStatics::GetWorldDeltaSeconds(GetWorld()), 540.f);
	GetOwner()->SetActorRotation(InputRot);
}

