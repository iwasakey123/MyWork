// Fill out your copyright notice in the Description page of Project Settings.


#include "StatsComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"

UStatsComponent::UStatsComponent()
{
	OwnerCharacter = Cast<ACharacter>(GetOwner());
	PrimaryComponentTick.bCanEverTick = true;
	//HP.StatType = EStat::HP;
	//HP.Max = 100.f;
	//HP.Current = HP.Max;
	//Stamina.StatType = EStat::Stamina;
	//Stamina.Max = 100.f;
	//Stamina.Current = Stamina.Max;
	//CritChance = 0.f;
	//CritDamage = 200.f;
}

void UStatsComponent::BeginPlay()
{
	Super::BeginPlay();

	auto EquipmentComp = GetOwner()->FindComponentByClass<UEquipmentComponent>();
	if (EquipmentComp)
		EquipmentComp->UpdateStats.BindUFunction(this, FName("UpdateStat"));
	UpdateStatUI.ExecuteIfBound();
}

void UStatsComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!bStopStaminaGage && Stamina.Current < Stamina.Max)
	{
		Stamina.Current += 0.7f;
		if (Stamina.Current >= Stamina.Max)
			Stamina.Current = Stamina.Max;		
	}
}

FDamage UStatsComponent::MakeDamage(EDamageType DamageType)
{
	FDamage LocalDamage;
	LocalDamage.DamageType = DamageType;
	if (DamageType != EDamageType::Heavy)
	{
		LocalDamage.bCanGuard = true;
		LocalDamage.bCanParry = true;
	}
	LocalDamage.bIsCrit = UKismetMathLibrary::RandomBoolWithWeight(CritChance / 100.f);
	float FDamage = FMath::FRandRange(ATT.Current - ATT.Current * 0.2f, ATT.Current + ATT.Current * 0.2f);
	LocalDamage.Damage = LocalDamage.bIsCrit ? FDamage * ((int32)CritDamage / 100) : FDamage;	
	return LocalDamage;
}

void UStatsComponent::UpdateStat(TMap<EStat, float> Stat, bool UpDown)
{
	if (Stat.Contains(EStat::HP))
		HP.Max = UpDown ? HP.Max + Stat.FindRef(EStat::HP) : HP.Max - Stat.FindRef(EStat::HP);			
	if (Stat.Contains(EStat::MP))
		MP.Max = UpDown ? MP.Max + Stat.FindRef(EStat::MP) : MP.Max - Stat.FindRef(EStat::MP);
	if (Stat.Contains(EStat::Stamina))
		Stamina.Max = UpDown ? Stamina.Max + Stat.FindRef(EStat::Stamina) : Stamina.Max - Stat.FindRef(EStat::Stamina);
	if (Stat.Contains(EStat::STR))
		STR.Current = UpDown ? STR.Current + Stat.FindRef(EStat::STR) : STR.Current - Stat.FindRef(EStat::STR);
	if (Stat.Contains(EStat::INT))											
		INT.Current = UpDown ? INT.Current + Stat.FindRef(EStat::INT) : INT.Current - Stat.FindRef(EStat::INT);
	if (Stat.Contains(EStat::ATT))								
		ATT.Current = UpDown ? ATT.Current + Stat.FindRef(EStat::ATT) : ATT.Current - Stat.FindRef(EStat::ATT);
	if (Stat.Contains(EStat::MTT))							
		MTT.Current = UpDown ? MTT.Current + Stat.FindRef(EStat::MTT) : MTT.Current - Stat.FindRef(EStat::MTT);
	if (Stat.Contains(EStat::CritChance))
		CritChance = UpDown ? CritChance + Stat.FindRef(EStat::CritChance) : CritChance - Stat.FindRef(EStat::CritChance);
	if (Stat.Contains(EStat::CritDamage))
		CritDamage = UpDown ? CritDamage + Stat.FindRef(EStat::CritDamage) : CritDamage - Stat.FindRef(EStat::CritDamage);
	if (Stat.Contains(EStat::MoveSpeed))
	{		
		UpDown ? OwnerCharacter->GetCharacterMovement()->MaxWalkSpeed += Stat.FindRef(EStat::MoveSpeed) : OwnerCharacter->GetCharacterMovement()->MaxWalkSpeed -= Stat.FindRef(EStat::MoveSpeed);
		SetSaveMoveSpeed.Broadcast();
	}
	if (Stat.Contains(EStat::A_DEF))
		A_DEF.Current = UpDown ? A_DEF.Current + Stat.FindRef(EStat::A_DEF) : A_DEF.Current - Stat.FindRef(EStat::A_DEF);
	if (Stat.Contains(EStat::M_DEF))
		M_DEF.Current = UpDown ? M_DEF.Current + Stat.FindRef(EStat::M_DEF) : M_DEF.Current - Stat.FindRef(EStat::M_DEF);

	if (HP.Max < HP.Current)
		HP.Current = HP.Max;
	if (MP.Max < MP.Current)
		MP.Current = MP.Max;
	if (Stamina.Max < Stamina.Current)
		Stamina.Current = Stamina.Max;

	UpdateStatUI.ExecuteIfBound();
}

void UStatsComponent::Damaged(FDamage Damage)
{
	if (Damage.DamageType == EDamageType::InstantDeath || Damage.Damage > HP.Current)
	{
		HP.Current = 0.f;
		Die.Broadcast();
		return;
	}
	HP.Current -= (Damage.Damage - A_DEF.Current);
}

void UStatsComponent::UpdateHPMPST(EStat StatType, float value, bool UpDown)
{
	switch (StatType)
	{
	case EStat::HP:
		if (UpDown == true)
			HP.Current = (HP.Current + value) > HP.Max ? HP.Max : HP.Current + value;
		else
			HP.Current = (HP.Current - value) <= 0.f ? 0.f : HP.Current - value;
		break;
	case EStat::MP:
		if(UpDown == true)
			MP.Current = (MP.Current + value) > MP.Max ? MP.Max : MP.Current + value;
		else
			MP.Current = (MP.Current - value) <= 0.f ? 0.f : MP.Current - value;
		break;
	case EStat::Stamina:
		if(UpDown == true)
			Stamina.Current = (Stamina.Current + value) > Stamina.Max ? Stamina.Max : Stamina.Current + value;
		else
			Stamina.Current = (Stamina.Current - value) <= 0.f ? 0.f : Stamina.Current - value;
		break;
	}
}

void UStatsComponent::StaminaUpTimerFunc()
{
	bStopStaminaGage = true;
	if(GetWorld()->GetTimerManager().IsTimerActive(StaminaTimerHandle))
		GetWorld()->GetTimerManager().ClearTimer(StaminaTimerHandle);
	GetWorld()->GetTimerManager().SetTimer(StaminaTimerHandle, FTimerDelegate::CreateLambda([&]() {
		bStopStaminaGage = false;
	}), 1.f, false);
}

void UStatsComponent::StaminaStopTimerFunc()
{
	bStopStaminaGage = true;
	if (GetWorld()->GetTimerManager().IsTimerActive(StaminaTimerHandle))
		GetWorld()->GetTimerManager().ClearTimer(StaminaTimerHandle);
}
