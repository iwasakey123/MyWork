// Fill out your copyright notice in the Description page of Project Settings.


#include "InteractComponent.h"
#include "Camera/CameraComponent.h"
#include "KilsuARPG/Characters/PlayerCharacter.h"
#include "KilsuARPG/Interactables/Interactable.h"
#include "KilsuARPG/Item/Item.h"

UInteractComponent::UInteractComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	Player = Cast<APlayerCharacter>(GetOwner());
}

void UInteractComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (Interactables.Num() > 0)
		GetBestInteractable();
	else
		SetBestInteractable(nullptr);

}
//InteractInterface::RegisterInteractable
void UInteractComponent::RegisterInteractable_Implementation(AInteractable* Interactable)
{
	Interactables.AddUnique(Interactable);
}
//InteractInterface::UnRegisterInteractable
void UInteractComponent::UnRegisterInteractable_Implementation(AInteractable* Interactable)
{
	Interactables.Remove(Interactable);
}

void UInteractComponent::GetBestInteractable()
{
	float Dot = -1;
	AInteractable* BestInteractable = nullptr;
	for (AInteractable* Interactable : Interactables)
	{
		if (Interactable && Player)
		{
			auto Cam = Player->GetCamera();
			auto CenterOfMass = Interactable->GetDisplayMesh()->GetCenterOfMass();			
			auto CamLocation = Cam->GetComponentLocation();
			auto CamForward = Cam->GetForwardVector();
			auto dot = FVector::DotProduct(FVector(CenterOfMass - CamLocation).GetSafeNormal(), CamForward);		
			if (dot > 0.8 && dot > Dot)
			{
				Dot = dot;
				BestInteractable = Interactable;
			}
		}
	}
	if (BestInteractable != nullptr)
		SetBestInteractable(BestInteractable);
	else
		SetBestInteractable(nullptr);
}
void UInteractComponent::SetBestInteractable(AInteractable* Interactable)
{
	if (Interactable != nullptr)
	{		
		if(SelectInteractable != nullptr && SelectInteractable != Interactable)
			SelectInteractable->SetHighlight(false);
		SelectInteractable = Interactable;
		SelectInteractable->SetHighlight(true);
	}
	else
	{
		if (SelectInteractable != nullptr)
		{
			SelectInteractable->SetHighlight(false);
			SelectInteractable = nullptr;	
		}		
	}
}

void UInteractComponent::Interaction()
{
	if (SelectInteractable != nullptr)
	{
		SelectInteractable->Interaction(GetOwner());
	}
}

