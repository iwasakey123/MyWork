// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "KilsuARPG/Data/Enum/EItem.h"
#include "KilsuARPG/Data/Enum/EStat.h"
#include "EquipmentComponent.generated.h"

class AWeapon;
class AArmor;
typedef TMap<EStat, float> FStatTMap; //��� ���� ������ �����ϴ� TMap��������
DECLARE_DELEGATE_TwoParams(FUpdateStats, FStatTMap, bool); 
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API UEquipmentComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UEquipmentComponent();

protected:
	UPROPERTY() class ACharacter* OwnerCharacter;

	UPROPERTY() TSubclassOf<AWeapon> CurrentWeapon = nullptr;	
	UPROPERTY() TSubclassOf<AArmor> CurrentHead = nullptr;
	UPROPERTY() TSubclassOf<AArmor> CurrentUpper = nullptr;
	UPROPERTY() TSubclassOf<AArmor> CurrentLower = nullptr;
	UPROPERTY() TSubclassOf<AArmor> CurrentShoes = nullptr;
	UPROPERTY() TSubclassOf<AArmor> CurrentHand = nullptr;
	UPROPERTY() TSubclassOf<AArmor> CurrentCape = nullptr;
	UPROPERTY() TSubclassOf<class UParticleSystem> CurrentEnchant = nullptr;
	UPROPERTY() TSubclassOf<UParticleSystem> CurrentTrail = nullptr;
	UPROPERTY() TSubclassOf<UParticleSystem> CurrentHitEffect = nullptr;
	UPROPERTY() TSubclassOf<UParticleSystem> CurrentSlashEffect = nullptr;

public:	
	//��� Component
	UPROPERTY() UStaticMeshComponent* MainWeaponComp;
	UPROPERTY() UStaticMeshComponent* SubWeaponComp;
	UPROPERTY() USkeletalMeshComponent* HeadComp;
	UPROPERTY() USkeletalMeshComponent* UpperComp;
	UPROPERTY() USkeletalMeshComponent* LowerComp;
	UPROPERTY() USkeletalMeshComponent* ShoesComp;
	UPROPERTY() USkeletalMeshComponent* HandComp;
	UPROPERTY() USkeletalMeshComponent* CapeComp;

	DECLARE_EVENT_FourParams(ACharacter, FUpdateMeshRender, EEquipmentType, FName, class UStaticMesh*, class USkeletalMesh*) FUpdateMeshRender UpdatingMeshRender;
	DECLARE_EVENT_TwoParams(ACharacter, FUpdateEquipmentUI, TSubclassOf<class AItem>, EEquipmentType) FUpdateEquipmentUI UpdateEquipmentUI;	
	FUpdateStats UpdateStats;

	//���
	UFUNCTION() void EquipWeapon(TSubclassOf<AWeapon>WeaponClass = nullptr, bool bAutoUnEquip = true);
	UFUNCTION() bool UnEquipWeapon();
	UFUNCTION() void EquipArmor(TSubclassOf<AArmor>ArmorClass = nullptr);
	UFUNCTION() bool UnEquipArmor(EArmorType ArmorType);
	UFUNCTION() void ArmWeapon();
	UFUNCTION() void UnArmWeapon();
	UFUNCTION() void EnchantWeapon(class UParticleSystem* EnchantParticle, UParticleSystem* Trail, UParticleSystem* HitEffect, UParticleSystem* SlashEffect, FTransform transform, bool Active = true);
	UFUNCTION() void DeactiveEnchant();
	
	//��þƮ
	UPROPERTY(BlueprintReadWrite) FTimerHandle Enchanthandle;
	UPROPERTY(BlueprintReadOnly) bool bIsEnchant;

	//inline�Լ��� �������� ��ġ���ʰ� ������ �����ɴϴ�.
	FORCEINLINE TSubclassOf<AWeapon> GetCurrentWeapon() { return CurrentWeapon; }
	FORCEINLINE TSubclassOf<AArmor>GetCurrentHead() { return CurrentHead; }
	FORCEINLINE TSubclassOf<AArmor>GetCurrentUpper() { return CurrentUpper; }
	FORCEINLINE TSubclassOf<AArmor>GetCurrentLower() { return CurrentLower; }
	FORCEINLINE TSubclassOf<AArmor>GetCurrentHand() { return CurrentHand; }
	FORCEINLINE TSubclassOf<AArmor>GetCurrentShoes() { return CurrentShoes; }
	FORCEINLINE TSubclassOf<AArmor>GetCurrentCape() { return CurrentCape; }
	FORCEINLINE TSubclassOf<UParticleSystem>GetCurrentEnchant() { return CurrentEnchant; }
	FORCEINLINE TSubclassOf<UParticleSystem>GetCurrentTrail() { return CurrentTrail; }
	FORCEINLINE TSubclassOf<UParticleSystem>GetCurrentHitEffect() { return CurrentHitEffect; }
	FORCEINLINE TSubclassOf<UParticleSystem>GetCurrentSlashEffect() { return CurrentSlashEffect; }

	UFUNCTION() EWeaponType GetCurrentWeaponType();
	UFUNCTION() float GetAttackSpeed() const;
	UFUNCTION() FName GetMontageID() const;

	//���� �⺻ ����Ʈ
	UPROPERTY() class UParticleSystemComponent* ParticleComp = nullptr;
	UPROPERTY() UParticleSystemComponent* WeaponTrailComp = nullptr;
	UPROPERTY() UParticleSystem* DefaultTrail = nullptr;
	UPROPERTY() UParticleSystem* HitEffect = nullptr;
	UPROPERTY() UParticleSystem* SlashEffect = nullptr;
};
