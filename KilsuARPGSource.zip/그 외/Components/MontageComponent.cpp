// Fill out your copyright notice in the Description page of Project Settings.


#include "MontageComponent.h"
#include "Animation/AnimMontage.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"

UMontageComponent::UMontageComponent()
{
	//PrimaryComponentTick.bCanEverTick = true;
	Owner = Cast<ACharacter>(GetOwner());
	MontageID = FName("NoWeapon");
	Count = 0;	
}

void UMontageComponent::InitializeMontageTable(UDataTable* Table)
{
	if (IsValid(Table))
		MontageTable = Table;
}

float UMontageComponent::PlayMontage(EMontageType MontageType)
{	
	float PlaySpeed = (GetOwner() && GetOwner()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true) ? IStateInterface::Execute_GetAttackSpeed(GetOwner()) : 1.f;

	switch (MontageType)
	{
	case EMontageType::CombatOn:
		return Owner->PlayAnimMontage(GetMontages().CombatOn, 1.f);
	case EMontageType::CombatOff:
		return Owner->PlayAnimMontage(GetMontages().CombatOff, 1.f);
	case EMontageType::DefaultAttack:
		return PlayMontages(GetMontages().DefaultAttack, PlaySpeed);
	case EMontageType::HeavyAttack:	
		if (Count <= 1 && GetMontages().HeavyAttack.Num() > 0)
			return Owner->PlayAnimMontage(GetMontages().HeavyAttack[0], PlaySpeed);
		else if (Count == 2 && GetMontages().HeavyAttack.Num() > 1)
			return Owner->PlayAnimMontage(GetMontages().HeavyAttack[1], PlaySpeed + 0.5f);
		else if (Count == 3 && GetMontages().HeavyAttack.Num() > 2)
			return Owner->PlayAnimMontage(GetMontages().HeavyAttack[2], PlaySpeed - 0.1f);
		else break;
	case EMontageType::SpecialAttack:
		if (GetMontages().SpecialAttack.Num() > 0)
			return Owner->PlayAnimMontage(GetMontages().SpecialAttack[0], 1.f);
	case EMontageType::Rolling_NT:
		return Owner->PlayAnimMontage(GetMontages().Rolling_NT, PlaySpeed);
	case EMontageType::Rolling_F:
		return Owner->PlayAnimMontage(GetMontages().Rolling_F, PlaySpeed);
	case EMontageType::Rolling_B:
		return Owner->PlayAnimMontage(GetMontages().Rolling_B, PlaySpeed);
	case EMontageType::Rolling_L:
		return Owner->PlayAnimMontage(GetMontages().Rolling_L, PlaySpeed);
	case EMontageType::Rooling_R:
		return Owner->PlayAnimMontage(GetMontages().Rooling_R, PlaySpeed);
	case EMontageType::Slide_NT:
		return Owner->PlayAnimMontage(GetMontages().Slide_NT, 1.f);
	case EMontageType::Slide_F:
		return Owner->PlayAnimMontage(GetMontages().Slide_F, 1.f);
	case EMontageType::Slide_B:
		return Owner->PlayAnimMontage(GetMontages().Slide_B, 1.f);
	case EMontageType::Slide_L:
		return Owner->PlayAnimMontage(GetMontages().Slide_L, 1.f);
	case EMontageType::Slide_R:
		return Owner->PlayAnimMontage(GetMontages().Slide_R, 1.f);
	case EMontageType::Guard:
		return Owner->PlayAnimMontage(GetMontages().Guard, 1.f);
	case EMontageType::GuardSuccess:
		return Owner->PlayAnimMontage(GetMontages().GuardSuccess, 1.f);
	case EMontageType::GuardBreak:
		return Owner->PlayAnimMontage(GetMontages().GuardBreak, 1.f);
	case EMontageType::Parry:
		return Owner->PlayAnimMontage(GetMontages().Parry, PlaySpeed);
	case EMontageType::Execution:
		return Owner->PlayAnimMontage(GetMontages().Execution, 1.f);
	case EMontageType::Executed:
		return Owner->PlayAnimMontage(GetMontages().Executed, 1.f);
	case EMontageType::Damaged:
		return Owner->PlayAnimMontage(GetMontages().Damaged, 1.f);
	case EMontageType::HeavyDamaged:
		return Owner->PlayAnimMontage(GetMontages().HeavyDamaged, 1.f);
	case EMontageType::TakeDown:
		return Owner->PlayAnimMontage(GetMontages().TakeDown, 1.f);
	case EMontageType::Drink:
		return Owner->PlayAnimMontage(GetMontages().Drink, 1.5f);
	case EMontageType::Die:
		return Owner->PlayAnimMontage(GetMontages().Die, 0.7f);
	case EMontageType::CustomAttack:
		if (GetMontages().CustomAttack.Num() > 0)
			return PlayCustomAttacks(1.f);
	}
	return 0.f;
}

float UMontageComponent::PlayMontages(TArray<UAnimMontage*>Montages, float PlaySpeed)
{
	if (Montages.Num() > 0)
	{
		if (Count >= Montages.Num())
			Count = 0;
		return Owner->PlayAnimMontage(Montages[Count++], PlaySpeed);
	}
	return 0.f;
}

float UMontageComponent::PlayCustomAttacks(float PlaySpeed)
{
	if (GetMontages().CustomAttack.Num() > 0)
	{
		if (CustomCount >= GetMontages().CustomAttack.Num())
			CustomCount = 0;
		return Owner->PlayAnimMontage(GetMontages().CustomAttack[CustomCount++], PlaySpeed);
	}
	return 0.f;
}

float UMontageComponent::PlayMontage_Skill(FName SkillName, float PlaySpeed)
{
	if (GetMontages().Skills.Num() > 0)
	{
		auto SkillMontage = GetMontages().Skills.FindRef(SkillName);
		if (SkillMontage)
		{
			return Owner->PlayAnimMontage(SkillMontage, PlaySpeed);
		}
	}
	return 0.f;
}