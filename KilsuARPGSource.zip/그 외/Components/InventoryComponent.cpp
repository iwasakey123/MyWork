// Fill out your copyright notice in the Description page of Project Settings.

#include "InventoryComponent.h"
#include "KilsuARPG/Data/Interface/UIInterface.h"
#include "KilsuARPG/Item/Item.h"
#define nullidx -1

UInventoryComponent::UInventoryComponent()
{
	SlotAmount = 40;
	InventoryItems.SetNum(SlotAmount);	
	MaxStackSize = 100;
	Gold = 15000;
	MaxGold = 1000000000;

	Hidden_InventoryItems.Empty();
	Temp_InventoryItems.Empty();
}

//Inventory
bool UInventoryComponent::IsSlotEmpty(int32 idx)
{
	return (InventoryItems[idx].ItemClass == nullptr) ? true : false;
}
int32 UInventoryComponent::FindEmptyidx()
{
	for (int32 i = 0; i < SlotAmount; i++)
	{
		if (InventoryItems[i].ItemClass == nullptr)
			return i;
	}
	return nullidx;
}
int32 UInventoryComponent::FindStackidx(TSubclassOf<AItem>ItemClass)
{
	for (int32 i = 0; i < SlotAmount; i++)
	{
		if (IsSlotEmpty(i) == false && ItemClass == InventoryItems[i].ItemClass && InventoryItems[i].Amount != MaxStackSize)
		{
			return i;
		}
	}
	return nullidx;
}
int32 UInventoryComponent::AddItem(TSubclassOf<class AItem>ItemClass, int32 Amount)
{
	if (ItemClass == nullptr)
		return Amount;

	int32 Rest = 0;
	int32 idx = nullidx;

	if (ItemClass.GetDefaultObject()->ItemInfo.CanStack == true)
	{
		idx = FindStackidx(ItemClass);
		if (idx != nullidx)
		{
			int32 localAmount = GetAmountAtidx(idx) + Amount;
			if (localAmount > MaxStackSize)
			{				
				InventoryItems[idx].ItemClass = ItemClass;
				InventoryItems[idx].Amount = MaxStackSize;
				UpdateInventoryUI.Broadcast();				
				return AddItem(ItemClass, localAmount - MaxStackSize);				
			}
			else
			{
				InventoryItems[idx].ItemClass = ItemClass;
				InventoryItems[idx].Amount = localAmount;
				UpdateInventoryUI.Broadcast();
				return 0;
			}
		}
		else
		{
			idx = FindEmptyidx();
			if (idx != nullidx)
			{
				if (Amount > MaxStackSize)
				{
					InventoryItems[idx].ItemClass = ItemClass;
					InventoryItems[idx].Amount = MaxStackSize;
					UpdateInventoryUI.Broadcast();
					return AddItem(ItemClass, Amount - MaxStackSize);
				}
				else
				{
					InventoryItems[idx].ItemClass = ItemClass;
					InventoryItems[idx].Amount += Amount;
					UpdateInventoryUI.Broadcast();
					return 0;
				}
			}
			else return Amount;
		}
	}
	else
	{
		idx = FindEmptyidx();
		if (idx != nullidx)
		{
			InventoryItems[idx].ItemClass = ItemClass;
			InventoryItems[idx].Amount += 1;
			if (Amount > 1)
				return AddItem(ItemClass, Amount - 1);
			else
			{
				UpdateInventoryUI.Broadcast();
				return 0;
			}
		}
		else;
	}
	return Amount;
}
bool UInventoryComponent::RemoveItem(int32 idx, int32 Amount)
{
	if (GetItemClassAtidx(idx) != nullptr)
	{
		if (InventoryItems[idx].Amount - Amount <= 0)
		{
			InventoryItems[idx].ItemClass = nullptr;
			InventoryItems[idx].Amount = 0;
			UpdateInventoryUI.Broadcast();
			return true;
		}
		else
		{
			InventoryItems[idx].Amount -= Amount;
			UpdateInventoryUI.Broadcast();
			return true;
		}
	}
	return false;
}
void UInventoryComponent::UseItemAtidx(int32 idx, int32 Amount)
{
	if (GetItemClassAtidx(idx) != nullptr)
	{
		FActorSpawnParameters SpawnInfo;
		SpawnInfo.Owner = GetOwner();
		SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		FTransform transform = FTransform(FRotator(0.f), FVector(45640.f, 19116.f, 100000.f), ((FVector)(0.f)));
		auto SpawnItem = GetWorld()->SpawnActor<AItem>(GetItemClassAtidx(idx), transform, SpawnInfo);	
		if (SpawnItem)
		{
			RemoveItem(idx, Amount);
			SpawnItem->Use();			
		}
	}
}

void UInventoryComponent::DragSlotByInventory(int32 From_idx, int32 To_idx)
{
	if (InventoryItems[From_idx].ItemClass != nullptr && InventoryItems[From_idx].ItemClass == InventoryItems[To_idx].ItemClass && GetAmountAtidx(From_idx) != MaxStackSize && GetAmountAtidx(To_idx) != MaxStackSize)
	{
		if (GetAmountAtidx(From_idx) + GetAmountAtidx(To_idx) > MaxStackSize)
		{
			InventoryItems[To_idx].Amount = MaxStackSize;			
			InventoryItems[From_idx].Amount = GetAmountAtidx(From_idx) + GetAmountAtidx(To_idx) - MaxStackSize;
			UpdateInventoryUI.Broadcast();
			return;
		}
		else
		{
			InventoryItems[To_idx].Amount = GetAmountAtidx(From_idx) + GetAmountAtidx(To_idx);
			InventoryItems[From_idx].ItemClass = nullptr;
			InventoryItems[From_idx].Amount = 0;
			UpdateInventoryUI.Broadcast();
			return;
		}
	}
	else
	{
		InventoryItems.Swap(From_idx, To_idx);
		UpdateInventoryUI.Broadcast();
	}
}

bool UInventoryComponent::AddItemAtidx(int32 idx, TSubclassOf<AItem> ItemClass, int32 Amount)
{
	if (IsSlotEmpty(idx) == true)
	{		
		InventoryItems[idx].ItemClass = ItemClass;
		InventoryItems[idx].Amount = Amount;
		UpdateInventoryUI.Broadcast();
		return true;
	}
	else
	{
		return false;
	}
}

void UInventoryComponent::Sort(EItemType ItemType)
{
	switch (ItemType)
	{
	case EItemType::Weapon:
		Sort_Weapon();
		break;
	case EItemType::Armor:
		Sort_Armor();
		break;
	case EItemType::Consumable:
		Sort_Consumable();
		break;
	case EItemType::Quest:
		Sort_Quest();
		break;
	case EItemType::ETC:
		Sort_ETC();
		break;
	default:
		Sort_All();
		break;
	}
}

void UInventoryComponent::Sort_All()
{
	Temp_InventoryItems.Empty();
	for (int32 i = 0; i < SlotAmount; i++)
	{
		if (InventoryItems[i].ItemClass != nullptr)
		{
			Temp_InventoryItems.Add(InventoryItems[i]);
			InventoryItems[i].ItemClass = nullptr;
			InventoryItems[i].Amount = 0;
		}
	}

	if (Hidden_InventoryItems.Num() > 0)
	{
		for (int32 i = 0; i < Hidden_InventoryItems.Num(); i++)
		{
			if(Hidden_InventoryItems[i].ItemClass != nullptr)
				Temp_InventoryItems.Add(Hidden_InventoryItems[i]);
		}
	}
	
	for (int32 i = 0; i < Temp_InventoryItems.Num(); i++)
	{
		InventoryItems[i].ItemClass = Temp_InventoryItems[i].ItemClass;
		InventoryItems[i].Amount = Temp_InventoryItems[i].Amount;
	}
	Hidden_InventoryItems.Empty();
	UpdateInventoryUI.Broadcast();
}

void UInventoryComponent::Sort_Weapon()
{	
	Temp_InventoryItems.Empty();
	for (int32 i = 0; i < SlotAmount; i++)
	{
		if (InventoryItems[i].ItemClass != nullptr && InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Weapon)
		{
			Temp_InventoryItems.Add(InventoryItems[i]);
		}
		else if (InventoryItems[i].ItemClass != nullptr && InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType != EItemType::Weapon)
			Hidden_InventoryItems.Add(InventoryItems[i]);
		InventoryItems[i].ItemClass = nullptr;
		InventoryItems[i].Amount = 0;
	}
	for (int32 i = 0; i < Hidden_InventoryItems.Num(); i++)
	{		
		if (Hidden_InventoryItems[i].ItemClass != nullptr && Hidden_InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Weapon)
		{
			Temp_InventoryItems.Add(Hidden_InventoryItems[i]);
			Hidden_InventoryItems[i].ItemClass = nullptr;
			Hidden_InventoryItems[i].Amount = 0;
		}
	}
	for (int32 i = 0; i < Temp_InventoryItems.Num(); i++)
	{		
		if (Temp_InventoryItems[i].ItemClass != nullptr)		
			InventoryItems[i] = Temp_InventoryItems[i];
	}
	UpdateInventoryUI.Broadcast();
}
void UInventoryComponent::Sort_Armor()
{
	Temp_InventoryItems.Empty();
	for (int32 i = 0; i < SlotAmount; i++)
	{
		if (InventoryItems[i].ItemClass != nullptr && InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Armor)
		{
			Temp_InventoryItems.Add(InventoryItems[i]);
		}
		else if (InventoryItems[i].ItemClass != nullptr && InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType != EItemType::Armor)
			Hidden_InventoryItems.Add(InventoryItems[i]);
		InventoryItems[i].ItemClass = nullptr;
		InventoryItems[i].Amount = 0;
	}
	for (int32 i = 0; i < Hidden_InventoryItems.Num(); i++)
	{
		if (Hidden_InventoryItems[i].ItemClass != nullptr && Hidden_InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Armor)
		{
			Temp_InventoryItems.Add(Hidden_InventoryItems[i]);
			Hidden_InventoryItems[i].ItemClass = nullptr;
			Hidden_InventoryItems[i].Amount = 0;
		}
	}
	for (int32 i = 0; i < Temp_InventoryItems.Num(); i++)
	{
		if (Temp_InventoryItems[i].ItemClass != nullptr)
			InventoryItems[i] = Temp_InventoryItems[i];
	}
	UpdateInventoryUI.Broadcast();
}
void UInventoryComponent::Sort_Consumable()
{
	Temp_InventoryItems.Empty();
	for (int32 i = 0; i < SlotAmount; i++)
	{
		if (InventoryItems[i].ItemClass != nullptr && InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Consumable)
		{
			Temp_InventoryItems.Add(InventoryItems[i]);
		}
		else if (InventoryItems[i].ItemClass != nullptr && InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType != EItemType::Consumable)
			Hidden_InventoryItems.Add(InventoryItems[i]);
		InventoryItems[i].ItemClass = nullptr;
		InventoryItems[i].Amount = 0;
	}
	for (int32 i = 0; i < Hidden_InventoryItems.Num(); i++)
	{
		if (Hidden_InventoryItems[i].ItemClass != nullptr && Hidden_InventoryItems[i].ItemClass.GetDefaultObject()->ItemInfo.ItemType == EItemType::Consumable)
		{
			Temp_InventoryItems.Add(Hidden_InventoryItems[i]);
			Hidden_InventoryItems[i].ItemClass = nullptr;
			Hidden_InventoryItems[i].Amount = 0;
		}
	}
	for (int32 i = 0; i < Temp_InventoryItems.Num(); i++)
	{
		if (Temp_InventoryItems[i].ItemClass != nullptr)
			InventoryItems[i] = Temp_InventoryItems[i];
	}
	UpdateInventoryUI.Broadcast();
}
void UInventoryComponent::Sort_Quest()
{

}
void UInventoryComponent::Sort_ETC()
{

}

//Gold
void UInventoryComponent::AddGold(int32 money)
{
	Gold += money;
	if (Gold > MaxGold)
		Gold = MaxGold;
}
void UInventoryComponent::DrawOffGold(int32 money)
{
	Gold -= money;
	if (Gold < 0)
		Gold = 0;
}
