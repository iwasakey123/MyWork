// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "RotateComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API URotateComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	URotateComponent();

private:
	//Rotate Variables
	UPROPERTY() bool bShouldRotate;
	UPROPERTY() bool bInputRotate;
	UPROPERTY() float MaxDegreesPerSeconds;
	UPROPERTY() float ElapsedTime;
	UPROPERTY() float RotateTime;

public:	
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	//Rotate Functions
	UFUNCTION() void StartRotateWithTime(float _RotateTime, float _MaxDegreesPerSeconds);
	UFUNCTION() void StopRotate();
	UFUNCTION() void StartInputRotation(float MaxPossibleRotation, float _MaxDegreesPerSeconds);
	UFUNCTION() void InputRotation();
};
