// Fill out your copyright notice in the Description page of Project Settings.


#include "SkillComponent.h"
#include "KilsuARPG/Skill/SkillObject.h"
#include "KilsuARPG/Skill/FireEnchant.h"

USkillComponent::USkillComponent()
{
	//PrimaryComponentTick.bCanEverTick = true;

}

void USkillComponent::BeginPlay()
{
	Super::BeginPlay();
	auto FireEnch = LoadClass<AFireEnchant>(nullptr, TEXT("Class'/Script/KilsuARPG.FireEnchant'"));
	RegisterSkill(FireEnch);
}

void USkillComponent::RegisterSkill(TSubclassOf<ASkillObject> SkillClass)
{
	if (Skills.Num() > 0)
	{
		for (auto Skill : Skills)
			if (Skill.SkillClass == SkillClass) return;		
	}
	FSkillStat NewSkill;
	NewSkill.SkillClass = SkillClass;
	NewSkill.MaxSkillLevel = 20;
	Skills.Add(NewSkill);
}

void USkillComponent::UnRegisterSkill(int32 index)
{
	if (Skills.Num() - 1 >= index)
	{		
		Skills[index].SkillClass = nullptr;
		Skills[index].MaxSkillLevel = 0;
	}
}

void USkillComponent::UseSkillAtidx(int32 idx)
{
	if (Skills.Num() - 1 >= idx)
	{
		FActorSpawnParameters SpawnInfo;
		SpawnInfo.Owner = GetOwner();
		SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		auto SpawnSkill = GetWorld()->SpawnActor<ASkillObject>(Skills[idx].SkillClass, SpawnInfo);
		SpawnSkill->UseSkill();
	}
}
