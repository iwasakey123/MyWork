// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "KilsuARPG/Data/Interface/InteractInterface.h"
#include "InteractComponent.generated.h"

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API UInteractComponent : public UActorComponent, public IInteractInterface
{
	GENERATED_BODY()

public:	
	UInteractComponent();

public:	
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UPROPERTY() class APlayerCharacter* Player;
	UPROPERTY() TArray<class AInteractable*> Interactables;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly) AInteractable* SelectInteractable;
	
	UFUNCTION() void GetBestInteractable();
	UFUNCTION()	void SetBestInteractable(AInteractable* Interactable);

	UFUNCTION() void Interaction();

	//InteractInterface
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void RegisterInteractable(AInteractable* Interactable);
	virtual void RegisterInteractable_Implementation(AInteractable* Interactable) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void UnRegisterInteractable(AInteractable* Interactable);
	virtual void UnRegisterInteractable_Implementation(AInteractable* Interactable) override;
};
