// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "SkillComponent.generated.h"

USTRUCT()
struct FSkillStat
{
	GENERATED_BODY()
public:
	UPROPERTY() TSubclassOf<class ASkillObject>SkillClass;
	UPROPERTY() int32 MaxSkillLevel = 0;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API USkillComponent : public UActorComponent
{
	GENERATED_BODY()

protected:
	virtual void BeginPlay() override;
public:
	USkillComponent();	

	UPROPERTY() TArray<FSkillStat>Skills;
	UPROPERTY() int32 MaxSkillHave = 100;

	UFUNCTION() void RegisterSkill(TSubclassOf<ASkillObject> SkillClass);
	UFUNCTION() void UnRegisterSkill(int32 index);
	UFUNCTION() void UseSkillAtidx(int32 idx);
};
