// Fill out your copyright notice in the Description page of Project Settings.


#include "BTDecorator_BelowHP.h"
#include "GameFramework/Character.h"
#include "AIController.h"
#include "KilsuARPG/Components/StatsComponent.h"

bool UBTDecorator_BelowHP::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	Super::CalculateRawConditionValue(OwnerComp, NodeMemory);
	if (OwnerComp.GetAIOwner() == nullptr || OwnerComp.GetAIOwner()->GetPawn() == nullptr)
		return false;
	
	auto StatsComp = OwnerComp.GetAIOwner()->GetPawn()->FindComponentByClass<UStatsComponent>();
	if (StatsComp == nullptr) return false;	
	return StatsComp->HP.Current <= StatsComp->HP.Max * (RemainingPer * 0.01f) ? true : false;
}