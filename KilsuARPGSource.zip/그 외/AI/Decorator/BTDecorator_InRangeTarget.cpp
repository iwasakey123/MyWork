// Fill out your copyright notice in the Description page of Project Settings.


#include "BTDecorator_InRangeTarget.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "BehaviorTree/BlackboardComponent.h"

UBTDecorator_InRangeTarget::UBTDecorator_InRangeTarget()
{
	NodeName = TEXT("InRangeTarget");
}

bool UBTDecorator_InRangeTarget::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	Super::CalculateRawConditionValue(OwnerComp, NodeMemory);
	auto AC = Cast<AEnemyController>(OwnerComp.GetAIOwner());
	if (AC == nullptr)
		return false;
	
	AActor* Target = Cast<AActor>(AC->GetBlackboardComponent()->GetValueAsObject(AEnemyController::TargetKey));
	if (Target == nullptr)
		return false;
	float Distance = Target->GetDistanceTo(OwnerComp.GetAIOwner()->GetPawn());

	return (Distance >= MinRange && Distance <= MaxRange) ? true : false;
}