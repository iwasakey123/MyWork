// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTService.h"
#include "EnvironmentQuery/EnvQueryTypes.h"
#include "BTService_Strafe.generated.h"

UCLASS()
class KILSUARPG_API UBTService_Strafe : public UBTService
{
	GENERATED_BODY()

	virtual void OnBecomeRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory);
	virtual void OnCeaseRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory);
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds);
	
public:
	UBTService_Strafe();
	
	UPROPERTY(EditAnywhere) class UEnvQuery* EQS_StrafeLeft;
	UPROPERTY(EditAnywhere) UEnvQuery* EQS_StrafeRight;
	//UPROPERTY(EditAnywhere) FBlackboardKeySelector TargetKey;

	UFUNCTION() void Strafe();
	void HandleQueryResult(TSharedPtr<FEnvQueryResult> result);

private:
	UPROPERTY() class AEnemyController* EC;
	UPROPERTY() class ACharacter* Enemy;
	UPROPERTY() AActor* Target;
	UPROPERTY() bool bIsRandomDirection;
	};
