// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTService.h"
#include "KilsuARPG/Data/Enum/EAI.h"
#include "BTService_BossLogic.generated.h"

UCLASS()
class KILSUARPG_API UBTService_BossLogic : public UBTService
{
	GENERATED_BODY()

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
	
public:
	UBTService_BossLogic();

	FORCEINLINE void SetBehavior(class AEnemyController* EC, EAIBehavior Behavior);

	UPROPERTY(EditAnywhere) float AttackRange;

private:
	UPROPERTY() float Distance;
	UPROPERTY() float Dot;
	UPROPERTY() int32 tick;
};
