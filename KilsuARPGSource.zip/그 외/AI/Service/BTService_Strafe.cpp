// Fill out your copyright notice in the Description page of Project Settings.


#include "BTService_Strafe.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "EnvironmentQuery/EnvQuery.h"
#include "EnvironmentQuery/EnvQueryManager.h"

UBTService_Strafe::UBTService_Strafe() //: Super(ObjectInitializer)
{
	NodeName = "Strafe";
	bNotifyTick = true;
	bNotifyBecomeRelevant = true;    
	bNotifyCeaseRelevant = true;
	
	Interval = 1.f; 
	RandomDeviation = 0.f;

	static ConstructorHelpers::FObjectFinder<UEnvQuery>StrafeLeftOb(TEXT("EnvQuery'/Game/BP/AI/EQS/EQS_StrafeLeft.EQS_StrafeLeft'"));
	if (StrafeLeftOb.Succeeded())
		EQS_StrafeLeft = StrafeLeftOb.Object;
	static ConstructorHelpers::FObjectFinder<UEnvQuery>StrafeRightOb(TEXT("EnvQuery'/Game/BP/AI/EQS/EQS_StrafeRight.EQS_StrafeRight'"));
	if (StrafeRightOb.Succeeded())
		EQS_StrafeRight = StrafeRightOb.Object;
}

//Activation
void UBTService_Strafe::OnBecomeRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::OnBecomeRelevant(OwnerComp, NodeMemory);
	
	if (OwnerComp.GetAIOwner() && OwnerComp.GetAIOwner()->GetPawn())
	{		
		Enemy = Cast<ACharacter>(OwnerComp.GetAIOwner()->GetPawn());
		EC = Cast<AEnemyController>(OwnerComp.GetAIOwner());
		Target = EC->Target != nullptr ?  EC->Target : nullptr;
		if (Target != nullptr)
		{
			EC->SetFocus(Target);
			Enemy->bUseControllerRotationYaw = false;
			Enemy->GetCharacterMovement()->bOrientRotationToMovement = false;
			Enemy->GetCharacterMovement()->bUseControllerDesiredRotation = true;
			Strafe();
		}
		bIsRandomDirection = UKismetMathLibrary::RandomBool();
	}	
}

//Deactivation
void UBTService_Strafe::OnCeaseRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::OnCeaseRelevant(OwnerComp, NodeMemory);

	EC->ClearFocus(EAIFocusPriority::Default);
	EC->StopMovement();
	Enemy->bUseControllerRotationYaw = false;
	Enemy->GetCharacterMovement()->bOrientRotationToMovement = true;
	Enemy->GetCharacterMovement()->bUseControllerDesiredRotation = false;
}

//tick
void UBTService_Strafe::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);	
	Strafe();
}

void UBTService_Strafe::Strafe()
{
	FEnvQueryRequest QueryRequest = bIsRandomDirection ? FEnvQueryRequest(EQS_StrafeLeft, EC->GetPawn()) : FEnvQueryRequest(EQS_StrafeRight, EC->GetPawn());
	QueryRequest.Execute(EEnvQueryRunMode::RandomBest5Pct, this, &UBTService_Strafe::HandleQueryResult);
}

void UBTService_Strafe::HandleQueryResult(TSharedPtr<FEnvQueryResult> result)
{
	if (result->IsSuccsessful())
	{
		EC->MoveToLocation(result->GetItemAsLocation(0), 20.f);		
	}
	else
		EC->StopMovement();
}