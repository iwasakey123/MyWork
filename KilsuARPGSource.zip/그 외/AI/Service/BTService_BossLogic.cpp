// Fill out your copyright notice in the Description page of Project Settings.


#include "BTService_BossLogic.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Kismet/KismetMathLibrary.h"

#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"

UBTService_BossLogic::UBTService_BossLogic()
{
	NodeName = TEXT("BossLogic");
	Interval = 1.f;
	RandomDeviation = 0.f;
}

void UBTService_BossLogic::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	auto EC = Cast<AEnemyController>(OwnerComp.GetAIOwner());
	APawn* Pawn = nullptr;
	if(EC)
		Pawn = EC->GetPawn();
	if (Pawn == nullptr)
		return;
		
	//UE_LOG(LogTemp, Warning, TEXT("Service"));
	SetBehavior(EC, EAIBehavior::Idle);	
	if (IStateInterface::Execute_IsAlive(Pawn))
	{
		AActor* target = Cast<AActor>(EC->GetBlackboardComponent()->GetValueAsObject(AEnemyController::TargetKey));
		if (target && IStateInterface::Execute_IsAlive(target))
		{
			Distance = target->GetDistanceTo(Pawn);
			Dot = target->GetDotProductTo(Pawn);
			
			//IsTarget Behind?
			if (Dot <= -0.25)
			{
				if (Distance <= AttackRange)
					SetBehavior(EC, EAIBehavior::MeleeAttack);
				else
					SetBehavior(EC, EAIBehavior::Chase);
			}
			else
			{
				if (Distance <= AttackRange)
				{
					if (tick >= 3)
					{
						SetBehavior(EC, EAIBehavior::MeleeAttack);
						if (UKismetMathLibrary::RandomBoolWithWeight(0.4f))
							tick = 0;
					}
					else
					{
						tick++;
						if (UKismetMathLibrary::RandomBoolWithWeight(0.1f))
							SetBehavior(EC, EAIBehavior::MeleeAttack);
						else SetBehavior(EC, EAIBehavior::Strafe);
					}
				}
				else
				{
					tick = 0;
					if (Distance >= 2000.f)
						SetBehavior(EC, EAIBehavior::Chase);
					else
					{
						SetBehavior(EC, EAIBehavior::Strafe);
					}
				}
			}
		}
		else
			SetBehavior(EC, EAIBehavior::Idle);
	}
	else
	{
		SetBehavior(EC, EAIBehavior::Dead);
	}
}

void UBTService_BossLogic::SetBehavior(AEnemyController* EC, EAIBehavior Behavior)
{
	EC->GetBlackboardComponent()->SetValueAsEnum(AEnemyController::AIBehaviorKey, (uint8)Behavior);
}