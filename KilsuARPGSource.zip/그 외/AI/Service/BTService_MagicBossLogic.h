// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTService.h"
#include "KilsuARPG/Data/Enum/EAI.h"
#include "BTService_MagicBossLogic.generated.h"

UCLASS()
class KILSUARPG_API UBTService_MagicBossLogic : public UBTService
{
	GENERATED_BODY()
	
protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

public:
	UBTService_MagicBossLogic();

	FORCEINLINE void SetBehavior(class AEnemyController* EC, EAIBehavior Behavior);

	UPROPERTY(EditAnywhere) float MeleeBehaviorDistance;

private:
	UPROPERTY() float Distance;
};
