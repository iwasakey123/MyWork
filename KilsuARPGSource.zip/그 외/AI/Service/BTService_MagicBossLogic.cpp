 // Fill out your copyright notice in the Description page of Project Settings.


#include "BTService_MagicBossLogic.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"

UBTService_MagicBossLogic::UBTService_MagicBossLogic()
{
	NodeName = TEXT("MagicBossLogic");
	Interval = 1.f;
	RandomDeviation = 0.f;
}

void UBTService_MagicBossLogic::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	auto EC = Cast<AEnemyController>(OwnerComp.GetAIOwner());
	APawn* Pawn = nullptr;
	if (EC)
		Pawn = EC->GetPawn();
	if (Pawn == nullptr)
		return;

	SetBehavior(EC, EAIBehavior::Idle);
	if (IStateInterface::Execute_IsAlive(Pawn))
	{
		AActor* target = Cast<AActor>(EC->GetBlackboardComponent()->GetValueAsObject(AEnemyController::TargetKey));
		if (target && IStateInterface::Execute_IsAlive(target))
		{
			Distance = target->GetDistanceTo(Pawn);
			if (Distance <= MeleeBehaviorDistance)
				SetBehavior(EC, EAIBehavior::MeleeAttack);
			else
				SetBehavior(EC, EAIBehavior::RangeAttack);			
		}
	}
}

void UBTService_MagicBossLogic::SetBehavior(AEnemyController* EC, EAIBehavior Behavior)
{
	EC->GetBlackboardComponent()->SetValueAsEnum(AEnemyController::AIBehaviorKey, (uint8)Behavior);
}