// Fill out your copyright notice in the Description page of Project Settings.


#include "EQS_RightContext.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "EnvironmentQuery/EnvQueryTypes.h"
#include "Kismet/KismetMathLibrary.h"
#include "EnvironmentQuery/Items/EnvQueryItemType_Point.h"

void UEQS_RightContext::ProvideContext(FEnvQueryInstance& QueryInstance, FEnvQueryContextData& ContextData) const
{
	Super::ProvideContext(QueryInstance, ContextData);

	auto EC = Cast<AEnemyController>((Cast<AActor>((QueryInstance.Owner).Get())->GetInstigatorController()));	
	AActor* OwnerAct = Cast<AActor>(QueryInstance.Owner.Get());

	
	if (EC->Target && OwnerAct)
	{		
		auto Rot = UKismetMathLibrary::MakeRotator(0.f, 0.f, UKismetMathLibrary::FindLookAtRotation(EC->Target->GetActorLocation(), OwnerAct->GetActorLocation()).Yaw + 90.f);
		FVector ResultLocation = Rot.Vector() * 300.f + OwnerAct->GetActorLocation();
		UEnvQueryItemType_Point::SetContextHelper(ContextData, ResultLocation);
	}
}