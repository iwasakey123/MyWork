// Fill out your copyright notice in the Description page of Project Settings.


#include "EQS_TargetContext.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "EnvironmentQuery/EnvQueryTypes.h"
#include "EnvironmentQuery/Items/EnvQueryItemType_Actor.h"

void UEQS_TargetContext::ProvideContext(FEnvQueryInstance& QueryInstance, FEnvQueryContextData& ContextData) const
{
	Super::ProvideContext(QueryInstance, ContextData);

	auto EC = Cast<AEnemyController>((Cast<AActor>((QueryInstance.Owner).Get())->GetInstigatorController()));
	if(EC && EC->Target)
		UEnvQueryItemType_Actor::SetContextHelper(ContextData, EC->Target);
	else
		UEnvQueryItemType_Actor::SetContextHelper(ContextData, EC->GetPawn());
}