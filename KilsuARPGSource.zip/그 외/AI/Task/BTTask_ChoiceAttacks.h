// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "BTTask_ChoiceAttacks.generated.h"

UCLASS()
class KILSUARPG_API UBTTask_ChoiceAttacks : public UBTTaskNode
{
	GENERATED_BODY()	

public:
	UBTTask_ChoiceAttacks();
	UPROPERTY(EditAnywhere) TArray<class UAnimMontage*> AttackMontages;
	UPROPERTY(EditAnywhere) int32 RandomValue_idx_1 = 100;
	UPROPERTY(EditAnywhere) int32 RandomValue_idx_2 = 100;
	UPROPERTY(EditAnywhere) float PlayRate = 1.f;

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

};
