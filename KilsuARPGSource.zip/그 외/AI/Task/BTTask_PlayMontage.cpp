// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_PlayMontage.h"
#include "AIController.h"
#include "GameFramework/Character.h"

UBTTask_PlayMontage::UBTTask_PlayMontage()
{
	NodeName = "PlayMontage";	
}

EBTNodeResult::Type UBTTask_PlayMontage::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	EBTNodeResult::Type Result = Super::ExecuteTask(OwnerComp, NodeMemory);
	auto Character = Cast<ACharacter>(OwnerComp.GetAIOwner()->GetPawn());
	if (Character == nullptr || CustomMontage == nullptr)
		return EBTNodeResult::Failed;

	FTimerHandle handle;
	float delay = Character->PlayAnimMontage(CustomMontage, PlayRate);
	GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]()
	{
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
	}), delay - 0.1f, false);
	return EBTNodeResult::InProgress;
}


