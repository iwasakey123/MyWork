// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_SetMovement.h"
#include "AIController.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"

UBTTask_SetMovement::UBTTask_SetMovement()
{
	NodeName = TEXT("SetMovement");
}

EBTNodeResult::Type UBTTask_SetMovement::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	EBTNodeResult::Type Result = Super::ExecuteTask(OwnerComp, NodeMemory);
	auto Character = Cast<ACharacter>(OwnerComp.GetAIOwner()->GetPawn());
	if (Character == nullptr)
		return EBTNodeResult::Failed;
	if (Character->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true)
	{
		IStateInterface::Execute_SetMovement(Character, MovementType);
		return EBTNodeResult::Succeeded;
	}
	return EBTNodeResult::Failed;
}