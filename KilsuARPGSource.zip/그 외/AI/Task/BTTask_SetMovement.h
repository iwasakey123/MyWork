// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "KilsuARPG/Data/Enum/EAI.h"
#include "BTTask_SetMovement.generated.h"

UCLASS()
class KILSUARPG_API UBTTask_SetMovement : public UBTTaskNode
{
	GENERATED_BODY()
	
public:
	UBTTask_SetMovement();

	UPROPERTY(EditAnywhere) EAIMovement MovementType;

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
};
