// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_CombatOn.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Controllers/EnemyController.h"
#include "KilsuARPG/Components/MontageComponent.h"

UBTTask_CombatOn::UBTTask_CombatOn()
{
	NodeName = TEXT("CombatOn");
}

EBTNodeResult::Type UBTTask_CombatOn::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	EBTNodeResult::Type Result = Super::ExecuteTask(OwnerComp, NodeMemory);
	auto Character = Cast<ACharacter>(OwnerComp.GetAIOwner()->GetPawn());
	if (Character == nullptr)
		return EBTNodeResult::Failed;

	FTimerHandle handle;
	auto MontageComp = Character->FindComponentByClass<UMontageComponent>();
	float delay = MontageComp->PlayMontage(EMontageType::CombatOn);
	GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]()
	{
		OwnerComp.GetAIOwner()->GetBlackboardComponent()->SetValueAsBool(AEnemyController::IsCombatKey, true);
	}), delay - 0.1f, false);

	return EBTNodeResult::Succeeded;
}