// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_ChoiceAttacks.h"
#include "AIController.h"
#include "GameFramework/Character.h"

UBTTask_ChoiceAttacks::UBTTask_ChoiceAttacks()
{
	NodeName = "ChoiceAttack";
}

EBTNodeResult::Type UBTTask_ChoiceAttacks::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	EBTNodeResult::Type Result = Super::ExecuteTask(OwnerComp, NodeMemory);
	auto Character = Cast<ACharacter>(OwnerComp.GetAIOwner()->GetPawn());
	if (Character == nullptr)
		return EBTNodeResult::Failed;
	if (AttackMontages.Num() <= 0)
		return EBTNodeResult::Failed;

	if (AttackMontages.Num() > 0)
	{
		float delay = 0.f;
		if (FMath::RandRange(1, 100) <= RandomValue_idx_1)
			delay = Character->PlayAnimMontage(AttackMontages[0], PlayRate);
		else if (FMath::RandRange(1, 100) <= RandomValue_idx_2 && AttackMontages.Num() > 1)
			delay = Character->PlayAnimMontage(AttackMontages[1], PlayRate);
		else if (AttackMontages.Num() > 2)			
			delay = Character->PlayAnimMontage(AttackMontages[2], PlayRate);	

		FTimerHandle handle;
		GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]()
		{
			FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
		}), delay - 0.1f, false);
	}

	return EBTNodeResult::InProgress;
}
