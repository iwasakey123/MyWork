// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "EnemyController.generated.h"

UCLASS()
class KILSUARPG_API AEnemyController : public AAIController
{
	GENERATED_BODY()

private:
	UPROPERTY() class UAIPerceptionComponent* AIPerceptionComp;
	UPROPERTY() class UAISenseConfig_Sight* SightConfig;
	UPROPERTY() class UAISenseConfig_Damage* DamageConfig;

public:
	AEnemyController();

	virtual void OnPossess(APawn* InPawn) override;

	//BlackboardŰ
	static const FName AIBehaviorKey;
	static const FName TargetKey;
	static const FName IsCombatKey;
	static const FName IsGroggyKey;
	static const FName ExecutedKey;
	static const FName GuardHitKey;
	static const FName SpecialHitKey;
	static const FName TakeDownKey;
	static const FName HitKey;

	//TimerHandle
	UPROPERTY() FTimerHandle SearchTargetHandle;

	UPROPERTY() class AEnemyCharacter* Enemy;
	UPROPERTY(BlueprintReadOnly) AActor* Target;

	UFUNCTION() void SearchTarget();
	UFUNCTION() void SetTarget(AActor* NewTarget);	
};
