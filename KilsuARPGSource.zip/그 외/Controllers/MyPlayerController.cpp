// Fill out your copyright notice in the Description page of Project Settings.


#include "MyPlayerController.h"
#include "Blueprint/UserWidget.h"
#include "KilsuARPG/UI/MainWidget.h"
#include "KilsuARPG/UI/HUDLayer.h"
#include "KilsuARPG/UI/InventoryUI/InventoryWidget.h"
#include "KilsuARPG/UI/InventoryUI/InventorySlotWidget.h"
#include "KilsuARPG/UI/EquipmentUI/EquipmentWidget.h"
#include "KilsuARPG/UI/EquipmentUI/EquipmentSlotWidget.h"
#include "KilsuARPG/UI/HUD/HUDUI_Boss.h"
#include "KilsuARPG/UI/HUD/HUDUI.h"
#include "KilsuARPG/Data/Interface/UIInterface.h"
#include "Components/ProgressBar.h"
#include "Kismet/GameplayStatics.h"

AMyPlayerController::AMyPlayerController()
{
	//UIList.Add(EUIType::Inventory, true);	
	//UIList.Add(EUIType::Equipment, false);

	//static ConstructorHelpers::FClassFinder<UMainWidget>MainWidgetClassOb(TEXT("WidgetBlueprint'/Game/BP/UI/WBP_MainWidget.WBP_MainWidget'"));
	//if (MainWidgetClassOb.Succeeded())
	//{
	//	MainWidgetClass = MainWidgetClassOb.Class;
	//}

	//static ConstructorHelpers::FClassFinder<UHUDLayer>HUDWidgetClassOb(TEXT("WidgetBlueprint'/Game/BP/UI/WBP_HUDLayer.WBP_HUDLayer'"));
	//if (HUDWidgetClassOb.Succeeded())
	//{
	//	HUDLayerClass = HUDWidgetClassOb.Class;
	//}

	//static ConstructorHelpers::FClassFinder<UInventoryWidget>InventoryWidgetClassOb(TEXT("WidgetBlueprint'/Game/BP/UI/Inventory/WBP_Inventory.WBP_Inventory'"));
	//{
	//	InventoryWidgetClass = InventoryWidgetClassOb.Class;
	//}
}

void AMyPlayerController::OnPossess(APawn* aPawn)
{
	Super::OnPossess(aPawn);

	//bShowMouseCursor = true;

	if (HUDLayerClass != NULL)
	{
		HUDLayer = CreateWidget<UHUDLayer>(this, HUDLayerClass);		
		HUDLayer->AddToViewport();
		UE_LOG(LogTemp, Warning, TEXT("Success::HUDLayer is Valid"));
	}
	else UE_LOG(LogTemp, Warning, TEXT("Error::HUDLayer is Not Valid"));
	if (HUDLayer && HUDLayer->WBP_InventoryWidget)
	{
		InventoryWidget = HUDLayer->WBP_InventoryWidget;
		UE_LOG(LogTemp, Warning, TEXT("Success::InventoryWidget is Valid"));
	}
	else UE_LOG(LogTemp, Warning, TEXT("Error::InventoryWidget is Not Valid"));
	if (HUDLayer && HUDLayer->WBP_EquipmentWidget)
	{
		EquipmentWidget = HUDLayer->WBP_EquipmentWidget;
	}
	UpdateSlotUI();
}

void AMyPlayerController::OpenUI(EUIType UIType)
{
	switch (UIType)
	{
	case EUIType::Inventory:
		if (UIList.Find(EUIType::Inventory))
		{			
			UIList.Remove(EUIType::Inventory);
			if (HUDLayer)
			{
				HUDLayer->IUIInterface::Execute_SetVisible(HUDLayer, false, EUIType::Inventory);				
				UE_LOG(LogTemp, Warning, TEXT("Inven Close"));
			}
		}
		else
		{			
			UIList.Add(EUIType::Inventory, true);	
			if (HUDLayer)
			{				
				HUDLayer->IUIInterface::Execute_SetVisible(HUDLayer, true, EUIType::Inventory);
				UE_LOG(LogTemp, Warning, TEXT("Inven Open"));
			}
		}		
		break;
	case EUIType::Equipment:
		if (UIList.Find(EUIType::Equipment))
		{
			UIList.Remove(EUIType::Equipment);
			if (HUDLayer)
			{
				HUDLayer->IUIInterface::Execute_SetVisible(HUDLayer, false, EUIType::Equipment);
				UE_LOG(LogTemp, Warning, TEXT("Equipment Close"));
			}
		}
		else
		{
			UIList.Add(EUIType::Equipment, true);
			if (HUDLayer)
			{
				HUDLayer->IUIInterface::Execute_SetVisible(HUDLayer, true, EUIType::Equipment);
				UE_LOG(LogTemp, Warning, TEXT("Equipment Open"));
			}
		}		
		break;
	case EUIType::Menu:
		if (HUDLayer)
		{
			HUDLayer->IUIInterface::Execute_SetVisible(HUDLayer, true, EUIType::Menu);
			UGameplayStatics::SetGamePaused(GetWorld(), true);
			SetInputMode(FInputModeUIOnly());
			bShowMouseCursor = true;
			DisableInput(this);
		}
		return;
	}
	ShowCursor();
}

void AMyPlayerController::ShowCursor()
{
	bool Open = false;
	for (auto& Elem : UIList)
	{
		if (Elem.Value == true)
		{
			Open = true;
			break;
		}
	}
	if (Open == true)
	{		
		bShowMouseCursor = true;
		SetInputMode(FInputModeGameAndUI());
	}
	else
	{		
		bShowMouseCursor = false;
		SetInputMode(FInputModeGameOnly());
	}
}

void AMyPlayerController::UpdateSlotUI()
{
	if (InventoryWidget)
	{
		IUIInterface::Execute_GenerateSlots(InventoryWidget);		
	}
}

void AMyPlayerController::UpdateEquipmentSlotUI(TSubclassOf<AItem>EquipmentClass, EEquipmentType EquipmentType)
{
	if (HUDLayer)
	{
		switch (EquipmentType)
		{
		case EEquipmentType::MainWeapon:
			HUDLayer->WBP_EquipmentWidget->Slot_MainWeapon->EquipmentClass = EquipmentClass;
			HUDLayer->WBP_EquipmentWidget->Slot_MainWeapon->UpdateSlot();
			break;
		case EEquipmentType::SubWeapon:
			HUDLayer->WBP_EquipmentWidget->Slot_SubWeapon->EquipmentClass = EquipmentClass;
			HUDLayer->WBP_EquipmentWidget->Slot_SubWeapon->UpdateSlot();
			break;
		case EEquipmentType::Head:
			HUDLayer->WBP_EquipmentWidget->Slot_Head->EquipmentClass = EquipmentClass;
			HUDLayer->WBP_EquipmentWidget->Slot_Head->UpdateSlot();
			break;
		case EEquipmentType::Upper:
			HUDLayer->WBP_EquipmentWidget->Slot_Upper->EquipmentClass = EquipmentClass;
			HUDLayer->WBP_EquipmentWidget->Slot_Upper->UpdateSlot();
			break;
		case EEquipmentType::Lower:
			HUDLayer->WBP_EquipmentWidget->Slot_Lower->EquipmentClass = EquipmentClass;
			HUDLayer->WBP_EquipmentWidget->Slot_Lower->UpdateSlot();
			break;
		case EEquipmentType::Hand:
			HUDLayer->WBP_EquipmentWidget->Slot_Hand->EquipmentClass = EquipmentClass;
			HUDLayer->WBP_EquipmentWidget->Slot_Hand->UpdateSlot();
			break;
		case EEquipmentType::Shoes:
			HUDLayer->WBP_EquipmentWidget->Slot_Shoes->EquipmentClass = EquipmentClass;
			HUDLayer->WBP_EquipmentWidget->Slot_Shoes->UpdateSlot();
			break;
		case EEquipmentType::Cape:
			HUDLayer->WBP_EquipmentWidget->Slot_Cape->EquipmentClass = EquipmentClass;
			HUDLayer->WBP_EquipmentWidget->Slot_Cape->UpdateSlot();
			break;
		}
	}
}

void AMyPlayerController::ShowBossUI(bool Visible)
{
	if (Visible)
	{		
		BossHPUI = CreateWidget<UHUDUI_Boss>(this, BossHPUIClass);
		BossHPUI->AddToViewport();
		BossHPUI->PlayAnimation(BossHPUI->HPBarShow);
		//BossHPUI->BindHPPer();
	}
	else
	{
		BossHPUI->PlayAnimation(BossHPUI->HPBarHide);
		FTimerHandle handle;
		float delay = 0.5f;		
		GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]() 
		{
			BossHPUI->RemoveFromParent();
			BossHPUI = nullptr;
			GetWorld()->GetTimerManager().ClearTimer(handle);
		}), delay, false);
	}
}

void AMyPlayerController::HitHPBar()
{
	HUDLayer->WBP_HUDUI_Player->PlayAnimation(HUDLayer->WBP_HUDUI_Player->HPBorderHitAnim);
}

void AMyPlayerController::UpdateStatUI()
{
	HUDLayer->WBP_EquipmentWidget->UpdateStatUI();
}
