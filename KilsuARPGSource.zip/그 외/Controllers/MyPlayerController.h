// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "KilsuARPG/Data/Enum/EWidget.h"
#include "KilsuARPG/Data/Enum/EItem.h"
#include "KilsuARPG/Data/Enum/EStat.h"
#include "MyPlayerController.generated.h"

class UUserWidget;
UCLASS()
class KILSUARPG_API AMyPlayerController : public APlayerController
{
	GENERATED_BODY()
	
private:
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true")) TSubclassOf<class UHUDLayer> HUDLayerClass;
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true")) TSubclassOf<class UInventoryWidget> InventoryWidgetClass;
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true")) TSubclassOf<class UInventorySlotWidget> InventorySlotWidgetClass;
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true")) TSubclassOf<class UDraggedInventorySlotWidget> InventorySlot_DragClass;
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true")) TSubclassOf<class UEquipmentWidget> EquipmentWidgetClass;
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true")) TSubclassOf<class UEquipmentSlotWidget> EquipmentSlotWidgetClass;	
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true")) TSubclassOf<class UHUDUI_Boss> BossHPUIClass;
	//UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true")) TSubclassOf<class UUserWidget> DeadUIClass;	

public:
	AMyPlayerController();
	virtual void OnPossess(APawn* aPawn) override;

	FORCEINLINE TSubclassOf<UInventorySlotWidget> GetSlotClass() { return InventorySlotWidgetClass; }
	FORCEINLINE TSubclassOf<UDraggedInventorySlotWidget> GetDraggedSlotClass() { return InventorySlot_DragClass; }	

	//UPROPERTY(BlueprintReadwrite) UMainWidget* MainWidget;
	UPROPERTY(blueprintReadwrite) UHUDLayer* HUDLayer;
	UPROPERTY(blueprintreadwrite) UInventoryWidget* InventoryWidget;
	UPROPERTY(blueprintreadwrite) UInventorySlotWidget* InventorySlotWidget;
	UPROPERTY(blueprintReadWrite) UEquipmentWidget* EquipmentWidget;
	UPROPERTY(BLUEprintreadWrite) UEquipmentSlotWidget* EquipmentSlotWidget;
	UPROPERTY() class UHUDUI_Boss* BossHPUI;

	UPROPERTY() TMap<EUIType, bool> UIList;

	UFUNCTION() void OpenUI(EUIType UIType);
	UFUNCTION(BlueprintCallable) void ShowCursor();
	UFUNCTION() void UpdateSlotUI();
	UFUNCTION() void UpdateEquipmentSlotUI(TSubclassOf<class AItem>EquipmentClass, EEquipmentType EquipmentType);
	UFUNCTION() void ShowBossUI(bool Visible);
	UFUNCTION() void HitHPBar();
	UFUNCTION() void UpdateStatUI();	
};

