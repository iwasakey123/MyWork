// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemyController.h"
#include "KilsuARPG/Characters/EnemyCharacter.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AISenseConfig_Damage.h"
#include "TimerManager.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"

AEnemyController::AEnemyController()
{
	SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("SightConfig"));
	SightConfig->SightRadius = 1500.f;
	SightConfig->LoseSightRadius = 5500.f;
	SightConfig->PeripheralVisionAngleDegrees = 60.f;
	SightConfig->DetectionByAffiliation.bDetectEnemies = true;
	SightConfig->DetectionByAffiliation.bDetectFriendlies = true;
	SightConfig->DetectionByAffiliation.bDetectNeutrals = true;
	SightConfig->SetMaxAge(800.f);

	DamageConfig = CreateDefaultSubobject<UAISenseConfig_Damage>(TEXT("DamageConfig"));
	DamageConfig->SetMaxAge(800.f);

	AIPerceptionComp = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("AIPerceptionComp"));
	AIPerceptionComp->ConfigureSense(*SightConfig);
	AIPerceptionComp->ConfigureSense(*DamageConfig);
	AIPerceptionComp->SetDominantSense(SightConfig->GetSenseImplementation());
}

const FName AEnemyController::AIBehaviorKey(TEXT("AIBehavior"));
const FName AEnemyController::TargetKey(TEXT("Target"));
const FName AEnemyController::IsCombatKey(TEXT("IsCombat"));
const FName AEnemyController::IsGroggyKey(TEXT("IsGroggy"));
const FName AEnemyController::ExecutedKey(TEXT("Executed"));
const FName AEnemyController::GuardHitKey(TEXT("GuardHit"));
const FName AEnemyController::SpecialHitKey(TEXT("SpecialHit"));
const FName AEnemyController::TakeDownKey(TEXT("TakeDown"));
const FName AEnemyController::HitKey(TEXT("Hit"));

void AEnemyController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);	
	Enemy = Cast<AEnemyCharacter>(InPawn);	
	if (Enemy && Enemy->BehaviorTree != nullptr)
	{			
		//SightConfig->SightRadius = Enemy->EnemySense.SightRadius;
		//SightConfig->LoseSightRadius = Enemy->EnemySense.LoseSightRadius;
		//SightConfig->PeripheralVisionAngleDegrees = Enemy->EnemySense.PeripheralVisionAngleDegrees;
		//SightConfig->SetMaxAge(Enemy->EnemySense.SightMaxAge);
		//DamageConfig->SetMaxAge(Enemy->EnemySense.DamageMaxAge);
		if(!RunBehaviorTree(Enemy->BehaviorTree))
			UE_LOG(LogTemp, Warning, TEXT("AI BehaviorTree Not Valid"));		
		GetWorld()->GetTimerManager().SetTimer(SearchTargetHandle, this, &AEnemyController::SearchTarget, 0.1f, true);
	}
	//else if (Enemy && Enemy->BehaviorTree == nullptr)
		//Enemy->BehaviorTree = LoadObject<>(nullptr, TEXt(""));
}

void AEnemyController::SearchTarget()
{	
	TArray<AActor*>LocalPerceivedEnemies;
	TArray<float>LocalDistance;
	if (GetPawn() && GetPawn()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(GetPawn()) == true)
	{		
		TArray<AActor*>OuterActors;
		AIPerceptionComp->GetKnownPerceivedActors(nullptr, OuterActors);
		for (AActor* OuterActor : OuterActors)
		{			
			if (OuterActor && OuterActor->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(OuterActor) == true)
			{				
				if (OuterActor->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true)
				{
					FName OuterTag = ICombatInterface::Execute_GetTag(OuterActor);
					if (ICombatInterface::Execute_CheckEnemy(GetPawn(), OuterTag))
						LocalPerceivedEnemies.Add(OuterActor);				
				}
			}
		}
			   
		if (LocalPerceivedEnemies.Num() > 0)
		{
			for (AActor* PerceivedEnemy : LocalPerceivedEnemies)
				LocalDistance.Add(GetPawn()->GetDistanceTo(PerceivedEnemy));
			int32 idx = 0;
			float MinDistance = 0;
			UKismetMathLibrary::MinOfFloatArray(LocalDistance, idx, MinDistance);

			if (LocalPerceivedEnemies[idx])
			{
				if (IsValid(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0)) && LocalPerceivedEnemies.Contains(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0)))
				{
					ICombatInterface::Execute_SetEnemyTarget(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0), GetPawn(), Enemy->AIType);
					if (Target == nullptr)Enemy->ShowEnemyHUD(false);
				}
				SetTarget(LocalPerceivedEnemies[idx]);				
			}
		}
		else
		{	
			if (IsValid(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0)))
			{
				if (UGameplayStatics::GetPlayerCharacter(GetWorld(), 0)->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()))
					ICombatInterface::Execute_SetEnemyTarget(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0), nullptr, Enemy->AIType);
				if(Target) Enemy->ShowEnemyHUD(true);			
			}
			SetTarget(nullptr);			
		}
	}
	else
	{
		GetWorldTimerManager().ClearTimer(SearchTargetHandle);
	}
}
void AEnemyController::SetTarget(AActor* NewTarget)
{
	if (Target != NewTarget)
	{
		Target = NewTarget;
		Target != nullptr ? GetBlackboardComponent()->SetValueAsObject(TargetKey, Target) : GetBlackboardComponent()->SetValueAsObject(TargetKey, nullptr);
	}
}

