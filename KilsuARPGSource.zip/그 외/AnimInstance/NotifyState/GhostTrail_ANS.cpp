// Fill out your copyright notice in the Description page of Project Settings.


#include "GhostTrail_ANS.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Data/GhostTrail/GhostTrail.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"

void UGhostTrail_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto Player = Cast<ACharacter>(MeshComp->GetOwner());
		if (Player && Player->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true)
			ICombatInterface::Execute_GhostTailOnOff(MeshComp->GetOwner(), true);	
	}
}

void UGhostTrail_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto Player = Cast<ACharacter>(MeshComp->GetOwner());
		if (Player && Player->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true)
			ICombatInterface::Execute_GhostTailOnOff(MeshComp->GetOwner(), false);
	}
}