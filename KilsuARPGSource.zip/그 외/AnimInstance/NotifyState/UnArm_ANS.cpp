// Fill out your copyright notice in the Description page of Project Settings.


#include "UnArm_ANS.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Components/MontageComponent.h"

void UUnArm_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto MontageComp = MeshComp->GetOwner()->FindComponentByClass<UMontageComponent>();
		auto EquipmentComp = MeshComp->GetOwner()->FindComponentByClass<UEquipmentComponent>();
		if (MontageComp && EquipmentComp && EquipmentComp->GetCurrentWeapon() != nullptr)
		{
			MontageComp->PlayMontage(EMontageType::CombatOff);
			bSaveWeapon = true;
		}
	}
}

void UUnArm_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto MontageComp = MeshComp->GetOwner()->FindComponentByClass<UMontageComponent>();
		auto EquipmentComp = MeshComp->GetOwner()->FindComponentByClass<UEquipmentComponent>();
		if (MontageComp && EquipmentComp && EquipmentComp->GetCurrentWeapon() != nullptr && bSaveWeapon)
		{
			MontageComp->PlayMontage(EMontageType::CombatOn);
			bSaveWeapon = false;
		}
	}
}