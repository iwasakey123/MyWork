// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "KilsuARPG/Data/Struct/FCollisionComponent.h"
#include "KilsuARPG/Data/Struct/FDamage.h"
#include "HitTrace_ANS.generated.h"

UCLASS()
class KILSUARPG_API UHitTrace_ANS : public UAnimNotifyState
{
	GENERATED_BODY()	
	
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

public:

	UPROPERTY(EditAnywhere) ECollisionParts CustomCollisionParts;
	UPROPERTY(EditAnywhere) float CustomTraceSize = 1.f;
	UPROPERTY(EditAnywhere) FDamage CustomDamage;
};
