// Fill out your copyright notice in the Description page of Project Settings.


#include "DisableInput_ANS.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"

void UDisableInput_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	auto Cha = Cast<ACharacter>(MeshComp->GetOwner());
	if (Cha)
	{
		if(IsValid(UGameplayStatics::GetPlayerController(GetWorld(), 0)))
			if (auto PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
				Cha->DisableInput(PC);
	}
}

void UDisableInput_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	auto Cha = Cast<ACharacter>(MeshComp->GetOwner());
	if (Cha)
	{
		if (IsValid(UGameplayStatics::GetPlayerController(GetWorld(), 0)))
			if (auto PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
				Cha->EnableInput(PC);
	}
}