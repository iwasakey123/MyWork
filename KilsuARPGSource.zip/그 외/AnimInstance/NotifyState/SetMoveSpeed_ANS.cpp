// Fill out your copyright notice in the Description page of Project Settings.


#include "SetMoveSpeed_ANS.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"

void USetMoveSpeed_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		ACharacter* CharacterRef = Cast<ACharacter>(MeshComp->GetOwner());
		if (CharacterRef)
		{
			SaveSpeed = CharacterRef->GetCharacterMovement()->MaxWalkSpeed;
			CharacterRef->GetCharacterMovement()->MaxWalkSpeed = CustomSpeed;
		}
	}
}

void USetMoveSpeed_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		ACharacter* CharacterRef = Cast<ACharacter>(MeshComp->GetOwner());
		if(CharacterRef)		
			CharacterRef->GetCharacterMovement()->MaxWalkSpeed = SaveSpeed;
	}
}