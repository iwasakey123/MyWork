// Fill out your copyright notice in the Description page of Project Settings.


#include "MySwordIsShining_ANS.h"
#include "KilsuARPG/Components/EquipmentComponent.h"

void UMySwordIsShining_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto EquipmentComp = MeshComp->GetOwner()->FindComponentByClass<UEquipmentComponent>();
		if (EquipmentComp && EquipmentComp->GetCurrentWeapon())
		{
			EquipmentComp->MainWeaponComp->SetWorldScale3D(FVector(ScaleSize));
			for (int32 i = 0; i < EquipmentComp->MainWeaponComp->GetMaterials().Num(); i++)
			{
				auto MyMat = EquipmentComp->MainWeaponComp->GetMaterial(i);
				SaveMats.Add(MyMat);
				EquipmentComp->MainWeaponComp->SetMaterial(i, Mat);
			}
		}
	}
}

void UMySwordIsShining_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto EquipmentComp = MeshComp->GetOwner()->FindComponentByClass<UEquipmentComponent>();
		if (EquipmentComp && EquipmentComp->GetCurrentWeapon())
		{
			EquipmentComp->MainWeaponComp->SetWorldScale3D(FVector(1.f));
			for (int32 i = 0; i < SaveMats.Num(); i++)
			{				
				EquipmentComp->MainWeaponComp->SetMaterial(i, SaveMats[i]);
			}
		}
	}
}
