// Fill out your copyright notice in the Description page of Project Settings.


#include "DontWalkOrRun_ANS.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"

void UDontWalkOrRun_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner() && MeshComp->GetOwner()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true)
	{
		IStateInterface::Execute_SetCanWalk(MeshComp->GetOwner(), CanWalk);
		IStateInterface::Execute_SetCanSprint(MeshComp->GetOwner(), CanSprint);
	}
}
void UDontWalkOrRun_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner() && MeshComp->GetOwner()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true)
	{
		IStateInterface::Execute_SetCanWalk(MeshComp->GetOwner(), true);
		IStateInterface::Execute_SetCanSprint(MeshComp->GetOwner(), true);
	}
}