// Fill out your copyright notice in the Description page of Project Settings.


#include "HitTrace_ANS.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"

void UHitTrace_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto CombatComp = MeshComp->GetOwner()->FindComponentByClass<UMeleeCombatComponent>();
		if (CombatComp)
		{
			CombatComp->ActivateCollision(CustomCollisionParts, CustomTraceSize, CustomDamage);
		}
	}
}

void UHitTrace_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto CombatComp = MeshComp->GetOwner()->FindComponentByClass<UMeleeCombatComponent>();
		if (CombatComp)
		{
			CombatComp->DeactivateCollision();
		}
	}
}