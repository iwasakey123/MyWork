// Fill out your copyright notice in the Description page of Project Settings.


#include "RotateInput_ANS.h"
#include "KilsuARPG/Components/RotateComponent.h"

void URotateInput_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto RotateComp = MeshComp->GetOwner()->FindComponentByClass<URotateComponent>();
		if(RotateComp)
			RotateComp->StartInputRotation(MaxPossibleRotation, MasDegreesPerSeconds);
	}
}

void URotateInput_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto RotateComp = MeshComp->GetOwner()->FindComponentByClass<URotateComponent>();
		if(RotateComp)
			RotateComp->StopRotate();
	}
}