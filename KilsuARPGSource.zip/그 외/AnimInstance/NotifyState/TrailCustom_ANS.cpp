// Fill out your copyright notice in the Description page of Project Settings.


#include "TrailCustom_ANS.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "Particles/ParticleSystemComponent.h"

void UTrailCustom_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto EquipmentComp = MeshComp->GetOwner()->FindComponentByClass<UEquipmentComponent>();
		if (EquipmentComp && EquipmentComp->GetCurrentWeapon() && EquipmentComp->GetCurrentWeaponType() == EWeaponType::GreatSword && EquipmentComp->GetCurrentTrail())
		{
			EquipmentComp->WeaponTrailComp->BeginTrails(FName("GSTrail_01"), FName("GSTrail_02"), ETrailWidthMode::ETrailWidthMode_FromCentre, 1.f);				
		}
	}
}

void UTrailCustom_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto EquipmentComp = MeshComp->GetOwner()->FindComponentByClass<UEquipmentComponent>();
		if (EquipmentComp && EquipmentComp->GetCurrentWeapon() && EquipmentComp->GetCurrentWeaponType() == EWeaponType::GreatSword && EquipmentComp->GetCurrentTrail())
		{
			EquipmentComp->WeaponTrailComp->EndTrails();
		}
	}
}