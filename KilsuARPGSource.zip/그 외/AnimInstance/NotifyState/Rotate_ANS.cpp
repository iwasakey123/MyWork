// Fill out your copyright notice in the Description page of Project Settings.


#include "Rotate_ANS.h"
#include "KilsuARPG/Components/RotateComponent.h"

void URotate_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto RotateComp = MeshComp->GetOwner()->FindComponentByClass<URotateComponent>();
		if(RotateComp)
			RotateComp->StartRotateWithTime(RotateTime, MaxDegreesPerSeconds);
	}
}
void URotate_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto RotateComp = MeshComp->GetOwner()->FindComponentByClass<URotateComponent>();
		if(RotateComp)
			RotateComp->StopRotate();
	}
}