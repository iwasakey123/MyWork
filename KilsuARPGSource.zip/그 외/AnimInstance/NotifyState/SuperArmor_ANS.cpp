// Fill out your copyright notice in the Description page of Project Settings.


#include "SuperArmor_ANS.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"

void USuperArmor_ANS::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto Player = Cast<ACharacter>(MeshComp->GetOwner());
		if (Player && Player->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true)
		{
			IStateInterface::Execute_SetSuperArmor(MeshComp->GetOwner(), true);
		}
	}
}
void USuperArmor_ANS::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto Player = Cast<ACharacter>(MeshComp->GetOwner());
		if (Player && Player->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true)
		{
			IStateInterface::Execute_SetSuperArmor(MeshComp->GetOwner(), false);
		}
	}
}