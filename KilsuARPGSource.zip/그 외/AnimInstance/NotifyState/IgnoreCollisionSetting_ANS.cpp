// Fill out your copyright notice in the Description page of Project Settings.


#include "IgnoreCollisionSetting_ANS.h"
#include "GameFramework/Character.h"
#include "Components/CapsuleComponent.h"

void UIgnoreCollisionSetting_ANS::NotifyBegin(USkeletalMeshComponent * MeshComp, UAnimSequenceBase * Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
	if (MeshComp->GetOwner())
	{
		auto Cha = Cast<ACharacter>(MeshComp->GetOwner());
		if (Cha)
		{
			Cha->GetCapsuleComponent()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Destructible, ECollisionResponse::ECR_Overlap);
			Cha->GetCapsuleComponent()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Overlap);
		}
	}
}
void UIgnoreCollisionSetting_ANS::NotifyEnd(USkeletalMeshComponent * MeshComp, UAnimSequenceBase * Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto Cha = Cast<ACharacter>(MeshComp->GetOwner());
		if (Cha)
		{
			Cha->GetCapsuleComponent()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Destructible, ECollisionResponse::ECR_Block);
			Cha->GetCapsuleComponent()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Block);
		}
	}
}