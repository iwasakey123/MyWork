// Fill out your copyright notice in the Description page of Project Settings.


#include "VectorForward_AN.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "GameFramework/Character.h"

void UVectorForward_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto OwnerCharacter = Cast<ACharacter>(MeshComp->GetOwner());
		auto TargetController = UGameplayStatics::GetPlayerController(MeshComp, 0);
		if (TargetController, OwnerCharacter)
		{
			float Power = TargetController->GetPawn()->GetDistanceTo(MeshComp->GetOwner()) * 10.f;
			FVector Vec = UKismetMathLibrary::GetForwardVector(MeshComp->GetOwner()->GetRootComponent()->GetComponentRotation()) * Power;
			OwnerCharacter->LaunchCharacter(Vec, true, false);
		}
	}
}