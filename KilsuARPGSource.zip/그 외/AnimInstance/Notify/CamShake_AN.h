// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "CamShake_AN.generated.h"

UCLASS()
class KILSUARPG_API UCamShake_AN : public UAnimNotify
{
	GENERATED_BODY()

public:
	UPROPERTY(editAnywhere, category = "CamShake") TSubclassOf<class UCameraShake> CamShake;
	UPROPERTY(EditAnywhere, category = "CamShake") float CustomInnerRadius = 5000.f;
	UPROPERTY(EditAnywhere, category = "CamShake") float CustomOuterRadius = 100000.f;
	UPROPERTY(EditAnywhere, category = "CamShake") float CustomFallOff = 1.0f;

	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};
