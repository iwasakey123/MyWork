// Fill out your copyright notice in the Description page of Project Settings.


#include "CamShake_AN.h"
#include "Kismet/GameplayStatics.h"

void UCamShake_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	if (MeshComp->GetOwner() && CamShake)
	{
		UGameplayStatics::PlayWorldCameraShake(MeshComp, CamShake, MeshComp->GetOwner()->GetActorLocation(), CustomInnerRadius, CustomOuterRadius, CustomFallOff, false);
	}
}