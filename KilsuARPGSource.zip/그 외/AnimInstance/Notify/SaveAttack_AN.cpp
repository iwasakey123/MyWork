// Fill out your copyright notice in the Description page of Project Settings.


#include "SaveAttack_AN.h"
#include "KilsuARPG/Characters/PlayerCharacter.h"

void USaveAttack_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	if (MeshComp->GetOwner())
	{
		auto Player = Cast<APlayerCharacter>(MeshComp->GetOwner());
		if (Player)
			Player->SaveAttack();
	}
}