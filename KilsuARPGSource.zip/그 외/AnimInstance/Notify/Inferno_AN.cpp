// Fill out your copyright notice in the Description page of Project Settings.


#include "Inferno_AN.h"
#include "KilsuARPG/Characters/Boss_Reaper.h"

void UInferno_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto Reaper = Cast<ABoss_Reaper>(MeshComp->GetOwner());
		if (Reaper)
			Reaper->JusticeSword();
	}
}