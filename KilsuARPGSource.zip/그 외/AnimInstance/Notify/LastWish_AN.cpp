// Fill out your copyright notice in the Description page of Project Settings.


#include "LastWish_AN.h"
#include "KilsuARPG/Characters/EnemyCharacter.h"

void ULastWish_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);	
	if (MeshComp->GetOwner())
	{		
		auto Enemy = Cast<AEnemyCharacter>(MeshComp->GetOwner());
		if (Enemy)
		{
			Enemy->LastWish();
		}
	}
}