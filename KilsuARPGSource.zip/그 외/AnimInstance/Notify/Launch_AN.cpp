// Fill out your copyright notice in the Description page of Project Settings.


#include "Launch_AN.h"
#include "GameFramework/Character.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

void ULaunch_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto OwnerCharacter = Cast<ACharacter>(MeshComp->GetOwner());
		if (OwnerCharacter)
		{
			switch (LaunchedDirection)
			{
			case ELaunchedDirection::Up:
				OwnerCharacter->LaunchCharacter(FVector(0.f, 0.f, 750.f), false, true);
				break;
			case ELaunchedDirection::Down:
				OwnerCharacter->LaunchCharacter(FVector(0.f, 0.f, -3000.f), true, true);
				break;
			case ELaunchedDirection::Forward:
				float Power = 0.f;
				auto PC = UGameplayStatics::GetPlayerController(MeshComp, 0);
				if (PC && PC->GetPawn())
					Power = PC->GetPawn()->GetDistanceTo(MeshComp->GetOwner()) * 2.7f;
				auto NewVec = UKismetMathLibrary::GetForwardVector(OwnerCharacter->GetRootComponent()->GetComponentRotation()) * Power;
				OwnerCharacter->LaunchCharacter(NewVec, true, false);
				break;
			}
		}
	}
}