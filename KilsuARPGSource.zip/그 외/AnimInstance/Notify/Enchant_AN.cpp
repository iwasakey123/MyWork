// Fill out your copyright notice in the Description page of Project Settings.


#include "Enchant_AN.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "Particles/ParticleSystemComponent.h"
#include "Gameframework/Character.h"
#include "KilsuARPG/Item/Weapon/Weapon.h"

void UEnchant_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	if (MeshComp->GetOwner())
	{
		auto ChaRef = Cast<ACharacter>(MeshComp->GetOwner());
		auto EquipmentComp = MeshComp->GetOwner()->FindComponentByClass<UEquipmentComponent>();
		if (EquipmentComp && EquipmentComp->GetCurrentWeapon() && ChaRef)
		{
			FTransform transform;
			if(EquipmentComp->GetCurrentEnchant() == EnchantParticle->GetClass())
				EquipmentComp->EnchantWeapon(EnchantParticle, TrailParticle, HitParticle, SlashParticle, transform, false);	
			else
				EquipmentComp->EnchantWeapon(EnchantParticle , TrailParticle, HitParticle, SlashParticle, transform, true);
		}			
	}
}