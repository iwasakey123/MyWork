// Fill out your copyright notice in the Description page of Project Settings.


#include "DrinkPotion_AN.h"
#include "KilsuARPG/Components/StatsComponent.h"

void UDrinkPotion_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto StatsComp = MeshComp->GetOwner()->FindComponentByClass<UStatsComponent>();
		if (StatsComp)
		{
			StatsComp->UpdateHPMPST(EStat::HP, 600.f, true);			
		}
	}
}