// Fill out your copyright notice in the Description page of Project Settings.


#include "VectorForwardCustom_AN.h"
#include "Kismet/KismetMathLibrary.h"
#include "GameFramework/Character.h"

void UVectorForwardCustom_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto OwnerCharacter = Cast<ACharacter>(MeshComp->GetOwner());
		if (OwnerCharacter)
		{			
			FVector Vec = UKismetMathLibrary::GetForwardVector(MeshComp->GetOwner()->GetRootComponent()->GetComponentRotation()) * Power;
			OwnerCharacter->LaunchCharacter(Vec, true, false);
		}
	}
}