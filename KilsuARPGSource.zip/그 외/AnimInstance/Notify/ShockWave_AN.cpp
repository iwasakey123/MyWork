// Fill out your copyright notice in the Description page of Project Settings.


#include "ShockWave_AN.h"
#include "KilsuARPG/Characters/Boss_Reaper.h"

void UShockWave_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	if (MeshComp->GetOwner())
	{
		auto Reaper = Cast<ABoss_Reaper>(MeshComp->GetOwner());
		if (Reaper)
			Reaper->ShockWave();
	}
}
