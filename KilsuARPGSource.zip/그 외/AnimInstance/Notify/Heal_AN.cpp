// Fill out your copyright notice in the Description page of Project Settings.


#include "Heal_AN.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Components/StatsComponent.h"

void UHeal_AN::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	if (MeshComp->GetOwner())
	{
		auto Char = Cast<ACharacter>(MeshComp->GetOwner());
		if (Char)
		{
			auto StatsComp = Char->FindComponentByClass<UStatsComponent>();
			if (StatsComp)
			{
				StatsComp->UpdateHPMPST(EStat::HP, StatsComp->HP.Max * 0.3f, true);
			}
		}
	}
}