// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "KilsuARPG/Data/Enum/EItem.h"
#include "MyAnimInstance.generated.h"

UCLASS()
class KILSUARPG_API UMyAnimInstance : public UAnimInstance
{
	GENERATED_BODY()
	
public:
	virtual void NativeInitializeAnimation() override;
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;

	UPROPERTY(visibleAnywhere, blueprintReadOnly) float Speed;
	UPROPERTY(visibleAnywhere, blueprintReadOnly) float Direction;
	UPROPERTY(EditAnywhere, blueprintReadWrite) bool bIsCombat;
	UPROPERTY(EditAnywhere, blueprintReadWrite) bool bIsWalk;
	UPROPERTY(EditAnywhere, blueprintReadWrite) bool bIsSprint;
	UPROPERTY(EditAnywhere, blueprintReadWrite) EWeaponType WeaponType;
};
