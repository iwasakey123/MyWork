// Fill out your copyright notice in the Description page of Project Settings.


#include "MyAnimInstance.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
//#include "KilsuARPG/Characters/PlayerCharacter.h"

void UMyAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();
	WeaponType = EWeaponType::NoWeapon;
	
}

void UMyAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	if (TryGetPawnOwner())
	{
		auto Owner = TryGetPawnOwner();
		Speed = Owner->GetVelocity().Size();
		Direction = CalculateDirection(Owner->GetVelocity(), Owner->GetActorRotation());
		if (Owner->GetClass()->ImplementsInterface(UStateInterface::StaticClass()))
		{
			bIsCombat = IStateInterface::Execute_IsCombat(Owner);
			bIsWalk = IStateInterface::Execute_IsWalk(Owner);
			bIsSprint = IStateInterface::Execute_IsSprint(Owner);
		}
	}
}

