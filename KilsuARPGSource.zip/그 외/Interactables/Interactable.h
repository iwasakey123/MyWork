// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "KilsuARPG/Data/Enum/EInteract.h"
#include "Interactable.generated.h"

UCLASS()
class KILSUARPG_API AInteractable : public AActor
{
	GENERATED_BODY()
	
private:
	UPROPERTY(visibleAnywhere, blueprintReadOnly, meta = (AllowPrivateAccess = "true")) UStaticMeshComponent* InteractableMesh;
	UPROPERTY(visibleAnywhere, blueprintReadOnly, meta = (AllowPrivateAccess = "true")) class USphereComponent* InteractCollision;
	//UPROPERTY(VisibleAnywhere, blueprintReadOnly, meta = (AllowPrivateAccess = "true")) class UWidgetComponent* InteractionWidget;

public:
	AInteractable();

	UPROPERTY(EditAnywhere, blueprintReadwrite) EInteractType InteractType;

	FORCEINLINE UStaticMeshComponent* GetDisplayMesh() { return InteractableMesh; }
	FORCEINLINE USphereComponent* GetInteractCollision() { return InteractCollision; }
	//FORCEINLINE UWidgetComponent* GetInteractionWidget() {return InteractionWidget;}

	UFUNCTION() virtual void Interaction(AActor* OwnerActor);

	UFUNCTION() void SetHighlight(bool On);
	UFUNCTION(blueprintCallable) virtual void BeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION(blueprintCallable) virtual void EndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
};
