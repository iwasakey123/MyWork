// Fill out your copyright notice in the Description page of Project Settings.


#include "CelticSword.h"

ACelticSword::ACelticSword()
{
	WeaponInfo.MontageID = FName("Sword");
	WeaponInfo.SocketName = FName("Sword");
	WeaponInfo.UnArmSocketName = FName("UnArm_Sword");
	WeaponInfo.WeaponType = EWeaponType::Sword;
	WeaponInfo.AttackSpeed = 1.f;

	ItemInfo.ItemName = "CelticSword";
	ItemInfo.Description = "CelticSword Description";
	ItemInfo.Quality = EQuality::Rare;
	ItemInfo.Stats.Add(EStat::ATT, 120.f);

	WeaponInfo.AttackSpeed = 1.0f;

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/BP_Prototype/Data/Image/IconGame/Icon/Icon_02.Icon_02'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/Reource_AddNew/Sword/CelticSword/CelticSword.CelticSword'"));
	if (MeshOb.Succeeded())
	{
		ItemInfo.ItemMesh = MeshOb.Object;
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}