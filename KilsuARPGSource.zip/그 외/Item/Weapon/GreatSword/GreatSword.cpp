// Fill out your copyright notice in the Description page of Project Settings.


#include "GreatSword.h"

AGreatSword::AGreatSword()
{
	//ItemInfo.ItemName = "ItemName";
	//ItemInfo.Description = "ItemDescription";
	//ItemInfo.Quality = EQuality::Normal;

	//static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Engine/EngineResources/AICON-Green.AICON-Green'"));
	//if (IconOb.Succeeded())
	//	ItemInfo.Icon = IconOb.Object;

	//static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/StarterContent/Shapes/Shape_Sphere.Shape_Sphere'"));
	//if (MeshOb.Succeeded())
	//{
	//	ItemInfo.ItemMesh = MeshOb.Object;
	//	GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	//}

	WeaponInfo.MontageID = FName("GreatSword");
	WeaponInfo.SocketName = FName("GreatSword");
	WeaponInfo.UnArmSocketName = FName("UnArm_GreatSword");
	WeaponInfo.WeaponType = EWeaponType::GreatSword;
	WeaponInfo.AttackSpeed = 1.f;
}