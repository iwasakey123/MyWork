// Fill out your copyright notice in the Description page of Project Settings.


#include "GS_Atorias_Sword.h"

AGS_Atorias_Sword::AGS_Atorias_Sword()
{
	ItemInfo.ItemName = "AtoriasSword";
	ItemInfo.Description = "ATT + 100, AttackSpeed - 0.2";
	ItemInfo.Quality = EQuality::Legendary;
	ItemInfo.Stats.Add(EStat::ATT, 100.f);	

	WeaponInfo.AttackSpeed = 0.8f;

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/BP_Prototype/Data/Image/greatsword_white.greatsword_white'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/Reource_AddNew/Sword/Artorias_Sword/ArtoriasBossSword.ArtoriasBossSword'"));
	if (MeshOb.Succeeded())
	{
		ItemInfo.ItemMesh = MeshOb.Object;
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}