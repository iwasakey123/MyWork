// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Interactables/Interactable.h"
#include "KilsuARPG/Data/Struct/FItem.h"
#include "Item.generated.h"

UCLASS()
class KILSUARPG_API AItem : public AInteractable
{
	GENERATED_BODY()

public:	
	AItem();
	
	UPROPERTY(EditAnywhere, BlueprintReadwrite) FItemInfo ItemInfo;
	UPROPERTY(EditAnywhere, BlueprintReadwrite, meta = (ClampMin = "1", ClampMax = "300")) int32 FieldAmount;

	virtual void Interaction(AActor* OwnerActor) override;
	UFUNCTION() virtual void Use();
};
