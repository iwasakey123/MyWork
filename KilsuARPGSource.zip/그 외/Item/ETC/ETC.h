// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Item/Item.h"
#include "ETC.generated.h"

/**
 * 
 */
UCLASS()
class KILSUARPG_API AETC : public AItem
{
	GENERATED_BODY()
	
};
