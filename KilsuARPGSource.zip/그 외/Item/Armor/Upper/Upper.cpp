// Fill out your copyright notice in the Description page of Project Settings.


#include "Upper.h"

AUpper::AUpper()
{
	ArmorInfo.ArmorType = EArmorType::Upper;
}