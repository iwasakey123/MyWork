// Fill out your copyright notice in the Description page of Project Settings.


#include "Upper_TypeB.h"

AUpper_TypeB::AUpper_TypeB()
{
	ItemInfo.ItemName = "Knight Shirts";
	ItemInfo.Description = "DEF + 40, HP + 200";
	ItemInfo.Quality = EQuality::Unique;
	ItemInfo.Stats.Add(EStat::A_DEF, 40.f);
	ItemInfo.Stats.Add(EStat::M_DEF, 25.f);
	ItemInfo.Stats.Add(EStat::HP, 200.f);

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/BP_Prototype/Data/Image/IconGame/Icon/armor.armor'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<USkeletalMesh>SKMeshOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/TopBodies/SK_TopBody_E.SK_TopBody_E'"));
	if (SKMeshOb.Succeeded())
	{
		ItemInfo.ItemMeshSK = SKMeshOb.Object;
	}

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/BP/ItemDisplayMesh/TopBody_E.TopBody_E'"));
	if (MeshOb.Succeeded())
	{
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}