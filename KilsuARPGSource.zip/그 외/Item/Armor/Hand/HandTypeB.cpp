// Fill out your copyright notice in the Description page of Project Settings.


#include "HandTypeB.h"

AHandTypeB::AHandTypeB()
{
	ItemInfo.ItemName = "Dark Glove";
	ItemInfo.Description = "DEF + 15";
	ItemInfo.Quality = EQuality::Unique;
	ItemInfo.Stats.Add(EStat::A_DEF, 15.f);
	ItemInfo.Stats.Add(EStat::M_DEF, 20.f);
	//ItemInfo.Stats.Add(EStat::HP, 150.f);

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/BP_Prototype/Data/Image/IconGame/Icon/gauntlet.gauntlet'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<USkeletalMesh>SKMeshOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Gauntlets/SK_GauntletsMerge.SK_GauntletsMerge'"));
	if (SKMeshOb.Succeeded())
	{
		ItemInfo.ItemMeshSK = SKMeshOb.Object;
	}

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/BP/ItemDisplayMesh/Gauntlets_B.Gauntlets_B'"));
	if (MeshOb.Succeeded())
	{
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}