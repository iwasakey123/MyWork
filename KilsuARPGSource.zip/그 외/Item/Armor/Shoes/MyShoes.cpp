// Fill out your copyright notice in the Description page of Project Settings.


#include "MyShoes.h"

AMyShoes::AMyShoes()
{
	ItemInfo.ItemName = "Dark Shoes";
	ItemInfo.Description = "MoveSpeed + 200";
	ItemInfo.Quality = EQuality::Unique;
	ItemInfo.Stats.Add(EStat::MoveSpeed, 200.f);

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/BP_Prototype/Data/Image/IconGame/Icon/Boots01.Boots01'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<USkeletalMesh>SKMeshOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Shoes/SK_Boots.SK_Boots'"));
	if (SKMeshOb.Succeeded())
	{
		ItemInfo.ItemMeshSK = SKMeshOb.Object;
	}

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/BP/ItemDisplayMesh/Boots_B.Boots_B'"));
	if (MeshOb.Succeeded())
	{
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}