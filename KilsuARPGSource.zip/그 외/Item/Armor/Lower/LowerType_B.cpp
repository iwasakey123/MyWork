// Fill out your copyright notice in the Description page of Project Settings.


#include "LowerType_B.h"

ALowerType_B::ALowerType_B()
{
	ItemInfo.ItemName = "Dark Lower";
	ItemInfo.Description = "DEF + 25, HP + 120";
	ItemInfo.Quality = EQuality::Unique;
	ItemInfo.Stats.Add(EStat::A_DEF, 25.f);
	ItemInfo.Stats.Add(EStat::M_DEF, 16.f);
	ItemInfo.Stats.Add(EStat::HP, 120.f);

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/BP_Prototype/Data/Image/IconGame/Icon/Pants.Pants'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<USkeletalMesh>SKMeshOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/BotBodies/SK_BotBody_B.SK_BotBody_B'"));
	if (SKMeshOb.Succeeded())
	{
		ItemInfo.ItemMeshSK = SKMeshOb.Object;
	}

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/BP/ItemDisplayMesh/Lower_B.Lower_B'"));
	if (MeshOb.Succeeded())
	{
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}