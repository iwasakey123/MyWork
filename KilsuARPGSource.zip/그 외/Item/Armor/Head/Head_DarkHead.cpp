// Fill out your copyright notice in the Description page of Project Settings.


#include "Head_DarkHead.h"

AHead_DarkHead::AHead_DarkHead()
{
	ItemInfo.ItemName = "Knight Helmet";
	ItemInfo.Description = "DEF + 25, HP + 80";
	ItemInfo.Quality = EQuality::Unique;
	ItemInfo.Stats.Add(EStat::A_DEF, 25.f);
	ItemInfo.Stats.Add(EStat::M_DEF, 13.f);
	ItemInfo.Stats.Add(EStat::HP, 80.f);

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/BP_Prototype/Data/Image/IconGame/Icon/Helmet.Helmet'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<USkeletalMesh>SKMeshOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Helmet/SK_Helmet_D.SK_Helmet_D'"));
	if (SKMeshOb.Succeeded())
	{
		ItemInfo.ItemMeshSK = SKMeshOb.Object;		
	}

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/BP/ItemDisplayMesh/DarkHelmet.DarkHelmet'"));
	if (MeshOb.Succeeded())
	{
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}