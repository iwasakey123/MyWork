// Fill out your copyright notice in the Description page of Project Settings.


#include "Potion.h"
#include "Components/SphereComponent.h"
#include "KilsuARPG/Components/MontageComponent.h"

APotion::APotion()
{
	ConsumableInfo.ConsumableType = EConsumableType::Potion;
	PotionInfo.PotionType = EPotionType::HPPotion;

	ItemInfo.ItemName = "HPPotion";
	ItemInfo.Description = "HP + 600up!";

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/Reource_AddNew/Texture/Items/Icon_Potion.Icon_Potion'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/BP/ItemDisplayMesh/S_FlaskHP.S_FlaskHP'"));
	if (MeshOb.Succeeded())
	{
		ItemInfo.ItemMesh = MeshOb.Object;		
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}

void APotion::Use()
{	
	auto MontageComp = GetOwner()->FindComponentByClass<UMontageComponent>();
	if (MontageComp)
	{
		MontageComp->PlayMontage(EMontageType::Drink);
		//UE_LOG(LogTemp, Warning, TEXT("usepotion"));
	}
	Destroy();
}