// Fill out your copyright notice in the Description page of Project Settings.


#include "Consumable.h"

AConsumable::AConsumable()
{
	//ItemInfo.ItemName = "ItemName";
	//ItemInfo.Description = "ItemDescription";
	ItemInfo.CanUse = true;
	ItemInfo.CanStack = true;
	ItemInfo.ItemType = EItemType::Consumable;
	ItemInfo.Quality = EQuality::Normal;
	//ConsumableInfo.ConsumableType = EConsumableType::;

	//static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Engine/EngineResources/AICON-Green.AICON-Green'"));
	//if (IconOb.Succeeded())
	//	ItemInfo.Icon = IconOb.Object;

	//static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/StarterContent/Shapes/Shape_Sphere.Shape_Sphere'"));
	//if (MeshOb.Succeeded())
	//{
	//	ItemInfo.ItemMesh = MeshOb.Object;
	//	GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	//}
}