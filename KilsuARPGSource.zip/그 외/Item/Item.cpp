// Fill out your copyright notice in the Description page of Project Settings.

#include "Item.h"
#include "KilsuARPG/Components/InventoryComponent.h"
#include "KilsuARPG/UI/InventoryUI/ItemInteractionWidget.h"
#include "Components/WidgetComponent.h"

AItem::AItem()
{	
	//������ �⺻����
	GetDisplayMesh()->SetSimulatePhysics(true);
	GetDisplayMesh()->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Overlap);
	GetDisplayMesh()->SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic, ECollisionResponse::ECR_Block);

	InteractType = EInteractType::Item;

	//������ �⺻����
	ItemInfo.ItemName = "ItemName";
	ItemInfo.Description = "ItemDescription";
	ItemInfo.CanUse = true;
	ItemInfo.CanStack = true;
	ItemInfo.ItemType = EItemType::Consumable;
	ItemInfo.Quality = EQuality::Normal;

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Engine/EngineResources/AICON-Green.AICON-Green'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;
	
	//�ʵ忡 ���� ����
	FieldAmount = 1;

}

//��ȣ�ۿ�
void AItem::Interaction(AActor* OwnerActor)
{	
	if (OwnerActor)
	{
		auto Inventory = OwnerActor->FindComponentByClass<UInventoryComponent>();
		if (Inventory)
		{
			FieldAmount = Inventory->AddItem(this->GetClass(), FieldAmount);
			if (FieldAmount == 0)
			{
				Destroy();
			}
		}
	}
}

//���
void AItem::Use()
{
	Destroy();
}


