// Fill out your copyright notice in the Description page of Project Settings.


#include "Interactable.h"
#include "Components/SphereComponent.h"
#include "KilsuARPG/Components/InteractComponent.h"

AInteractable::AInteractable()
{
	InteractableMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("InteractableMesh"));
	InteractableMesh->SetupAttachment(RootComponent);

	InteractCollision = CreateDefaultSubobject<USphereComponent>(TEXT("InteractCollision"));
	InteractCollision->SetupAttachment(InteractableMesh);
	InteractCollision->InitSphereRadius(300.f);
	InteractCollision->OnComponentBeginOverlap.AddDynamic(this, &AInteractable::BeginOverlap);
	InteractCollision->OnComponentEndOverlap.AddDynamic(this, &AInteractable::EndOverlap);
	
	//static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/StarterContent/Shapes/Shape_Sphere.Shape_Sphere'"));
	//if (MeshOb.Succeeded())
	//	InteractableMesh->SetStaticMesh(MeshOb.Object);
}

void AInteractable::SetHighlight(bool On)
{
	InteractableMesh->SetRenderCustomDepth(On);	
}

void AInteractable::BeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	auto InteractComp = OtherActor->FindComponentByClass<UInteractComponent>();
	if (InteractComp)
		IInteractInterface::Execute_RegisterInteractable(InteractComp, this);
}
void AInteractable::EndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	auto InteractComp = OtherActor->FindComponentByClass<UInteractComponent>();
	if (InteractComp)
		IInteractInterface::Execute_UnRegisterInteractable(InteractComp, this);
}

void AInteractable::Interaction(AActor* OwnerActor)
{
	switch (InteractType)
	{
	case EInteractType::Item:
		//override
		break;
	case EInteractType::NPC:
		break;
	case EInteractType::Door:
		break;
	}
}


