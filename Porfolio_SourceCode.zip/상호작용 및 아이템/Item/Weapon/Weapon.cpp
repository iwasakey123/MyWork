// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapon.h"
#include "KilsuARPG/Components/EquipmentComponent.h"

AWeapon::AWeapon()
{
	//InteractType = EInteractType::Item;

	//ItemInfo.ItemName = "ItemName";
	//ItemInfo.Description = "ItemDescription";
	ItemInfo.CanUse = true;
	ItemInfo.CanStack = false;
	ItemInfo.ItemType = EItemType::Weapon;
	//ItemInfo.Quality = EQuality::Normal;

	//static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Engine/EngineResources/AICON-Green.AICON-Green'"));
	//if (IconOb.Succeeded())
	//	ItemInfo.Icon = IconOb.Object;

	//static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/StarterContent/Shapes/Shape_Sphere.Shape_Sphere'"));
	//if (MeshOb.Succeeded())
	//{
	//	ItemInfo.ItemMesh = MeshOb.Object;
	//	GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	//}

	//WeaponInfo.MontageID = FName("");
	//WeaponInfo.SocketName = FName("");
	//WeaponInfo.UnArmSocketName = FName("");
	//WeaponInfo.WeaponType = EWeaponType::GreatSword;
	//WeaponInfo.AttackSpeed = 1.f;
}

void AWeapon::Use()
{
	auto EquipmentComp = GetOwner()->FindComponentByClass<UEquipmentComponent>();
	if (EquipmentComp)
		EquipmentComp->EquipWeapon(this->GetClass());
	Destroy();
}