// Fill out your copyright notice in the Description page of Project Settings.


#include "GS_DarkSoulSword.h"

AGS_DarkSoulSword::AGS_DarkSoulSword()
{
	ItemInfo.ItemName = "DarkSoulSword";
	ItemInfo.Description = "ATT + 100, CritChance + 10, STR + 10, AttackSpeed + 0.5";
	ItemInfo.Quality = EQuality::Unique;
	ItemInfo.Stats.Add(EStat::ATT, 100.f);
	ItemInfo.Stats.Add(EStat::CritChance, 10.f);
	ItemInfo.Stats.Add(EStat::STR, 15.f);
	
	WeaponInfo.AttackSpeed = 1.5f;

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/BP_Prototype/Data/Image/Texture_GreatSword_00.Texture_GreatSword_00'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;
	
	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/Reource_AddNew/Sword/DraksoulGS/DarkSoulGreatSword.DarkSoulGreatSword'"));
	if (MeshOb.Succeeded())
	{
		ItemInfo.ItemMesh = MeshOb.Object;
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}
}