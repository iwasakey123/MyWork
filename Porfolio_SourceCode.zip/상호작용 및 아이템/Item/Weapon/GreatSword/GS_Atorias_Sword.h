// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Item/Weapon/GreatSword/GreatSword.h"
#include "GS_Atorias_Sword.generated.h"

UCLASS()
class KILSUARPG_API AGS_Atorias_Sword : public AGreatSword
{
	GENERATED_BODY()
	
public:
	AGS_Atorias_Sword();
};
