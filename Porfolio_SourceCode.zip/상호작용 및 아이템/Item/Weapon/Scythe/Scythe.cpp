// Fill out your copyright notice in the Description page of Project Settings.


#include "Scythe.h"

AScythe::AScythe()
{
	ItemInfo.ItemName = "ReaperScythe";
	ItemInfo.Description = "ReaperScythe Description";	
	ItemInfo.Quality = EQuality::Rare;
	ItemInfo.Stats.Add(EStat::ATT, 170.f);
	ItemInfo.Stats.Add(EStat::MTT, 170.f);
	ItemInfo.Stats.Add(EStat::CritChance, 10.f);
	ItemInfo.Stats.Add(EStat::STR, 15.f);
	ItemInfo.Stats.Add(EStat::INT, 10.f);

	static ConstructorHelpers::FObjectFinder<UTexture2D>IconOb(TEXT("Texture2D'/Game/Reource_AddNew/Texture/scythe.scythe'"));
	if (IconOb.Succeeded())
		ItemInfo.Icon = IconOb.Object;

	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshOb(TEXT("StaticMesh'/Game/Model/Humanoid/TheReaper/Meshes/Characters/Separates/Acessories/ST_Scythe.ST_Scythe'"));
	if (MeshOb.Succeeded())
	{
		ItemInfo.ItemMesh = MeshOb.Object;
		GetDisplayMesh()->SetStaticMesh(MeshOb.Object);
	}

	WeaponInfo.MontageID = FName("Scythe");
	WeaponInfo.SocketName = FName("Scythe");
	WeaponInfo.UnArmSocketName = FName("ScytheBack");
	WeaponInfo.WeaponType = EWeaponType::Scythe;
	WeaponInfo.AttackSpeed = 1.f;
}