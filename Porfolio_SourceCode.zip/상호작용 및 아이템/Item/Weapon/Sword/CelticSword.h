// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Item/Weapon/Weapon.h"
#include "CelticSword.generated.h"

UCLASS()
class KILSUARPG_API ACelticSword : public AWeapon
{
	GENERATED_BODY()

public:
	ACelticSword();
	
};
