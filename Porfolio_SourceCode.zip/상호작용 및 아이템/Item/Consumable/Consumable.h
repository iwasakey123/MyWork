// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Item/Item.h"
#include "KilsuARPG/Data/Enum/EStat.h"
#include "Consumable.generated.h"

UCLASS()
class KILSUARPG_API AConsumable : public AItem
{
	GENERATED_BODY()
	
public:
	AConsumable();
	UPROPERTY() FConsumableInfo ConsumableInfo;
};
