// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Item/Item.h"
#include "Armor.generated.h"

/**
 * 
 */
UCLASS()
class KILSUARPG_API AArmor : public AItem
{
	GENERATED_BODY()
	
public:
	AArmor();

	UPROPERTY() FArmorInfo ArmorInfo;

	virtual void Use() override;
};
