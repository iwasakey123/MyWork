// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Item/Armor/Armor.h"
#include "Cape.generated.h"

UCLASS()
class KILSUARPG_API ACape : public AArmor
{
	GENERATED_BODY()
	
public:
	ACape();
};
