// Fill out your copyright notice in the Description page of Project Settings.


#include "Cape.h"

ACape::ACape()
{
	ArmorInfo.ArmorType = EArmorType::Cape;
}