// Fill out your copyright notice in the Description page of Project Settings.


#include "Hand.h"

AHand::AHand()
{
	ArmorInfo.ArmorType = EArmorType::Hand;
}