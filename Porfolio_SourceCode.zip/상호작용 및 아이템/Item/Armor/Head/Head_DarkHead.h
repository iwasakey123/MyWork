// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Item/Armor/Head/Head.h"
#include "Head_DarkHead.generated.h"

/**
 * 
 */
UCLASS()
class KILSUARPG_API AHead_DarkHead : public AHead
{
	GENERATED_BODY()
	
public:
	AHead_DarkHead();
};
