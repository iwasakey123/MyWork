// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Item/Armor/Lower/Lower.h"
#include "LowerType_B.generated.h"

UCLASS()
class KILSUARPG_API ALowerType_B : public ALower
{
	GENERATED_BODY()
	
public:
	ALowerType_B();
};
