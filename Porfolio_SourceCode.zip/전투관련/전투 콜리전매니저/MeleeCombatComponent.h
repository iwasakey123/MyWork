// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "KilsuARPG/Data/Struct/FDamage.h"
#include "KilsuARPG/Data/Struct/FCollisionComponent.h"
#include "MeleeCombatComponent.generated.h"

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API UMeleeCombatComponent : public UActorComponent
{
	GENERATED_BODY()

private:
	UPROPERTY() FDamage SaveDamage;
	UPROPERTY() ACharacter* OwnerCharacter;

	//MelleCollision Variables
	UPROPERTY() bool bCollisionActivation;
	UPROPERTY() bool bPerformTrace;
	UPROPERTY() float TraceRadius = 0.1f;	
	UPROPERTY() AActor* DamagedActor;
	UPROPERTY() TArray<AActor*> AlreadyDamagedActors;
	UPROPERTY() TArray<FCollisionComp> CollisionComps;
	UPROPERTY() TMap<FName, FVector> LastSocketLocations;
	UPROPERTY() FDamage CustomDamage;

	UPROPERTY() class UMaterialInterface* Mat;
	   
public:		
	UMeleeCombatComponent();	
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	//Declare Event
	DECLARE_EVENT_OneParam(ACharacter, FMeleeCollision, ECollisionParts) FMeleeCollision MeleeCollisionActivate;
	DECLARE_EVENT_OneParam(ACharacter, FAttackHit, FHitResult) FAttackHit AttackHit;
	DECLARE_EVENT(ACharacter, FGroggy) FGroggy Groggy;
			
	//MeleeCollision Functions
	UFUNCTION() void ActivateCollision(ECollisionParts CollisionType, float TraceSize, FDamage DamageType);
	UFUNCTION() void SetCollisionComponent(class UPrimitiveComponent* WeaponComp, TArray<FName>SocketNames);
	UFUNCTION() void PerformTrace();
	UFUNCTION() void UpdateLastSocketPosition();
	UFUNCTION() void DeactivateCollision();
	UFUNCTION() void HitChangeMats();

	FORCEINLINE AActor* GetDamageActor() { return DamagedActor; }
	FORCEINLINE FDamage GetCustomDamage() { return CustomDamage; }
	FORCEINLINE bool IsPerformTrace() { return bPerformTrace; }
	FORCEINLINE void SetTraceSize(float size) { TraceRadius = size; }
};
