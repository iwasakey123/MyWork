// Fill out your copyright notice in the Description page of Project Settings.


#include "MeleeCombatComponent.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "DestructibleComponent.h"
#include "Materials/MaterialInterface.h"

UMeleeCombatComponent::UMeleeCombatComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	bCollisionActivation = false;
	bPerformTrace = false;
	OwnerCharacter = Cast<ACharacter>(GetOwner());

	static ConstructorHelpers::FObjectFinder<UMaterialInterface>HitMatOb(TEXT("MaterialInstanceConstant'/Game/Reource_AddNew/Materials/HitMaterial/Materials/HitMaterial_Inst.HitMaterial_Inst'"));
	if (HitMatOb.Succeeded())
	{
		Mat = HitMatOb.Object;
	}
}

void UMeleeCombatComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
		
	if (bCollisionActivation == true)
	{
		//������ Ȱ��ȭ
		if (bPerformTrace == true)
			PerformTrace();
		//��Ĺ��ġ���� ��ƽ���� ������Ʈ�մϴ�.
		UpdateLastSocketPosition();
		bPerformTrace = true;
	}
}

void UMeleeCombatComponent::ActivateCollision(ECollisionParts CollisionType, float TraceSize, FDamage DamageType)
{
	//����, �ʱ�ȭ
	TraceRadius = TraceSize;	
	bCollisionActivation = true;
	MeleeCollisionActivate.Broadcast(CollisionType);	
	CustomDamage = DamageType;
}

void UMeleeCombatComponent::DeactivateCollision()
{	
	//�ߴ�, ������ ����α�, �ʱ�ȭ�ϱ� 
	bCollisionActivation = false;
	bPerformTrace = false;
	AlreadyDamagedActors.Empty();
	LastSocketLocations.Empty();
	DamagedActor = nullptr;
	CustomDamage.DamageType = EDamageType::Normal;
	CustomDamage.bIsCrit = false;
	CustomDamage.bCanGuard = false;
	CustomDamage.bCanParry = false;
	CustomDamage.Damage = 0.f;
}

void UMeleeCombatComponent::SetCollisionComponent(UPrimitiveComponent* WeaponComp, TArray<FName>SocketNames)
{
	//ĳ������ ���������� �����ɴϴ�.
	FCollisionComp CollisionComponent;
	CollisionComponent.WeaponComp = WeaponComp;
	CollisionComponent.SocketNames = SocketNames;
	CollisionComps.Add(CollisionComponent);
	UpdateLastSocketPosition();
}

//������ġ ������Ʈ
void UMeleeCombatComponent::UpdateLastSocketPosition()
{	
	if(CollisionComps.Num() <= 0) return;
	for (FCollisionComp CollisionComp : CollisionComps)
	{
		if (IsValid(CollisionComp.WeaponComp))
		{
			//������ ������ �̸��� ���� �����̸��� ����� ������ ����
			for (FName SocketName : CollisionComp.SocketNames)
			{
				FName AppendName = FName(*(UKismetSystemLibrary::GetDisplayName(CollisionComp.WeaponComp).Append(SocketName.ToString())));
				LastSocketLocations.Add(AppendName, CollisionComp.WeaponComp->GetSocketLocation(SocketName));			
			}
		}		
	}
}

void UMeleeCombatComponent::PerformTrace()
{
	//SphereTraceMulti�� ������ ����
	TArray<TEnumAsByte<EObjectTypeQuery>>ObjectTypes;	
	ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
	ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_Destructible));
	TArray<AActor*>IgnoreActors; IgnoreActors.Empty();
	IgnoreActors.Add(GetOwner());
	TArray<FHitResult>Hits; Hits.Empty();
	for (FCollisionComp CollisionComp : CollisionComps)	
		if (IsValid(CollisionComp.WeaponComp))		
			for (FName SocketName : CollisionComp.SocketNames)
			{
				FName FindName = FName(*(UKismetSystemLibrary::GetDisplayName(CollisionComp.WeaponComp).Append(SocketName.ToString())));
				FVector StartPos = LastSocketLocations.FindRef(FindName);
				FVector EndPos = CollisionComp.WeaponComp->GetSocketLocation(SocketName);//1ƽ���� ������ġ, ������ ������ġ
				UKismetSystemLibrary::SphereTraceMultiForObjects(GetWorld(), StartPos, EndPos, TraceRadius, ObjectTypes, false, IgnoreActors, EDrawDebugTrace::None, Hits, true);
				for (FHitResult Hit : Hits)
				{
					//�������Ͱ� 1���̶� ���ڸ�
					if (IsValid(Hit.Actor.Get()) && AlreadyDamagedActors.Contains(Hit.Actor.Get()) == false)
					{
						DamagedActor = Hit.Actor.Get();
						//�������� tick���� �߻�Ǳ⶧���� �ߺ��̵ɼ��ִ�.
						//1���� 1�뾿�� ���������� 1���������� AlreadyDamagedActors������ �����Ͽ� �ߺ��� ���Ѵ�. �������� �ߴ��ҽ� �̹迭�� ����ش�.
						AlreadyDamagedActors.Add(Hit.Actor.Get());
						//���ݼ����� AttackHit�Լ� Delegate(�̺�Ʈ����ó)
						AttackHit.Broadcast(Hit);
					}
					if (IsValid(Hit.Component.Get()))
					{
						//���� ����� DestructibleMesh���, �浹����
						auto localDes = Cast<UDestructibleComponent>(Hit.Component.Get());
						if(localDes)
							localDes->ApplyRadiusDamage(1000.f, Hit.Location, 50.f, 3000.f, true);
					}
				}
			}
}

//�ǰݽ� �����ǰ���ó�� ���� ���ϰ����ִ� �Լ��Դϴ�.
void UMeleeCombatComponent::HitChangeMats()
{
	if (OwnerCharacter && OwnerCharacter->GetMesh()->bPauseAnims == false)
	{		
		if (Mat)
		{
			OwnerCharacter->GetMesh()->SetMaterial(0, Mat);
			FTimerHandle handle[5];
			float delay = 0.1f;
			//delay��� �����Լ��� Ÿ�̸ӷ� �����Ͽ����ϴ�.
			GetWorld()->GetTimerManager().SetTimer(handle[0], FTimerDelegate::CreateLambda([&]()
			{
				if (OwnerCharacter->GetMesh()->bPauseAnims == false)
					OwnerCharacter->GetMesh()->SetMaterial(0, nullptr);
				GetWorld()->GetTimerManager().ClearTimer(handle[0]);
			}), delay, false);
			OwnerCharacter->GetMesh()->SetMaterial(1, Mat);
			OwnerCharacter->GetMesh()->SetMaterial(2, Mat);
			GetWorld()->GetTimerManager().SetTimer(handle[1], FTimerDelegate::CreateLambda([&]()
			{
				if (OwnerCharacter->GetMesh()->bPauseAnims == false)
				{
					OwnerCharacter->GetMesh()->SetMaterial(1, nullptr);
					OwnerCharacter->GetMesh()->SetMaterial(2, nullptr);
				}
				GetWorld()->GetTimerManager().ClearTimer(handle[1]);
			}), delay, false);
			OwnerCharacter->GetMesh()->SetMaterial(3, Mat);
			OwnerCharacter->GetMesh()->SetMaterial(4, Mat);
			GetWorld()->GetTimerManager().SetTimer(handle[2], FTimerDelegate::CreateLambda([&]()
			{
				if (OwnerCharacter->GetMesh()->bPauseAnims == false)
				{
					OwnerCharacter->GetMesh()->SetMaterial(3, nullptr);
					OwnerCharacter->GetMesh()->SetMaterial(4, nullptr);
				}
				GetWorld()->GetTimerManager().ClearTimer(handle[2]);
			}), delay, false);
			OwnerCharacter->GetMesh()->SetMaterial(5, Mat);
			OwnerCharacter->GetMesh()->SetMaterial(6, Mat);
			GetWorld()->GetTimerManager().SetTimer(handle[3], FTimerDelegate::CreateLambda([&]()
			{
				if (OwnerCharacter->GetMesh()->bPauseAnims == false)
				{
					OwnerCharacter->GetMesh()->SetMaterial(5, nullptr);
					OwnerCharacter->GetMesh()->SetMaterial(6, nullptr);
				}
				GetWorld()->GetTimerManager().ClearTimer(handle[3]);
			}), delay, false);
			OwnerCharacter->GetMesh()->SetMaterial(7, Mat);
			OwnerCharacter->GetMesh()->SetMaterial(8, Mat);
			OwnerCharacter->GetMesh()->SetMaterial(9, Mat);
			GetWorld()->GetTimerManager().SetTimer(handle[4], FTimerDelegate::CreateLambda([&]()
			{
				if (OwnerCharacter->GetMesh()->bPauseAnims == false)
				{
					OwnerCharacter->GetMesh()->SetMaterial(7, nullptr);
					OwnerCharacter->GetMesh()->SetMaterial(8, nullptr);
					OwnerCharacter->GetMesh()->SetMaterial(9, nullptr);
				}
				GetWorld()->GetTimerManager().ClearTimer(handle[4]);		
			}), delay, false);
		}
	}
}
