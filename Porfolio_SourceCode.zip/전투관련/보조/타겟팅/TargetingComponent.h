// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "KilsuARPG/Data/Enum/ETargetSize.h"
#include "TargetingComponent.generated.h"

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API UTargetingComponent : public UActorComponent
{
	GENERATED_BODY()

private:
	UPROPERTY() class UArrowComponent* ArrowComp;
	UPROPERTY() class ACharacter* OwnerCharacter;
	UPROPERTY() bool bTargetEnabled;
	UPROPERTY() AActor* SelectActor;
	UPROPERTY() float MaxTargetingDistance;
	UPROPERTY() FTimerHandle CheckTargetTimerHandle;
	UPROPERTY() FTimerHandle bUCRHandle;
	UPROPERTY() ETargetSize TargetSize;

public:
	UTargetingComponent();
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	FORCEINLINE FVector2D GetActorScreenPosition(AActor* Actor);
	FORCEINLINE bool IsTargetEnabled() { return bTargetEnabled; }

	UFUNCTION() void Initialize(UArrowComponent* Arrow);
	UFUNCTION() void ToggleCameraLock();
	UFUNCTION() void FindTarget();
	UFUNCTION() void CheckTarget();
	UFUNCTION() void EnableCameraLock();
	UFUNCTION() void DisableCameraLock();
	UFUNCTION() void UpdateIgnoreInput();
	UFUNCTION() bool IsInViewport(FVector2D ScreenPos);
};
