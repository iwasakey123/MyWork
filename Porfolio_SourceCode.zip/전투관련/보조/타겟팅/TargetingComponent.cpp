// Fill out your copyright notice in the Description page of Project Settings.


#include "TargetingComponent.h"
#include "Components/ArrowComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Camera/CameraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "GameFramework/SpringArmComponent.h"
#include "KilsuARPG/Data/Interface/TargetingInterface.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"

UTargetingComponent::UTargetingComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	bTargetEnabled = false;
	SelectActor = nullptr;
	MaxTargetingDistance = 3000.f;
	OwnerCharacter = Cast<ACharacter>(GetOwner());
}

void UTargetingComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	
	//Ÿ������ Ȱ��ȭ�Ǹ� ����˴ϴ�.
	if (bTargetEnabled)
	{	
		//�����Ÿ��ȿ� �ְ� Ÿ���� �������ִ��� üũ
		if ((SelectActor != nullptr) && (0 <= GetOwner()->GetDistanceTo(SelectActor)) && (GetOwner()->GetDistanceTo(SelectActor) <= MaxTargetingDistance))
		{				
			if (ArrowComp)
			{				
				FRotator CurrentRot = ArrowComp->GetComponentRotation();
				FRotator TargetRot = OwnerCharacter->GetControlRotation();
				FRotator NewRot = UKismetMathLibrary::RInterpTo_Constant(CurrentRot, TargetRot, DeltaTime, 250.f);
				ArrowComp->SetWorldRotation(FRotator(0.f, 0.f, NewRot.Yaw));

				CurrentRot = OwnerCharacter->GetControlRotation();
				//Ÿ�ٻ���� �ʹ� ũ�ٸ� Ÿ������ ������ �ʹ� �����Ĵٺ��Ե˴ϴ�. �׷��� Ÿ�ٻ�������� Big���� �˻��Ͽ� ������ ������ 60������ �����ϴ�. 
				TargetRot = (GetOwner()->GetDistanceTo(SelectActor) <= 250.f) && (TargetSize == ETargetSize::Big) ? UKismetMathLibrary::FindLookAtRotation(GetOwner()->GetActorLocation() - FVector(0.f, 0.f, -60.f), SelectActor->GetActorLocation()) : UKismetMathLibrary::FindLookAtRotation(GetOwner()->GetActorLocation(), SelectActor->GetActorLocation());

				NewRot = UKismetMathLibrary::RInterpTo_Constant(CurrentRot, TargetRot, DeltaTime, 300.f);
				OwnerCharacter->GetController()->SetControlRotation(NewRot);
			}
		}
		else
			DisableCameraLock();
	}
}

void UTargetingComponent::Initialize(UArrowComponent* Arrow)
{
	if (Arrow)
	{
		ArrowComp = Arrow;
		ArrowComp->SetUsingAbsoluteRotation(true);//����ȸ���� ���
	}
	else UE_LOG(LogTemp, Warning, TEXT("Arrow is Not Valid"));
}

void UTargetingComponent::ToggleCameraLock()
{
	if (bTargetEnabled)
	{
		DisableCameraLock();
	}
	else FindTarget();
}

void UTargetingComponent::FindTarget()
{	
	TArray<AActor*>PotentialActors; PotentialActors.Empty();
	TArray<AActor*>Outers; Outers.Empty();
	UGameplayStatics::GetAllActorsWithInterface(GetWorld(), UTargetingInterface::StaticClass(), Outers);
	for (AActor* Outer : Outers)
	{		
		if (Outer->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) && IStateInterface::Execute_IsAlive(Outer) && ITargetingInterface::Execute_IsTargetable(Outer) && GetOwner() != SelectActor)
		{
			//����Ʈ���� ���� �ִ��� üũ�մϴ�. �����Ÿ����� �ִ����� üũ�մϴ�.
			if (IsInViewport(GetActorScreenPosition(Outer)) && GetOwner()->GetDistanceTo(Outer) <= MaxTargetingDistance)
			{				
				PotentialActors.Add(Outer);
			}
		}
	}

	float Dot = -1;
	for (AActor* PotentialActor : PotentialActors)
	{
		if (OwnerCharacter && PotentialActor)
		{
			auto Cam = OwnerCharacter->FindComponentByClass<UCameraComponent>();
			auto CenterOfMass = (Cast<ACharacter>(PotentialActor))->GetMesh()->GetCenterOfMass();
			auto CamLocation = Cam->GetComponentLocation();
			auto CamForward = Cam->GetForwardVector();
			auto dot = FVector::DotProduct(FVector(CenterOfMass - CamLocation).GetSafeNormal(), CamForward);//ī�޶� ���� ����� ������ �����߽���ġ�� ������ �����մϴ�.
			if (dot > 0.8 && dot > Dot)//�� 38�� �̳��Ͻ�
			{
				Dot = dot;
				SelectActor = PotentialActor;
			}
		}
	}

	if (SelectActor)
	{	
		EnableCameraLock();
	}
}

void UTargetingComponent::CheckTarget()
{
	//Ÿ������ ���� ����ִ��� Ȯ���մϴ�. �ƴ϶�� Ÿ������ Ǯ�� �ٽ� Ž���մϴ�.
	if (IStateInterface::Execute_IsAlive(SelectActor) == false || ITargetingInterface::Execute_IsTargetable(SelectActor) == false)
	{
		DisableCameraLock();
		FindTarget();
	}
}

void UTargetingComponent::EnableCameraLock()
{
	if (SelectActor)
	{
		ITargetingInterface::Execute_OnSelected(SelectActor);
		TargetSize = ITargetingInterface::Execute_GetTargetSize(SelectActor);
		//�������� �ӵ� ����
		bTargetEnabled = true;
		auto springArm = OwnerCharacter->FindComponentByClass<USpringArmComponent>();
		if (springArm && springArm->bEnableCameraLag)
			springArm->CameraLagSpeed = 7.f;
		//ī�޶�ȸ�� �Է� ����
		UpdateIgnoreInput();
		//�����Լ��� delay ����
		GetWorld()->GetTimerManager().SetTimer(bUCRHandle, FTimerDelegate::CreateLambda([&]() {
			OwnerCharacter->bUseControllerRotationYaw = true;
			GetWorld()->GetTimerManager().ClearTimer(bUCRHandle);
		}), 0.5f, false);
		//ĳ���� �����Ʈ ����
		OwnerCharacter->GetCharacterMovement()->bUseControllerDesiredRotation = true;
		OwnerCharacter->GetCharacterMovement()->bOrientRotationToMovement = false;
		FTimerDelegate TimerDel;
		TimerDel.BindUFunction(this, FName("CheckTarget"));
		GetWorld()->GetTimerManager().SetTimer(CheckTargetTimerHandle, TimerDel, 0.15f, true);
		UpdateIgnoreInput();
	}
}

void UTargetingComponent::DisableCameraLock()
{
	bTargetEnabled = false;
	ITargetingInterface::Execute_DeSelected(SelectActor);
	SelectActor = nullptr;
	auto springArm = OwnerCharacter->FindComponentByClass<USpringArmComponent>();
	if (springArm && springArm->bEnableCameraLag)
		springArm->CameraLagSpeed = 10.f;
	OwnerCharacter->bUseControllerRotationYaw = false;
	OwnerCharacter->GetCharacterMovement()->bUseControllerDesiredRotation = false;
	OwnerCharacter->GetCharacterMovement()->bOrientRotationToMovement = true;
	GetWorld()->GetTimerManager().ClearTimer(CheckTargetTimerHandle);
	GetWorld()->GetTimerManager().ClearTimer(bUCRHandle);
	UpdateIgnoreInput();
}

FVector2D UTargetingComponent::GetActorScreenPosition(AActor* Actor)
{
	FVector2D ScreenPos = FVector2D(1, 1);
	UGameplayStatics::ProjectWorldToScreen(UGameplayStatics::GetPlayerController(GetWorld(), 0), Actor->GetActorLocation(), ScreenPos);
	return ScreenPos;
}

void UTargetingComponent::UpdateIgnoreInput()
{
	if (OwnerCharacter)
	{
		if (bTargetEnabled)
			OwnerCharacter->GetController()->SetIgnoreLookInput(true);
		else
			OwnerCharacter->GetController()->ResetIgnoreLookInput();
	}
}

bool UTargetingComponent::IsInViewport(FVector2D ScreenPos)
{
	FVector2D ViewportSize;
	GEngine->GameViewport->GetViewportSize(ViewportSize);
	return (ScreenPos.X > 0 && ScreenPos.Y > 0 && ScreenPos.X <= ViewportSize.X && ScreenPos.Y <= ViewportSize.Y) ? true : false;
}
