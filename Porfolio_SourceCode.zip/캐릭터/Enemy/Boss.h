// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KilsuARPG/Characters/EnemyCharacter.h"
#include "Boss.generated.h"

UCLASS()
class KILSUARPG_API ABoss : public AEnemyCharacter
{
	GENERATED_BODY()
	
protected:
	UPROPERTY() class UParticleSystem* RedEyeTrail;
	UPROPERTY() class UParticleSystemComponent* EyeTrailComp;
	UPROPERTY() TSubclassOf<class AGS_Atorias_Sword> WeaponClass;

	virtual void BeginPlay() override;
public:
	ABoss();

	virtual void Die() override;
};
