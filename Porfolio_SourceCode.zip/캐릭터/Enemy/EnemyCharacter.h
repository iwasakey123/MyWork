// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "KilsuARPG/Data/Interface/TargetingInterface.h"
#include "EnvironmentQuery/EnvQueryTypes.h"
#include "EnemyCharacter.generated.h"

USTRUCT(BlueprintType)
struct FEnemyAISense
{
	GENERATED_BODY()

	UPROPERTY() float SightRadius;	
	UPROPERTY() float LoseSightRadius;
	UPROPERTY() float SightMaxAge;
	UPROPERTY() float PeripheralVisionAngleDegrees;
	UPROPERTY() float DamageMaxAge;
};

UCLASS()
class KILSUARPG_API AEnemyCharacter : public ACharacter, public IStateInterface, public ICombatInterface, public ITargetingInterface
{
	GENERATED_BODY()

protected:
	virtual void BeginPlay() override;

	//Custom Components
	UPROPERTY() class UEquipmentComponent* EquipmentComp;
	UPROPERTY() class URotateComponent* RotateComp;
	UPROPERTY(VisibleAnywhere) class UMontageComponent* MontageComp;
	UPROPERTY() class UMeleeCombatComponent* MeleeCombatComp;
	UPROPERTY() class UStatsComponent* StatsComp;
	UPROPERTY() class UDissolveComponent* DissolveComp;

	//bState
	UPROPERTY() bool bDead;
	UPROPERTY() bool bIsCombat;
	UPROPERTY() bool bImmotal;
	UPROPERTY() bool bSuperArmor;
	UPROPERTY() bool bHiting;
	UPROPERTY() bool bCanGroddyAttack;
	UPROPERTY() bool bGroggy;

	//EQS spawnspot
	UPROPERTY() class UEnvQuery* EQS_SpawnSpot;

public:
	AEnemyCharacter();

	UFUNCTION() void Groggy();

	UPROPERTY() FEnemyAISense EnemySense;
	   
	//Enemy Controller
	UPROPERTY() class AEnemyController* EnemyController;
	   
	UPROPERTY(EditAnywhere) class UBehaviorTree* BehaviorTree;
	UPROPERTY(EditAnywhere) FName AIName;
	UPROPERTY(EditAnywhere) EAIType AIType;
	UPROPERTY(EditAnywhere) FName AITag;
	UPROPERTY(EditAnywhere) TArray<FName>FriendTags;
	UPROPERTY(EditAnywhere) TArray<FName>EnemyTags;
	UPROPERTY(BlueprintReadWrite, EditAnywhere) TArray<TSubclassOf<class AItem>> Roots;
	UPROPERTY(EditAnywhere) ETargetSize AISize;

	UPROPERTY() UArrowComponent* BehindPos;
	UPROPERTY() class UWidgetComponent* EnemyHUDWidgetComp;

	UFUNCTION() virtual void LastWish();
	UFUNCTION() virtual void SummonAI(TSubclassOf<AEnemyCharacter>SummonAIClass = nullptr);
	UPROPERTY() TSubclassOf<AEnemyCharacter>SummonAIclass = nullptr;
	void HandleQueryResult(TSharedPtr<FEnvQueryResult> result);

	//Delegate Bind
	UFUNCTION() void CollisionActivated(ECollisionParts CollisionType);
	UFUNCTION() void AttackHit(FHitResult Hit);
	UFUNCTION() virtual void Die();
	UFUNCTION() void DissolveFinish(bool Reverse);
	UFUNCTION() void ShowEnemyHUD(bool Hide = false);
	
	//StateInterface
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsAlive();
	virtual bool IsAlive_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, blueprintCallable) bool IsCombat();
	virtual bool IsCombat_Implementation() override;
 	UFUNCTION(BlueprintNativeEvent, blueprintCallable) void SetCombat(bool Combat);
	virtual void SetCombat_Implementation(bool Combat) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) float GetAttackSpeed();
	virtual float GetAttackSpeed_Implementation() override;

	//CombatInterface
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) FRotator GetDesiredRotation();
	virtual FRotator GetDesiredRotation_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) FName GetTag();
	virtual FName GetTag_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool CheckEnemy(const FName& Tag);
	virtual bool CheckEnemy_Implementation(const FName& Tag) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetMovement(EAIMovement MovementType);
	virtual void SetMovement_Implementation(EAIMovement MovementType) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void TakeDamaged(const FDamage& Damage, AActor* Causer);
	virtual void TakeDamaged_Implementation(const FDamage& Damage, AActor* Causer) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsImmotal();
	virtual bool IsImmotal_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetImmotal(bool on);
	virtual void SetImmotal_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsSuperArmor();
	virtual bool IsSuperArmor_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetSuperArmor(bool on);
	virtual void SetSuperArmor_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void Target_ParrySuccess(AActor* Target);
	virtual void Target_ParrySuccess_Implementation(AActor* Target);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetExecutionMode();
	virtual void SetExecutionMode_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) UArrowComponent* GetBehindArrowPos();
	virtual UArrowComponent* GetBehindArrowPos_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetGuardHit();
	virtual void SetGuardHit_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetSpecialHit(bool on);
	virtual void SetSpecialHit_Implementation(bool on) override;

	//TargetingInterface
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) bool IsTargetable();
	virtual bool IsTargetable_Implementation() override;
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) void OnSelected();
	virtual void OnSelected_Implementation() override;
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) void DeSelected();
	virtual void DeSelected_Implementation() override;
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) ETargetSize GetTargetSize();
	virtual ETargetSize GetTargetSize_Implementation() override;
};
