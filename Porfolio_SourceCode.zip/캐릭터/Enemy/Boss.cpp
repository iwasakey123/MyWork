// Fill out your copyright notice in the Description page of Project Settings.


#include "Boss.h"
#include "Particles/ParticleSystemComponent.h"
#include "Components/CapsuleComponent.h"
//Boss Weapon
#include "KilsuARPG/Item/Weapon/GreatSword/GS_Atorias_Sword.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Components/MontageComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"

ABoss::ABoss()
{
	AIType = EAIType::Boss;
	AIName = FName("SkullKing");
	AITag = FName("Boss");
	AISize = ETargetSize::Big;

	//Stat Setting
	StatsComp->HP.Max = 10000.f;
	StatsComp->HP.Current = 10000.f;
	StatsComp->Stamina.Max = 100.f;
	StatsComp->Stamina.Current = 100.f;
	StatsComp->ATT.Current = 60.f;
	StatsComp->CritChance = 5.f;
	StatsComp->CritDamage = 200.f;

	MontageComp->SetMontageID(FName("Boss"));

	bSuperArmor = true;

	//AI Mesh
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/Humanoid/Skullking/mesh/SK_Mask_Skull_Golden.SK_Mask_Skull_Golden'"));
	if (Mannequin.Succeeded())
		GetMesh()->SetSkeletalMesh(Mannequin.Object);
	GetMesh()->SetRelativeLocationAndRotation(FVector(0.f, 0.f, -90.f), FRotator(0.f, -90.f, 0.f));
	GetCapsuleComponent()->SetWorldScale3D(FVector(2.0f));
	GetCapsuleComponent()->SetCapsuleRadius(35.f);
	
	//BehaviorTree
	static ConstructorHelpers::FObjectFinder<UBehaviorTree>BossBehaviorTree(TEXT("BehaviorTree'/Game/BP/AI/BT/BT_MeleeBossAI.BT_MeleeBossAI'"));
	if (BossBehaviorTree.Succeeded())
		BehaviorTree = BossBehaviorTree.Object;

	//AnimBP
	static ConstructorHelpers::FObjectFinder<UClass>AnimBP(TEXT("AnimBlueprint'/Game/BP/AnimInstance/ABP_Boss.ABP_Boss_C'"));
	if (AnimBP.Succeeded())
		GetMesh()->SetAnimInstanceClass(AnimBP.Object);

	EyeTrailComp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("EyeTrailComp"));
	EyeTrailComp->SetupAttachment(GetMesh(), FName("head"));
	EyeTrailComp->SetWorldLocation(FVector(3.f, 11.f, -3.5f));
	EyeTrailComp->SetWorldScale3D(FVector(0.2f));
	//Eyetrail
	static ConstructorHelpers::FObjectFinder<UParticleSystem>RedEyeOb(TEXT("ParticleSystem'/Game/VFX/Cascade/VFX_Toolkit_V1/ParticleSystems/356Days/EyeBoss.EyeBoss'"));
	if (RedEyeOb.Succeeded())
	{
		RedEyeTrail = RedEyeOb.Object;
		EyeTrailComp->SetTemplate(RedEyeTrail);
	}

	//WeaponClass c++
	static ConstructorHelpers::FClassFinder<AGS_Atorias_Sword>WeaponOb(TEXT("Class'/Script/KilsuARPG.GS_Atorias_Sword'"));
	if (WeaponOb.Succeeded())
		WeaponClass = WeaponOb.Class;	
}

void ABoss::BeginPlay()
{
	Super::BeginPlay();

	//��������
	if (WeaponClass != nullptr)
	{		
		EquipmentComp->EquipWeapon(WeaponClass);
		EquipmentComp->UnArmWeapon();
	}
}

void ABoss::Die()
{	
	Super::Die();
	EyeTrailComp->SetTemplate(nullptr);	
}