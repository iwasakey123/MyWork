// Fill out your copyright notice in the Description page of Project Settings.

#include "PlayerCharacter.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/KismetMathLibrary.h"
#include "KilsuARPG/Data/MeshCapture/MeshCaptureActor.h"
#include "Components/ArrowComponent.h"
#include "Components/CapsuleComponent.h"
#include "Perception/AISenseConfig_Damage.h"
#include "KilsuARPG/Data/FloatingDamage/FloatingDamageActor.h"
#include "Particles/ParticleSystemComponent.h"
#include "Components/WidgetComponent.h"
#include "KilsuARPG/Item/Consumable/Potion.h"
#include "KilsuARPG/Data/GhostTrail/GhostTrail.h"

#include "KilsuARPG/Components/InteractComponent.h"
#include "KilsuARPG/Components/InventoryComponent.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Components/MontageComponent.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"
#include "KilsuARPG/Components/RotateComponent.h"
#include "KilsuARPG/Components/TargetingComponent.h"
#include "KilsuARPG/Components/StatsComponent.h"
#include "KilsuARPG/Components/SkillComponent.h"

#include "KilsuARPG/AnimInstance/MyAnimInstance.h"
#include "KilsuARPG/Controllers/MyPlayerController.h"

//Constructor
APlayerCharacter::APlayerCharacter()
{
	PrimaryActorTick.bCanEverTick = true;

	MyTag = FName("Player"); //�÷��̾� �±�
	EnemyTags.Add(FName("Enemy")); //���±� �߰�
	EnemyTags.Add(FName("Dummy"));
	EnemyTags.Add(FName("Boss"));

	//ĳ���� �Ž� ����
	GetMesh()->SetRelativeLocationAndRotation(FVector(0.f, 0.f, -90.f), FRotator(0.f, -90.f, 0.f));
	GetMesh()->SetCollisionObjectType(ECollisionChannel::ECC_PhysicsBody);
	GetMesh()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);	
	GetCapsuleComponent()->SetCollisionObjectType(ECollisionChannel::ECC_Pawn);
	GetCapsuleComponent()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);

	//�������� ����
	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArm->SetupAttachment(GetCapsuleComponent());
	SpringArm->TargetArmLength = 540.f;
	SpringArm->SocketOffset = FVector(0.f, 0.f, 170.f);
	SpringArm->bUsePawnControlRotation = true;
	SpringArm->ProbeSize = 0.1f;
	SpringArm->bEnableCameraLag = true;
	SpringArm->CameraLagSpeed = 3.f;

	bUseControllerRotationYaw = false;
	bUseControllerRotationPitch = false;
	bUseControllerRotationRoll = false;

	//ī�޶� ����
	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	Camera->SetupAttachment(SpringArm);
	Camera->SetRelativeLocationAndRotation(FVector(65.f, 0.f, 70.f), FRotator(-20.f, 0.f, 0.f));

	//�ɸ��� �����Ʈ ����
	GetCharacterMovement()->MaxWalkSpeed = 400.f;
	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.f, 540.f, 0.f);
	GetCharacterMovement()->MaxStepHeight = 60.f;
	GetCharacterMovement()->SetWalkableFloorAngle(60.f);
	GetCharacterMovement()->AirControl = 0.2f;
	GetCharacterMovement()->JumpZVelocity = 700.f;
	GetCharacterMovement()->GravityScale = 3.0f;
	JumpMaxHoldTime = 0.2f;

	//Ŀ���� ������Ʈ ����
	InteractComp = CreateDefaultSubobject<UInteractComponent>(TEXT("InteractComp"));	
	InventoryComp = CreateDefaultSubobject<UInventoryComponent>(TEXT("InventoryComp"));
	EquipmentComp = CreateDefaultSubobject<UEquipmentComponent>(TEXT("EquipmentComp"));
	MontageComp = CreateDefaultSubobject<UMontageComponent>(TEXT("MontageComp"));
	MeleeCombatComp = CreateDefaultSubobject<UMeleeCombatComponent>(TEXT("MeleeCombatComp"));
	RotateComp = CreateDefaultSubobject<URotateComponent>(TEXT("RotateComp"));
	TargetingComp = CreateDefaultSubobject<UTargetingComponent>(TEXT("TargetingComp"));
	StatsComp = CreateDefaultSubobject<UStatsComponent>(TEXT("StatsComp"));
	SkillComp = CreateDefaultSubobject<USkillComponent>(TEXT("SkillComp"));
	
	//���� �ʱ�ȭ
	SaveCurrentSpeed = GetCharacterMovement()->MaxWalkSpeed = 400.f;
	StatsComp->HP.Max = 700.f;
	StatsComp->HP.Current = 700.f;
	StatsComp->MP.Max = 100.f;
	StatsComp->MP.Current = 0.f;
	StatsComp->Stamina.Max = 200.f;
	StatsComp->Stamina.Current = 200;
	StatsComp->ATT.Current = 10.f;
	StatsComp->CritChance = 10.f;
	StatsComp->CritDamage = 200.f;

	//Ÿ���� ������Ʈ�� �ʿ��� ArrowComponent ����
	TargetingArrow = CreateDefaultSubobject<UArrowComponent>(TEXT("ArrowComp"));
	TargetingArrow->SetupAttachment(GetMesh());

	//��ȣ�ۿ뿡 �ʿ��� Widget����
	InteractWidgetComp = CreateDefaultSubobject<UWidgetComponent>(TEXT("InteractWidgetComp"));	
	InteractWidgetComp->SetupAttachment(GetMesh());
	InteractWidgetComp->SetDrawAtDesiredSize(true);
	InteractWidgetComp->SetWidgetSpace(EWidgetSpace::Screen);
	InteractWidgetComp->SetRelativeLocation(FVector(0.f, 0.f, 200.f));
	
	//�Ӹ�ī���� �ִٸ� ����
	Hair = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Hair"));
	Hair->SetupAttachment(GetMesh());
	Hair->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	//�����̸� �߰�
	HandLeftSocketNames.Add(FName("Hand_L_01"));
	HandLeftSocketNames.Add(FName("Hand_L_02"));
	HandLeftSocketNames.Add(FName("Hand_L_03"));
	HandLeftSocketNames.Add(FName("Hand_L_04"));
	HandRightSocketNames.Add(FName("Hand_R_01"));
	HandRightSocketNames.Add(FName("Hand_R_02"));
	HandRightSocketNames.Add(FName("Hand_R_03"));
	HandRightSocketNames.Add(FName("Hand_R_04"));

	//Interaction Widget
	static ConstructorHelpers::FObjectFinder<UClass>InteractWidgetOb(TEXT("WidgetBlueprint'/Game/BP/UI/Inventory/WBP_ItemInteractionWidget.WBP_ItemInteractionWidget_C'"));
	if (InteractWidgetOb.Succeeded())
		InteractWidgetComp->SetWidgetClass(InteractWidgetOb.Object);	
	//Mannequin
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/Humanoid/Kilsu/Mesh/SK_Mannequin_Kilsu.SK_Mannequin_Kilsu'"));
	if(Mannequin.Succeeded())
		GetMesh()->SetSkeletalMesh(Mannequin.Object);
	//AnimBP
	static ConstructorHelpers::FObjectFinder<UClass>AnimBP(TEXT("AnimBlueprint'/Game/BP/AnimInstance/ABP_Player.ABP_Player_C'"));
	if (AnimBP.Succeeded())
		GetMesh()->SetAnimInstanceClass(AnimBP.Object);
	//Sprint Curve Asset
	static ConstructorHelpers::FObjectFinder<UCurveFloat>SprintCurveOb(TEXT("CurveFloat'/Game/BP/Data/Curve/Sprint.Sprint'"));
	if (SprintCurveOb.Succeeded())
		SprintCurveFloat = SprintCurveOb.Object;
	//CameraZoom Curve Asset
	static ConstructorHelpers::FObjectFinder<UCurveFloat>CameraZoomCurveOb(TEXT("CurveFloat'/Game/BP/Data/Curve/CamZoom.CamZoom'"));
	if (CameraZoomCurveOb.Succeeded())
		CameraZoomFloat = CameraZoomCurveOb.Object;
	//MeshCaptureActor
	static ConstructorHelpers::FClassFinder<AMeshCaptureActor>CapturedMeshclass(TEXT("Class'/Script/KilsuARPG.MeshCaptureActor'"));
	if (CapturedMeshclass.Class != NULL)
		CapturedMeshClass = CapturedMeshclass.Class;
	//MontageTable
	static ConstructorHelpers::FObjectFinder<UDataTable>MontageTableOb(TEXT("DataTable'/Game/BP/Data/DataTable/MontagesDT.MontagesDT'"));
	if (MontageTableOb.Succeeded())
		MontageComp->MontageTable = MontageTableOb.Object;

	//Particles
	//AttackHit
	static ConstructorHelpers::FObjectFinder<UParticleSystem>AttackHitEffectOb(TEXT("ParticleSystem'/Game/VFX/Niagara/StylizedVFX/VFX_Niagara/Hit/Hit_07/P_Hit_07_03.P_Hit_07_03'"));
	if (AttackHitEffectOb.Succeeded())
		P_AttackHitEffect = AttackHitEffectOb.Object;
	//AttackSlash
	static ConstructorHelpers::FObjectFinder<UParticleSystem>AttackSlashEffectOb(TEXT("ParticleSystem'/Game/VFX/Niagara/StylizedVFX/VFX_Niagara/Slash/Slash_05/P_Slash_05_03.P_Slash_05_03'"));
	if (AttackSlashEffectOb.Succeeded())
		P_AttackSlashEffect = AttackSlashEffectOb.Object;
	//Hit
	static ConstructorHelpers::FObjectFinder<UParticleSystem>P_DamagedEffectOb(TEXT("ParticleSystem'/Game/VFX/RifleEffects/P_body_bullet_impact.P_body_bullet_impact'"));
	if (P_DamagedEffectOb.Succeeded())
		P_DamagedEffect = P_DamagedEffectOb.Object;
	//HitSlash
	static ConstructorHelpers::FObjectFinder<UParticleSystem>P_DamagedSlashEffectOb(TEXT("ParticleSystem'/Game/VFX/Niagara/StylizedVFX/VFX_Niagara/Slash/Slash_01/P_Slash_01_01.P_Slash_01_01'"));
	if (P_DamagedSlashEffectOb.Succeeded())
		P_DamagedSlashEffect = P_DamagedSlashEffectOb.Object;
	//Guard
	static ConstructorHelpers::FObjectFinder<UParticleSystem>P_GuardEffectOb(TEXT("ParticleSystem'/Game/VFX/Niagara/StylizedVFX/VFX_Niagara/Hit/Hit_07/P_Hit_07_01.P_Hit_07_01'"));
	if (P_GuardEffectOb.Succeeded())
		P_GuardEffect = P_GuardEffectOb.Object;
	//GuardHit
	static ConstructorHelpers::FObjectFinder<UParticleSystem>P_GuardHitEffectOb(TEXT("ParticleSystem'/Game/VFX/RifleEffects/P_AssaultRifle_IH.P_AssaultRifle_IH'"));
	if (P_GuardHitEffectOb.Succeeded())
		P_GuardHitEffect = P_GuardHitEffectOb.Object;
	//Parry
	static ConstructorHelpers::FObjectFinder<UParticleSystem>P_ParryEffectOb(TEXT("ParticleSystem'/Game/VFX/Cascade/ParagonGideon/FX/Particles/Gideon/Abilities/ProjectileMeteor/FX/Parried.Parried'"));
	if (P_ParryEffectOb.Succeeded())
		P_ParryEffect = P_ParryEffectOb.Object;

	//Sound
	//ParrySound
	static ConstructorHelpers::FObjectFinder<USoundBase>S_ParrySoundOb(TEXT("SoundCue'/Game/SFX/Weapons_woosh/Cues/Impact_06_Cue.Impact_06_Cue'"));
	if (S_ParrySoundOb.Succeeded())
		S_ParrySound = S_ParrySoundOb.Object;
	
}

//BeginPlay
void APlayerCharacter::BeginPlay()
{
	Super::BeginPlay();
	//PlayerController
	PC = Cast<AMyPlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0));
	
	//DECLARE_EVENT binding Function
	InventoryComp->UpdateInventoryUI.AddUFunction(this, FName("UpdateSlotUI"));
	EquipmentComp->UpdatingMeshRender.AddUFunction(this, FName("UpdateMeshRender"));
	EquipmentComp->UpdateEquipmentUI.AddUFunction(this, FName("UpdateEquipmentUI"));
	MeleeCombatComp->MeleeCollisionActivate.AddUFunction(this, FName("CollisionActivated"));
	MeleeCombatComp->AttackHit.AddUFunction(this, FName("AttackHit"));
	StatsComp->Die.AddUFunction(this, FName("Die"));
	StatsComp->SetSaveMoveSpeed.AddUFunction(this, FName("SetSaveMoveSpeed"));

	//Equipment Setting
	EquipmentComp->HeadComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), FName("HAIR"));
	EquipmentComp->UpperComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	EquipmentComp->UpperComp->SetMasterPoseComponent(GetMesh());
	EquipmentComp->LowerComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	EquipmentComp->LowerComp->SetMasterPoseComponent(GetMesh());
	EquipmentComp->ShoesComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	EquipmentComp->ShoesComp->SetMasterPoseComponent(GetMesh());
	EquipmentComp->HandComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	EquipmentComp->HandComp->SetMasterPoseComponent(GetMesh());
	EquipmentComp->CapeComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	EquipmentComp->CapeComp->SetMasterPoseComponent(GetMesh());	

	//TargetingComponent
	TargetingComp->Initialize(TargetingArrow);

	//SpawnMeshCapture ���â�� ���̴� �ڽ�Ƭ�������� ĳ���͸� ����ٱ����� ���������մϴ�.
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Owner = this;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	FTransform transform = FTransform(FRotator(0.f, -60.f, 0.f), FVector(4092020.f, 3017930.f, 64700.f), FVector::OneVector);
	if (CapturedMeshClass != NULL)
	{
		auto SpawnCaptureMesh = GetWorld()->SpawnActor<AMeshCaptureActor>(CapturedMeshClass, transform, SpawnInfo);
		CapturedMesh = SpawnCaptureMesh;
	}
	
	//Setting Timeline Ÿ�Ӷ����� ����ϱ����� Ư���Լ��� ���ε� ��ŵ�ϴ�.
	if (SprintCurveFloat)
	{
		FOnTimelineFloat TimelineProgress;
		TimelineProgress.BindUFunction(this, FName("PlaySprintTimeline"));
		SprintTimeline.AddInterpFloat(SprintCurveFloat, TimelineProgress);
	}
	if (CameraZoomFloat)
	{
		FOnTimelineFloat TimelineProgress;
		TimelineProgress.BindUFunction(this, FName("PlayCameraZoomTimeline"));
		CameraZoomTimeline.AddInterpFloat(CameraZoomFloat, TimelineProgress);
	}
}

//Tick
void APlayerCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	//Timeline
	if (SprintTimeline.IsPlaying())
		SprintTimeline.TickTimeline(DeltaTime);
	if (CameraZoomTimeline.IsPlaying())
		CameraZoomTimeline.TickTimeline(DeltaTime);

	//Impulse character(.. hit) ������ �з����� �մϴ�.
	if (bHitImpulse)
		LaunchCharacter(GetActorForwardVector() * HitPower, true, false);
}

//SetupPlayerInputComponent
void APlayerCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	//Axis
	PlayerInputComponent->BindAxis("MoveForward", this, &APlayerCharacter::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &APlayerCharacter::MoveRight);
	PlayerInputComponent->BindAxis("Turn", this, &APlayerCharacter::Turn);
	PlayerInputComponent->BindAxis("LookUp", this, &APlayerCharacter::LookUp);	
	//Action
	PlayerInputComponent->BindAction("Interaction", IE_Pressed, this, &APlayerCharacter::Interaction);
	PlayerInputComponent->BindAction("InventoryUIOpen", IE_Pressed, this, &APlayerCharacter::InventoryUIOpen);
	PlayerInputComponent->BindAction("EquipmentUIOpen", IE_Pressed, this, &APlayerCharacter::EquipmentUIOpen);
	PlayerInputComponent->BindAction("MenuUIOpen", IE_Pressed, this, &APlayerCharacter::MenuUIOpen);
	PlayerInputComponent->BindAction("1", IE_Pressed, this, &APlayerCharacter::Input_1);
	PlayerInputComponent->BindAction("2", IE_Pressed, this, &APlayerCharacter::Input_2);
	PlayerInputComponent->BindAction("3", IE_Pressed, this, &APlayerCharacter::Input_3);
	PlayerInputComponent->BindAction("CombatOnOff", IE_Pressed, this, &APlayerCharacter::CombatOnOff);
	PlayerInputComponent->BindAction("Attack", IE_Pressed, this, &APlayerCharacter::Attack);
	PlayerInputComponent->BindAction("Guard", IE_Pressed, this, &APlayerCharacter::Guard);
	PlayerInputComponent->BindAction("Guard", IE_Released, this, &APlayerCharacter::Guard_Cancel);
	PlayerInputComponent->BindAction("Roll", IE_Pressed, this, &APlayerCharacter::Roll);
	PlayerInputComponent->BindAction("Slide", IE_Pressed, this, &APlayerCharacter::Slide);
	PlayerInputComponent->BindAction("Targeting", IE_Pressed, this, &APlayerCharacter::Targeting);
	PlayerInputComponent->BindAction("ShiftDown", IE_Pressed, this, &APlayerCharacter::ShiftDown);
	PlayerInputComponent->BindAction("ShiftDown", IE_Released, this, &APlayerCharacter::ShiftUp);
	PlayerInputComponent->BindAction("Parry", IE_Pressed, this, &APlayerCharacter::Parry);
	PlayerInputComponent->BindAction("Execution", IE_Pressed, this, &APlayerCharacter::FinishExecute);
	PlayerInputComponent->BindAction("G", IE_Pressed, this, &APlayerCharacter::DrinkPotion);
	PlayerInputComponent->BindAction("SpecialAttack", IE_Pressed, this, &APlayerCharacter::SpecialAttack);
	PlayerInputComponent->BindAction("Z", IE_Pressed, this, &APlayerCharacter::LongSlide);
	PlayerInputComponent->BindAction("Ctrl", IE_Pressed, this, &APlayerCharacter::CtrlDown);
	PlayerInputComponent->BindAction("Ctrl", IE_Released, this, &APlayerCharacter::CtrlUp);
}

//IStateInterface::GetAttackSpeed
float APlayerCharacter::GetAttackSpeed_Implementation()
{
	return EquipmentComp->GetAttackSpeed();
}
//IStateInterface::IsAlive
bool APlayerCharacter::IsAlive_Implementation()
{
	return !bDead;
}
//IStateInterface::IsImmotal
bool APlayerCharacter::IsImmotal_Implementation()
{
	return bImmotal;
}
//IStateInterface::Combat
bool APlayerCharacter::IsCombat_Implementation()
{
	return bIsCombat;
}
//ISateInterface::SetImmotal
void APlayerCharacter::SetImmotal_Implementation(bool on)
{
	bImmotal = on;
}
//IStateInterface::SetCombat
void APlayerCharacter::SetCombat_Implementation(bool Combat)
{	
	bIsCombat = Combat;
}
//IStateInterface::Roll
void APlayerCharacter::SetRolling_Implementation(bool on)
{
	bRolling = on;
}
//IStateInterface::Slide
void APlayerCharacter::SetSliding_Implementation(bool on)
{
	bSliding = on;
}
//StateInterface::IsWalk
bool APlayerCharacter::IsWalk_Implementation()
{
	return bIsWalk;
}
//StateInterface::IsSprint
bool APlayerCharacter::IsSprint_Implementation()
{
	return bIsSprint;
}
//StateInterface::CanGuard
void APlayerCharacter::SetCanGuard_Implementation(bool on)
{
	bCanGuard = on;
}
//StateInterface::CanWalk
void APlayerCharacter::SetCanWalk_Implementation(bool on)
{
	bCanWalk = on;
}
//StateInterface::CanSprint
void APlayerCharacter::SetCanSprint_Implementation(bool on)
{
	bCanSprint = on;
}
//StateInterface::SetIsParry
void APlayerCharacter::SetIsParry_Implementation(bool on)
{
	bIsParry = on;
}
//StateInterface::IsSuperArmor
bool APlayerCharacter::IsSuperArmor_Implementation()
{
	return bSuperArmor;
}
//StateInterface::SetSuperArmor
void APlayerCharacter::SetSuperArmor_Implementation(bool on)
{
	bSuperArmor = on;
}

//����, ȸ�ǽ� �ڿ������� ȸ���� ���� ȸ����. 
//ICombatInterface::GetDesiredRotation
FRotator APlayerCharacter::GetDesiredRotation_Implementation()
{
	if (GetLastMovementInputVector() != FVector(0.f))
	{
		return UKismetMathLibrary::MakeRotFromX(GetLastMovementInputVector());
	}
	else
	{	
		//3m�̳��� �� Ž��
		TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes; ObjectTypes.Empty();
		ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_Pawn));
		ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
		TArray<AActor*> Ignores; Ignores.Empty();
		Ignores.Add(this);
		TArray<AActor*>Outers; Outers.Empty();
		TArray<float>LocalDistances; LocalDistances.Empty();
		TArray<AActor*>LocalActors; LocalActors.Empty();
		AActor* ClosetEnemy = nullptr;
		if (UKismetSystemLibrary::SphereOverlapActors(GetWorld(), GetActorLocation(), 300.f, ObjectTypes, nullptr, Ignores, Outers))
		{			
			for (AActor* Outer : Outers)
			{
				//Interface�� ���� Tag�� �����µ� ������ �Ʊ����� ��
				if (Outer->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) && EnemyTags.Contains(ICombatInterface::Execute_GetTag(Outer)))
				{
					LocalDistances.Add(GetDistanceTo(Outer));
					LocalActors.Add(Outer);					
				}
			}
			if (LocalActors.Num() > 0)
			{
				//���� ��������� Ž��
				int32 Index;
				float Distance;
				UKismetMathLibrary::MinOfFloatArray(LocalDistances, Index, Distance);
				if (LocalActors.Num() > Index)
					ClosetEnemy = LocalActors[Index];
			}
			else ClosetEnemy = nullptr;

			if (ClosetEnemy)
			{		
				//���� ��������� ���Ͽ� ȸ��
				float XRoll =GetActorRotation().Roll;
				float YPitch = GetActorRotation().Pitch;
				float ZYaw = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), ClosetEnemy->GetActorLocation()).Yaw;
				FRotator NewRotator = UKismetMathLibrary::MakeRotator(XRoll, YPitch, ZYaw);
				return NewRotator;
			}
			else;
		}
	}
	return GetActorRotation();
}
//CombatInterface::GetTag
FName APlayerCharacter::GetTag_Implementation()
{
	return MyTag;
}
//CombatInterface::CheckEnemy
bool APlayerCharacter::CheckEnemy_Implementation(const FName& Tag)
{
	return EnemyTags.Contains(Tag);	
}

//���� ������ ��������
//CombatInterface::TakeDamage
void APlayerCharacter::TakeDamaged_Implementation(const FDamage& Damage, AActor* Causer)
{
	ResetAttack();
	//Guarding?
	if (bGuarding && this->GetDotProductTo(Causer) > 0.f)
	{		
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), P_GuardEffect, EquipmentComp->MainWeaponComp->GetCenterOfMass(), FRotator::ZeroRotator, ((FVector)(0.53f)));		
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), P_GuardHitEffect, EquipmentComp->MainWeaponComp->GetCenterOfMass(), FRotator::ZeroRotator, ((FVector)(1.63f)));
		FTimerHandle loofhandle;
		//���尡 ������ ��������?
		if (Damage.bCanGuard)
		{
			//�����ϴٸ� ������Ÿ�Կ� ���� �޶����ϴ�.
			if (Damage.DamageType == EDamageType::Normal)
			{				
				GetMesh()->GetAnimInstance()->Montage_JumpToSection(FName("Guard_Hit"));
				HitPower = -300.f;//300��ŭ �ڷ� �з����ϴ�.
				bHitImpulse = true;
				//1���� �з��� ����
				GetWorld()->GetTimerManager().SetTimer(loofhandle, FTimerDelegate::CreateLambda([&]() {
					bHitImpulse = false;
					GetWorld()->GetTimerManager().ClearTimer(loofhandle);
				}), 1.f, true);
				//���׹̳� ����
				StatsComp->UpdateHPMPST(EStat::Stamina, 20.f, false);
				if (StatsComp->Stamina.Current == 0.f)
					Guard_Cancel();
			}
			else if (Damage.DamageType == EDamageType::Heavy)
			{
				MontageComp->PlayMontage(EMontageType::GuardBreak);
				Guard_Cancel();

				StatsComp->UpdateHPMPST(EStat::Stamina, 40.f, false);
			}
			else if (Damage.DamageType == EDamageType::CustomDamage)
			{
				GetMesh()->GetAnimInstance()->Montage_JumpToSection(FName("Guard_Hit"));
				HitPower = -300.f;
				bHitImpulse = true;
				GetWorld()->GetTimerManager().SetTimer(loofhandle, FTimerDelegate::CreateLambda([&]() {
					bHitImpulse = false;
					GetWorld()->GetTimerManager().ClearTimer(loofhandle);
				}), 1.f, true);

				StatsComp->UpdateHPMPST(EStat::Stamina, 6.f, false);
				if (StatsComp->Stamina.Current == 0.f)
					Guard_Cancel();
			}			
			return;
		}
		else
			StatsComp->UpdateHPMPST(EStat::Stamina, 60.f, false);
	}
	//Parring?
	else if (bIsParry && this->GetDotProductTo(Causer) > 0.f && Damage.bCanParry) //�и��� ������ ����Ÿ������? ��밡 ���տ��ִ��� üũ
	{		
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), P_ParryEffect, EquipmentComp->MainWeaponComp->GetCenterOfMass(), FRotator::ZeroRotator, ((FVector)(1.f)));	
		if(S_ParrySound) UGameplayStatics::PlaySound2D(GetWorld(), S_ParrySound);
		ICombatInterface::Execute_Target_ParrySuccess(Causer, this);//�и��� �����ߴٴ� �޼����� ������ ����
		SpringArm->bUsePawnControlRotation = false;		
		CameraZoomTimeline.Play();//ī�޶��� Ÿ�Ӷ��� ����
		DisableInput(PC);
		FTimerHandle handle, handle_;
		//�����Լ�, timer�� delay�� �����Ͽ����ϴ�.
		GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]() {
			UGameplayStatics::SetGlobalTimeDilation(GetWorld(), 0.15f);
			GetWorld()->GetTimerManager().SetTimer(handle_, FTimerDelegate::CreateLambda([&]() {
				UGameplayStatics::SetGlobalTimeDilation(GetWorld(), 1.f);
				CameraZoomTimeline.Reverse();
				SpringArm->bUsePawnControlRotation = true;
				EnableInput(PC);
				GetWorld()->GetTimerManager().ClearTimer(handle);
				GetWorld()->GetTimerManager().ClearTimer(handle_);
			}), 0.3f, false);
		}), CameraZoomTimeline.GetTimelineLength() + 0.1f, false);
		return;
	}
	
	//Hit

	UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), P_DamagedSlashEffect , GetMesh()->GetCenterOfMass(), FRotator::ZeroRotator, ((FVector)(0.65f)));	
	UGameplayStatics::SpawnEmitterAttached(P_DamagedEffect, GetMesh(), FName("BloodEffect"), FVector::ZeroVector, UKismetMathLibrary::MakeRotFromX(GetActorRightVector()), ((FVector)(3.0f)));
	
	//Spawn Floating Damage(Hit)
	auto FloatingDamage = LoadClass<AFloatingDamageActor>(NULL, TEXT("Class'/Script/KilsuARPG.FloatingDamageActor'"));
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Owner = this;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	FTransform transform = FTransform(FRotator::ZeroRotator, GetMesh()->GetCenterOfMass(), ((FVector)(1.f)));
	auto FloatingDamageActor = GetWorld()->SpawnActor<AFloatingDamageActor>(FloatingDamage, transform, SpawnInfo);
	FDamage _Damage = Damage;
	_Damage.Damage -= StatsComp->A_DEF.Current;
	FloatingDamageActor->FloatingDamage(_Damage, true);
	
	//UI������Ʈ
	PC->HitHPBar();	
	StatsComp->Damaged(Damage);	
	if (StatsComp->HP.Current > 0)
	{
		//������Ÿ�Կ����� ���׼��� �����ϴ�.
		if (!bSuperArmor)
		{
			switch (Damage.DamageType)
			{
			case EDamageType::CustomDamage:
			case EDamageType::Normal:
				MontageComp->PlayMontage(EMontageType::Damaged);
				break;
			case EDamageType::Heavy:
				MontageComp->PlayMontage(EMontageType::HeavyDamaged);
				break;
			case EDamageType::TakeDown:
				MontageComp->PlayMontage(EMontageType::TakeDown);
				break;
			}
		}
	}
}
//CombatInterface::SetEnemyTarget
void APlayerCharacter::SetEnemyTarget_Implementation(AActor* Enemy, EAIType AIType)
{
	if (Enemy != nullptr && AIType == EAIType::Boss && bDo == false)
	{
		BossTarget = Enemy;
		PC->ShowBossUI(true);
		bDo = true;			
	}
	else if (Enemy == nullptr && AIType == EAIType::Boss && bDo == true)
	{
		BossTarget = nullptr;
		PC->ShowBossUI(false);
		bDo = false;
	}
}
//CombatInterface::CanFinishExecution
void APlayerCharacter::CanFinishExecute_Implementation(bool on)
{
	bCanExecution = on;
}
void APlayerCharacter::CallResetAttack_Implementation()
{
	ResetAttack();
}
void APlayerCharacter::GhostTailOnOff_Implementation(bool on)
{
	if (on)
		StartGhostTrail();
	else
		StopGhostTrail();
}

//DECLARE
void APlayerCharacter::UpdateSlotUI()//InventorySlot
{
	PC->UpdateSlotUI();
}
void APlayerCharacter::UpdateMeshRender(EEquipmentType EquipmentType, FName BoneName, UStaticMesh* StMesh, USkeletalMesh* SKMesh)
{
	if (CapturedMesh)
		CapturedMesh->UpdateMeshCapture(EquipmentType, BoneName, StMesh, SKMesh);
}
void APlayerCharacter::UpdateEquipmentUI(TSubclassOf<AItem>EquipmentClass, EEquipmentType EquipmentType)
{
	PC->UpdateEquipmentSlotUI(EquipmentClass, EquipmentType);	
	if (EquipmentType == EEquipmentType::MainWeapon || EquipmentType == EEquipmentType::SubWeapon)
	{
		MontageComp->SetMontageID(EquipmentComp->GetMontageID());
		MontageComp->PlayMontage(EMontageType::CombatOn);
		auto AnimIns = Cast<UMyAnimInstance>(GetMesh()->GetAnimInstance());
		AnimIns->WeaponType = EquipmentComp->GetCurrentWeaponType();
	}

	if (EquipmentComp->GetCurrentHead() == nullptr) //&& Head_Default != nullptr)
		EquipmentComp->HeadComp->SetSkeletalMesh(nullptr);
	if (EquipmentComp->GetCurrentUpper() == nullptr && Upper_Default != nullptr)
		EquipmentComp->UpperComp->SetSkeletalMesh(Upper_Default);
	if (EquipmentComp->GetCurrentLower() == nullptr && Lower_Default != nullptr)
		EquipmentComp->LowerComp->SetSkeletalMesh(Lower_Default);
	if (EquipmentComp->GetCurrentHand() == nullptr && Hand_Default != nullptr)
		EquipmentComp->HandComp->SetSkeletalMesh(Hand_Default);
	if (EquipmentComp->GetCurrentShoes() == nullptr && Shoes_Default != nullptr)
		EquipmentComp->ShoesComp->SetSkeletalMesh(Shoes_Default);
	if (EquipmentComp->GetCurrentCape() == nullptr && Cape_Default != nullptr)
		EquipmentComp->CapeComp->SetSkeletalMesh(Cape_Default);
	
	ResetAttack();
}
//DECLARE MeleeCollision
void APlayerCharacter::CollisionActivated(ECollisionParts CollisionType)
{
	//������ �����ݸ��������� �޾ư��ϴ�.
	switch (CollisionType)
	{
	case ECollisionParts::Weapon:
		if (EquipmentComp->MainWeaponComp)
			MeleeCombatComp->SetCollisionComponent(EquipmentComp->MainWeaponComp, EquipmentComp->MainWeaponComp->GetAllSocketNames());
		break;
	case ECollisionParts::Hand_L:
		MeleeCombatComp->SetCollisionComponent(GetMesh(), HandLeftSocketNames);
		break;
	case ECollisionParts::Hand_R:
		MeleeCombatComp->SetCollisionComponent(GetMesh(), HandRightSocketNames);
		break;
	}
}

//���� ������ ������
void APlayerCharacter::AttackHit(FHitResult Hit)
{
	if (IsValid(Hit.Actor.Get()))
	{
		//IsEnemy
		if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) == true && ICombatInterface::Execute_CheckEnemy(this, ICombatInterface::Execute_GetTag(Hit.Actor.Get())))
		{
			//IsAlive and NoImmotal
			if (Hit.Actor.Get()->GetClass()->ImplementsInterface(UStateInterface::StaticClass()) == true && IStateInterface::Execute_IsAlive(Hit.Actor.Get()) && IStateInterface::Execute_IsImmotal(Hit.Actor.Get()) == false)
			{
				//Effect Setting			
				auto SlashEffect = (EquipmentComp->SlashEffect) ? EquipmentComp->SlashEffect : P_AttackSlashEffect;
				auto HitEffect = (EquipmentComp->HitEffect) ? EquipmentComp->HitEffect : P_AttackHitEffect;
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), SlashEffect, Hit.Location, UKismetMathLibrary::MakeRotFromX(GetActorRightVector()) + FRotator(FMath::RandRange(-45.f, 45.f), 0.f, 0.f), ((FVector)(0.4f)));
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), HitEffect, Hit.Location, FRotator::ZeroRotator, ((FVector)(0.4f)));
				//CamShake Setting
				auto CamShake = bSpecialAttack ? LoadClass<UCameraShake>(nullptr, TEXT("Class'/Script/KilsuARPG.CamShake_SpecialAttack'")) : LoadClass<UCameraShake>(nullptr, TEXT("Class'/Script/KilsuARPG.CamShake_DefaultAttack'"));
				UGameplayStatics::PlayWorldCameraShake(GetWorld(), CamShake, Hit.Location, 1000.f, 1000.f, 0.6f);
				//Damage Setting
				auto Damage = MeleeCombatComp->GetCustomDamage().bSetCustom ? MeleeCombatComp->GetCustomDamage() : StatsComp->MakeDamage(EDamageType::Normal);
				Damage.bEnchant = EquipmentComp->GetCurrentEnchant() ? true : false;
				ICombatInterface::Execute_TakeDamaged(Hit.Actor.Get(), Damage, this);
				UAISense_Damage::ReportDamageEvent(GetWorld(), Hit.Actor.Get(), this, Damage.Damage, Hit.Location, Hit.Location);
				//Spawn Floating Damage
				auto FloatingDamage = LoadClass<AFloatingDamageActor>(NULL, TEXT("Class'/Script/KilsuARPG.FloatingDamageActor'"));
				FActorSpawnParameters SpawnInfo;
				SpawnInfo.Owner = this;
				SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
				FTransform transform = FTransform(FRotator::ZeroRotator, Hit.Location, ((FVector)(1.f)));
				auto FloatingDamageActor = GetWorld()->SpawnActor<AFloatingDamageActor>(FloatingDamage, transform, SpawnInfo);
				FloatingDamageActor->FloatingDamage(Damage, false);
				if(!bSpecialAttack) StatsComp->UpdateHPMPST(EStat::MP, 10.f, true);		
			}
		}
	}
}
//DECLARE Stats
void APlayerCharacter::Die()
{	
	StopAnimMontage();
	float delay = MontageComp->PlayMontage(EMontageType::Die);
	DisableInput(PC);
	bDead = true;	
	GetWorld()->GetTimerManager().ClearAllTimersForObject(this);
}
void APlayerCharacter::SetSaveMoveSpeed()
{
	SaveCurrentSpeed = GetCharacterMovement()->MaxWalkSpeed;
}

//Input Interaction
void APlayerCharacter::MoveForward(float value)
{
	FRotator RotationYaw = FRotator(0.f, GetControlRotation().Yaw, 0.f);
	FVector Direction = FRotationMatrix(RotationYaw).GetUnitAxis(EAxis::X);
	AddMovementInput(Direction, value);
	ForwardAxis = value;
}
void APlayerCharacter::MoveRight(float value)
{
	FRotator RotationYaw = FRotator(0.f, GetControlRotation().Yaw, 0.f);
	FVector Direction = FRotationMatrix(RotationYaw).GetUnitAxis(EAxis::Y);
	AddMovementInput(Direction, value);
	RightAxis = value;
}
void APlayerCharacter::Turn(float value)
{
	AddControllerYawInput(value);
}
void APlayerCharacter::LookUp(float value)
{
	AddControllerPitchInput(value);
}

void APlayerCharacter::Interaction()
{
	InteractComp->Interaction();
}

void APlayerCharacter::InventoryUIOpen()
{		
	PC->OpenUI(EUIType::Inventory);		
}
void APlayerCharacter::EquipmentUIOpen()
{
	PC->OpenUI(EUIType::Equipment);
}
void APlayerCharacter::MenuUIOpen()
{
	PC->OpenUI(EUIType::Menu);	
}

//Ctrl�� �����°�?
void APlayerCharacter::CtrlDown()
{
	bIsCtrlDown = true;
}
void APlayerCharacter::CtrlUp()
{
	bIsCtrlDown = false;
}

//Shift�� �����°�?
void APlayerCharacter::ShiftDown()
{
	bIsShiftDown = true;

	if (bCanSprint == true && StatsComp->Stamina.Current >= 1.0f && bAttacking == false)
		Sprint();
}
void APlayerCharacter::ShiftUp()
{
	if (bIsSprint)
	{
		bIsSprint = false;
		SprintTimeline.Reverse();
		SpringArm->CameraLagSpeed = 3.f;
		StatsComp->StaminaUpTimerFunc();
		GetWorld()->GetTimerManager().ClearTimer(SprintStaminaHandle);
	}
	bIsShiftDown = false;
}

//�޸���
void APlayerCharacter::Sprint()
{
	if (!bIsSprint && StatsComp->Stamina.Current >= 1.0f && bAttacking == false)
	{
		bIsSprint = true;
		SprintTimeline.Play();
		SpringArm->CameraLagSpeed = 2.f;
		StatsComp->StaminaStopTimerFunc();
		GetWorld()->GetTimerManager().SetTimer(SprintStaminaHandle, FTimerDelegate::CreateLambda([&]() {
			StatsComp->UpdateHPMPST(EStat::Stamina, 0.3f, false);
			if (StatsComp->Stamina.Current <= 0)			
				ShiftUp();
		}), 0.016f, true);
	}
}

//�ȱ�
void APlayerCharacter::Walk()
{
	if(bCanWalk != true) return;
	if (!bIsWalk)
	{
		bIsWalk = true;
		SprintTimeline.Reverse();
		SpringArm->CameraLagSpeed = 5.f;
	}
	else
	{
		bIsWalk = false;
		SprintTimeline.Play();
		SpringArm->CameraLagSpeed = 3.f;
	}
}

//�޸��⸦ ���� Ÿ�Ӷ��ν���
void APlayerCharacter::PlaySprintTimeline(float value)
{	
	GetCharacterMovement()->MaxWalkSpeed = SaveCurrentSpeed + value;
}

//1��Ű�� �����ٸ� (��þƮ)
void APlayerCharacter::Input_1()
{
	SkillComp->UseSkillAtidx(0);
}
//2��Ű�� �����ٸ� (��ų�ߵ�)
void APlayerCharacter::Input_2()
{
	if (EquipmentComp->GetCurrentWeapon() && !bSliding && !bRolling && bIsCombat && !bGuarding /*&& StatsComp->MP.Current >= 30.f*/)
	{
		//CurrentCamSet
		CurrentCamSet.Location = Camera->GetRelativeLocation();
		CurrentCamSet.Rotation = Camera->GetRelativeRotation();
		CurrentCamSet.SocketOffset = SpringArm->SocketOffset;
		CurrentCamSet.ArmLength = SpringArm->TargetArmLength;
		CurrentCamSet.CamLagSpeed = SpringArm->CameraLagSpeed;
		//ParryCamSet
		DestCamSet.Location = FVector(287.f, 247.f, 0.f);
		DestCamSet.Rotation = FRotator(0.f, -45.f, 0.f);
		DestCamSet.SocketOffset = FVector(0.f, 0.f, 30.f);
		DestCamSet.ArmLength = 400.f;
		DestCamSet.CamLagSpeed = SpringArm->CameraLagSpeed;

		SpringArm->bUsePawnControlRotation = false;

		ResetAttack();
		DisableInput(PC);
		//StatsComp->UpdateHPMPST(EStat::MP, 30.f, false);
		StatsComp->ATT.Current *= 3.f;

		if (TargetingComp->IsTargetEnabled() == true)
		{
			TargetingComp->ToggleCameraLock();
		}

		bSpecialAttack = true;

		//Charging
		//auto SkillMontage = LoadObject<UAnimMontage>(nullptr, TEXT("AnimMontage'/Game/BP/Montages/FM/Attack/FM_SkillAttack.FM_SkillAttack'"));
		float delay = MontageComp->PlayMontage_Skill(FName("ChargeAttack"), 1.f);
		CameraZoomTimeline.Play();
		//and PlaySkill
		FTimerHandle handle;
		GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]() {
			CameraZoomTimeline.Reverse();
			SpringArm->bUsePawnControlRotation = true;
			FTimerHandle inputhandle;
			GetWorld()->GetTimerManager().SetTimer(inputhandle, FTimerDelegate::CreateLambda([&]() {
				bSpecialAttack = false;
				StatsComp->ATT.Current /= 3.f;
				EnableInput(PC);	
				GetWorld()->GetTimerManager().ClearTimer(handle);
				GetWorld()->GetTimerManager().ClearTimer(inputhandle);
			}), 1.0f, false);
		}), 1.f, false);
	}
}
void APlayerCharacter::Input_3()
{

}

//�����غ��ڼ� ���
void APlayerCharacter::CombatOnOff()
{
	if (bCanArm != true) return;
	bIsCombat ? MontageComp->PlayMontage(EMontageType::CombatOff) : MontageComp->PlayMontage(EMontageType::CombatOn);
}

//Attack
void APlayerCharacter::Attack()
{
	if (bCanAttack != true) return;
	if (/*IsValid(EquipmentComp->GetCurrentWeapon()) &&*/ !bRolling && !bSliding)
	{
		if (bAttacking == true)
			bSaveAttack = true;
		else
		{
			if (bIsCombat == false)
			{
				bIsCombat = true;
				EquipmentComp->ArmWeapon();
			}			
			bAttacking = true;
			if (bIsCtrlDown) //��Ʈ���� �����°�?
				MontageComp->PlayMontage(EMontageType::CustomAttack);
			else			
				bIsShiftDown ? MontageComp->PlayMontage(EMontageType::HeavyAttack) : MontageComp->PlayMontage(EMontageType::DefaultAttack); //����Ʈ�� �����°�?
		}
	}
}

//�޺� ������ ���� �Լ�
void APlayerCharacter::SaveAttack() //��Ÿ�� Ư���������� SaveAttack �ߵ�. ���� �Լ� �ߵ��� �ѹ��� ������ �õ��Ϸ��ߴٸ� �߻�.
{
	if (bSaveAttack)
	{
		bSaveAttack = false;
		if (bIsCtrlDown)
			MontageComp->PlayMontage(EMontageType::CustomAttack);
		else
			(bIsShiftDown && MontageComp->Count >= 1) ? MontageComp->PlayMontage(EMontageType::HeavyAttack) : MontageComp->PlayMontage(EMontageType::DefaultAttack);
	}
}
//�޺� ����
void APlayerCharacter::ResetAttack()
{
	MontageComp->Count = 0;
	MontageComp->CustomCount = 0;
	bSaveAttack = false;
	bAttacking = false;	
}
//Guard
void APlayerCharacter::Guard()
{
	if (bCanGuard != true || EquipmentComp->GetCurrentWeapon() == nullptr || bSliding || bRolling || !bIsCombat || StatsComp->Stamina.Current <= 0.f) return;
	if (bGuarding == false)
	{
		if (GetCharacterMovement()->MaxWalkSpeed > 200.f)
			GetCharacterMovement()->MaxWalkSpeed = 200.f;
		MontageComp->PlayMontage(EMontageType::Guard);
		bGuarding = true;

		FName AttachName;
		if (EquipmentComp->GetCurrentWeaponType() == EWeaponType::GreatSword)
			AttachName = FName("GreatSword_Guard");
		EquipmentComp->MainWeaponComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), AttachName);
		if (EquipmentComp->GetCurrentEnchant())
			EquipmentComp->ParticleComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), AttachName);
		StatsComp->StaminaStopTimerFunc();
	}
}
void APlayerCharacter::Guard_Cancel()
{
	if (bGuarding)
	{
		StopAnimMontage(MontageComp->GetMontages().Guard);
		bGuarding = false;
		GetCharacterMovement()->MaxWalkSpeed = SaveCurrentSpeed;

		FName AttachName;
		if (EquipmentComp->GetCurrentWeaponType() == EWeaponType::GreatSword)		
			AttachName = FName("GreatSword");
		EquipmentComp->MainWeaponComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), AttachName);
		if (EquipmentComp->GetCurrentEnchant())
			EquipmentComp->ParticleComp->AttachToComponent(GetMesh(), FAttachmentTransformRules(EAttachmentRule::KeepRelative, true), AttachName);
		StatsComp->StaminaUpTimerFunc();
		ResetAttack();
	}
}

//�丵
void APlayerCharacter::Parry()
{
	if (!bIsParry && EquipmentComp->GetCurrentWeapon() && !bSliding && !bRolling && bIsCombat)
	{
		//CurrentCamSet
		CurrentCamSet.Location = Camera->GetRelativeLocation();
		CurrentCamSet.Rotation = Camera->GetRelativeRotation();
		CurrentCamSet.SocketOffset = SpringArm->SocketOffset;
		CurrentCamSet.ArmLength = SpringArm->TargetArmLength;
		CurrentCamSet.CamLagSpeed = SpringArm->CameraLagSpeed;
		//ParryCamSet
		DestCamSet.Location = FVector(80.f, 130.f, 20.f);
		DestCamSet.Rotation = FRotator(0.f, -30.f, 0.f);
		DestCamSet.SocketOffset = FVector(70.f, 40.f, 40.f);
		DestCamSet.ArmLength = 300.f;
		DestCamSet.CamLagSpeed = 7.f;

		MontageComp->PlayMontage(EMontageType::Parry);
		ResetAttack();
	}
}

//ī�޶��� Ÿ�Ӷ���
void APlayerCharacter::PlayCameraZoomTimeline(float value)
{
	FRotator rA = CurrentCamSet.Rotation;
	FRotator rB = DestCamSet.Rotation;
	FVector vA = CurrentCamSet.Location;
	FVector vB = DestCamSet.Location;
	FVector osA = CurrentCamSet.SocketOffset;
	FVector osB = DestCamSet.SocketOffset;
	float fA = CurrentCamSet.ArmLength;
	float fB = DestCamSet.ArmLength;

	FRotator LerpCamRot = UKismetMathLibrary::RLerp(rA, rB, value, false);
	Camera->SetRelativeRotation(LerpCamRot);
	FVector LerpLoc = UKismetMathLibrary::VLerp(vA, vB, value);
	Camera->SetRelativeLocation(LerpLoc);
	FVector LerpSocketOffset = UKismetMathLibrary::VLerp(osA, osB, value);
	SpringArm->SocketOffset = LerpSocketOffset;
	float LerpArmLength = UKismetMathLibrary::Lerp(fA, fB, value);
	SpringArm->TargetArmLength = LerpArmLength;
}

//��밡 �׷α�����϶� Finish�� ������. 
void APlayerCharacter::FinishExecute()
{
	if (bCanExecution && EquipmentComp->GetCurrentWeapon() && !bSliding && !bRolling && bIsCombat)
	{		
		TArray<AActor*> ExecuteTargets; ExecuteTargets.Empty();//Target Setting
		TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes; ObjectTypes.Empty();
		ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_Pawn));
		ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
		TArray<AActor*> IgnoreActors; IgnoreActors.Empty();
		IgnoreActors.Add(this);
		TArray<AActor*> OuterActors; OuterActors.Empty();
		if(UKismetSystemLibrary::SphereOverlapActors(GetWorld(), GetActorLocation(), 200.f, ObjectTypes, nullptr, IgnoreActors, OuterActors) == false) return;
		for (AActor* Outer : OuterActors)
		{
			if (IsValid(Outer) && Outer->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()) && this->GetDotProductTo(Outer) > 0.7f && Outer->GetDotProductTo(this) > 0.7f)
			{
				if (EnemyTags.Contains(ICombatInterface::Execute_GetTag(Outer)))
					ExecuteTargets.Add(Outer);
			}
		}
		if (ExecuteTargets.Num() > 0)
		{
			ResetAttack();
			DisableInput(PC);
			ICombatInterface::Execute_SetExecutionMode(ExecuteTargets[0]);
			//Charging			
			MontageComp->PlayMontage_Skill(FName("Charging"));
			CameraZoomTimeline.Play();
			//and Execution
			FTimerHandle handle;
			GetWorld()->GetTimerManager().SetTimer(handle, FTimerDelegate::CreateLambda([&]() {	
				CameraZoomTimeline.Reverse();
				FTimerHandle inputhandle;
				float delay = MontageComp->PlayMontage(EMontageType::Execution) - 0.2f;
				GetWorld()->GetTimerManager().SetTimer(inputhandle, FTimerDelegate::CreateLambda([&]() {
					EnableInput(PC);
					GetWorld()->GetTimerManager().ClearTimer(handle);
					GetWorld()->GetTimerManager().ClearTimer(inputhandle);
				}), delay, false);
			}), 1.f, false);		
		}
	}
}

//������
void APlayerCharacter::Roll()
{
	if (bRolling || bSliding || StatsComp->Stamina.Current < 20.f)
		return;
	ResetAttack();
	StatsComp->UpdateHPMPST(EStat::Stamina, 20.f, false);	
	StatsComp->StaminaStopTimerFunc();
	StatsComp->StaminaUpTimerFunc();
	if (GetCharacterMovement()->bOrientRotationToMovement == false)
	{
		//�Է¹����� �˻��Ͽ� �˸´� ��Ÿ�� ���
		if (ForwardAxis >= 0 && RightAxis == 0)
			MontageComp->PlayMontage(EMontageType::Rolling_F);
		else if (ForwardAxis >= 0 && RightAxis > 0)
			MontageComp->PlayMontage(EMontageType::Rooling_R);
		else if (ForwardAxis >= 0 && RightAxis < 0)
			MontageComp->PlayMontage(EMontageType::Rolling_L);
		else if (ForwardAxis < 0)
			MontageComp->PlayMontage(EMontageType::Rolling_B);
	}
	else
	{
		MontageComp->PlayMontage(EMontageType::Rolling_NT);
	}
}
//�����̵�
void APlayerCharacter::Slide()
{
	if (bRolling || bSliding || StatsComp->Stamina.Current < 10.f)
		return;
	ResetAttack();
	StatsComp->UpdateHPMPST(EStat::Stamina, 10.f, false);
	StatsComp->StaminaStopTimerFunc();
	StatsComp->StaminaUpTimerFunc();
	if (GetCharacterMovement()->bOrientRotationToMovement == false)
	{
		//�Է¹����� �˻��Ͽ� �˸´� ��Ÿ�� ���
		if (ForwardAxis >= 0 && RightAxis == 0)
			MontageComp->PlayMontage(EMontageType::Slide_F);
		else if (ForwardAxis >= 0 && RightAxis > 0)
			MontageComp->PlayMontage(EMontageType::Slide_R);
		else if (ForwardAxis >= 0 && RightAxis < 0)
			MontageComp->PlayMontage(EMontageType::Slide_L);
		else if (ForwardAxis < 0)
			MontageComp->PlayMontage(EMontageType::Slide_B);
	}
	else
		MontageComp->PlayMontage(EMontageType::Slide_NT);
}
void APlayerCharacter::LongSlide()
{
	if(bRolling || bSliding || StatsComp->Stamina.Current < 10.f)return;
	ResetAttack();
	StatsComp->UpdateHPMPST(EStat::Stamina, 10.f, false);
	StatsComp->StaminaStopTimerFunc();
	StatsComp->StaminaUpTimerFunc();
	MontageComp->PlayMontage_Skill(FName("LongSlide"));
}
void APlayerCharacter::Targeting()
{
	TargetingComp->ToggleCameraLock();
}

void APlayerCharacter::DrinkPotion()
{
	for (int32 i = 0; i < InventoryComp->InventoryItems.Num(); i++)
	{
		if (IsValid(InventoryComp->InventoryItems[i].ItemClass))
		{
			auto ItemOb = Cast<APotion>(InventoryComp->InventoryItems[i].ItemClass.GetDefaultObject());
			if (IsValid(ItemOb))
				InventoryComp->UseItemAtidx(i, 1);
		}
	}
}

//rŰ�� ���� Ư������
void APlayerCharacter::SpecialAttack()
{
	if (EquipmentComp->GetCurrentWeapon() && !bSliding && !bRolling && bIsCombat && !bIsParry && !bSpecialAttack && bCanSpecialAttack && StatsComp->MP.Current >= StatsComp->MP.Max) //�������� �����ϴٸ�
	{	
		//2.3m�̳��� �������� ���� ����� ���� Ž��
		UArrowComponent* TeleportPos = nullptr; //�����̵���ų ��ġ
		TArray<AActor*> Targets; Targets.Empty();//Target Setting
		TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes; ObjectTypes.Empty();
		ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_Pawn));
		ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
		TArray<AActor*> IgnoreActors; IgnoreActors.Empty();
		IgnoreActors.Add(this);
		TArray<AActor*> OuterActors; OuterActors.Empty();
		TArray<float>Distances; Distances.Empty();
		if (UKismetSystemLibrary::SphereOverlapActors(GetWorld(), GetActorLocation(), 230.f, ObjectTypes, nullptr, IgnoreActors, OuterActors) == false) return;	
		for (AActor* Outer : OuterActors)
		{
			if (IsValid(Outer) && Outer->GetClass()->ImplementsInterface(UCombatInterface::StaticClass()))
			{
				if (EnemyTags.Contains(ICombatInterface::Execute_GetTag(Outer)))
				{					
					Targets.Add(Outer);
					Distances.Add(GetDistanceTo(Outer));
				}
			}
		}		
		if ((Targets.Num() > 0))
		{			
			int32 MinDistanceidx = -1;
			float MinDistance = 0;
			UKismetMathLibrary::MinOfFloatArray(Distances, MinDistanceidx, MinDistance);
			if (Distances.Num() > 0)
			{
				TeleportPos = ICombatInterface::Execute_GetBehindArrowPos(Targets[MinDistanceidx]);				
				ICombatInterface::Execute_SetSpecialHit(Targets[MinDistanceidx], true);				
			}

			//CurrentCamSet
			CurrentCamSet.Location = Camera->GetRelativeLocation();
			CurrentCamSet.Rotation = Camera->GetRelativeRotation();
			CurrentCamSet.SocketOffset = SpringArm->SocketOffset;
			CurrentCamSet.ArmLength = SpringArm->TargetArmLength;
			CurrentCamSet.CamLagSpeed = SpringArm->CameraLagSpeed;
			//ZoomCamSet
			DestCamSet.Location = FVector(600.f, -500.f, 70.f);
			DestCamSet.Rotation = FRotator(0.f, 80.f, 0.f);
			DestCamSet.SocketOffset = FVector(0.f, 0.f, 00.f);
			DestCamSet.ArmLength = 540.f;
			DestCamSet.CamLagSpeed = 7.f;

			SetActorLocation(TeleportPos->GetComponentLocation()); 
			bImmotal = true;
			bSpecialAttack = true;
			DisableInput(PC);
			SpringArm->bUsePawnControlRotation = false;

			StatsComp->UpdateHPMPST(EStat::MP, StatsComp->MP.Max, false);

			//�����Լ��� Delay����
			float delay = MontageComp->PlayMontage(EMontageType::SpecialAttack);			
			GetWorld()->GetTimerManager().SetTimer(SAZoomhandle, FTimerDelegate::CreateLambda([&]() {
				CameraZoomTimeline.Play();
				GetWorld()->GetTimerManager().SetTimer(SpecialAttackhandle, FTimerDelegate::CreateLambda([&]() {
					CameraZoomTimeline.Reverse();
					bImmotal = false;
					bSpecialAttack = false;
					SpringArm->bUsePawnControlRotation = true;
					EnableInput(PC);						
					GetWorld()->GetTimerManager().ClearTimer(SAZoomhandle);
					GetWorld()->GetTimerManager().ClearTimer(SpecialAttackhandle);					
				}), 4.0f, false);
			}), 1.0f, false);
		}		
	}
}

//Ÿ�ָ̹°� ȸ�ǽ� GhostTrail�ߵ�
void APlayerCharacter::StartGhostTrail()
{
	if (BossTarget == nullptr) return;
	auto EMeleeCombatComp = BossTarget->FindComponentByClass<UMeleeCombatComponent>();
	if (EMeleeCombatComp && EMeleeCombatComp->IsPerformTrace() == true && EMeleeCombatComp->GetDamageActor() == nullptr)
	{
		if (GetDistanceTo(BossTarget) <= 600.f && this->GetDotProductTo(BossTarget) > 0.35f) //���� ���� ���� �ٶ󺸴°����� 0.35(�뷫 50��)�̻��Ͻ� 
		{
			GetWorld()->GetTimerManager().SetTimer(GhostTrailhandle, this, &APlayerCharacter::SpawnGhostTrail, 0.09f, true);
			UGameplayStatics::SetGlobalTimeDilation(GetWorld(), 0.35f);
		}
	}
}
//GhostTrail�ߴ�
void APlayerCharacter::StopGhostTrail()
{
	GetWorld()->GetTimerManager().ClearTimer(GhostTrailhandle);
	UGameplayStatics::SetGlobalTimeDilation(GetWorld(), 1.0f);
}
void APlayerCharacter::SpawnGhostTrail()
{
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Owner = this;	
	GetWorld()->SpawnActor<AGhostTrail>(GetActorLocation(), GetActorRotation(), SpawnInfo);
}
//
