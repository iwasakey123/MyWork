// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "KilsuARPG/Data/Interface/StateInterface.h"
#include "KilsuARPG/Data/Interface/CombatInterface.h"
#include "Components/TimelineComponent.h"
#include "KilsuARPG/Data/Enum/EItem.h"
#include "KilsuARPG/Data/Struct/FCollisionComponent.h"
#include "KilsuARPG/Data/Struct/FDynamicCam.h"
#include "PlayerCharacter.generated.h"

UCLASS()
class KILSUARPG_API APlayerCharacter : public ACharacter, public IStateInterface, public ICombatInterface
{
	GENERATED_BODY()

public:
	APlayerCharacter();

protected:
	virtual void BeginPlay() override;	

	UPROPERTY() class AMyPlayerController* PC;
	UPROPERTY(visibleAnywhere, blueprintReadonly) class USpringArmComponent* SpringArm;
	UPROPERTY(visibleAnywhere, blueprintReadonly) class UCameraComponent* Camera;
	UPROPERTY() TSubclassOf<class AMeshCaptureActor> CapturedMeshClass;
	UPROPERTY() AMeshCaptureActor* CapturedMesh;

	//�ڽ�Ƭ�� ���� SkeletonMesh ������ ���
	UPROPERTY(EditAnywhere) USkeletalMeshComponent* Hair;
	UPROPERTY() USkeletalMesh* Hair_NoEquip;
	UPROPERTY() USkeletalMesh* Hair_HeadEquip;
	UPROPERTY() USkeletalMesh* Head_Default;
	UPROPERTY() USkeletalMesh* Upper_Default;
	UPROPERTY() USkeletalMesh* Lower_Default;
	UPROPERTY() USkeletalMesh* Hand_Default;
	UPROPERTY() USkeletalMesh* Shoes_Default;
	UPROPERTY() USkeletalMesh* Cape_Default;

	//bool ���� �÷��̾���¸� �����ϴ� ����
	UPROPERTY() bool bIsCombat;
	UPROPERTY() bool bDead;
	UPROPERTY() bool bIsWalk;
	UPROPERTY() bool bIsSprint;
	UPROPERTY() bool bArming;
	UPROPERTY() bool bAttacking;
	UPROPERTY() bool bRolling;
	UPROPERTY() bool bSliding;
	UPROPERTY() bool bSaveAttack;
	UPROPERTY() bool bGuarding;
	UPROPERTY() bool bImmotal;
	UPROPERTY() bool bGuardHit;
	UPROPERTY() bool bIsParry;	
	UPROPERTY() bool bIsShiftDown;
	UPROPERTY() bool bIsCtrlDown;
	UPROPERTY() bool bSuperArmor;
	UPROPERTY() bool bSpecialAttack;
	UPROPERTY() bool bHit;
	
	UPROPERTY() bool bCanAttack = true;
	UPROPERTY() bool bCanArm = true;
	UPROPERTY() bool bCanWalk = true;
	UPROPERTY() bool bCanSprint = true;
	UPROPERTY() bool bCanGuard = true;
	UPROPERTY() bool bCanExecution;
	UPROPERTY() bool bCanSpecialAttack = true;
	
	//�Ǿƽĺ��� ���� �±�
	UPROPERTY(EditAnywhere, meta = (AllowProtectedAccess = "true")) FName MyTag;
	UPROPERTY(EditAnywhere, meta = (AllowProtectedAccess = "true")) TArray<FName>EnemyTags;
	UPROPERTY(EditAnywhere, meta = (AllowProtectedAccess = "true")) TArray<FName>AllianceTags;

	//�޸���, Ÿ�Ӷ���
	UPROPERTY() FTimeline SprintTimeline;
	UPROPERTY() class UCurveFloat* SprintCurveFloat;
	UPROPERTY() float SaveCurrentSpeed;
	UFUNCTION() void PlaySprintTimeline(float value);
	UPROPERTY() FTimerHandle SprintStaminaHandle;

	//ī�޶���, Ÿ�Ӷ���
	UPROPERTY() FDynamicCam CurrentCamSet;
	UPROPERTY() FDynamicCam DestCamSet;
	UPROPERTY() FTimeline CameraZoomTimeline;
	UPROPERTY() UCurveFloat* CameraZoomFloat;	
	UFUNCTION() void PlayCameraZoomTimeline(float value);

	//Do Once
	UPROPERTY() bool bDo;
	//UFUNCTION() void DoOnceFunc();
	//UFUNCTION() void ResetDoOnceFunc();
	
	//Physics ����
	UPROPERTY() bool bHitImpulse;
	UPROPERTY() float HitPower;

	//Particles (����Ʈ)
	UPROPERTY() class UParticleSystem* P_DamagedEffect;
	UPROPERTY() UParticleSystem* P_DamagedSlashEffect;
	UPROPERTY() UParticleSystem* P_AttackHitEffect;
	UPROPERTY() UParticleSystem* P_AttackSlashEffect;
	UPROPERTY() UParticleSystem* P_GuardEffect;
	UPROPERTY() UParticleSystem* P_GuardHitEffect;
	UPROPERTY() UParticleSystem* P_ParryEffect;
	//����
	UPROPERTY() class USoundBase* S_ParrySound;

public:
	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	//�÷��̾� ĳ���͸� �����ϴ� ������Ʈ��
	UPROPERTY() class UInteractComponent* InteractComp; //��ȣ�ۿ�
	UPROPERTY() class UInventoryComponent* InventoryComp; //�κ��丮
	UPROPERTY() class UEquipmentComponent* EquipmentComp; //���
	UPROPERTY() class UMontageComponent* MontageComp; //��Ÿ��
	UPROPERTY() class UMeleeCombatComponent* MeleeCombatComp; //����
	UPROPERTY() class URotateComponent* RotateComp; //ȸ��
	UPROPERTY() class UTargetingComponent* TargetingComp; //Ÿ����
	UPROPERTY() class UStatsComponent* StatsComp; //����
	UPROPERTY() class USkillComponent* SkillComp; //��ų

	//inline�Լ��� ����Ͽ� �����Ϸ��� ��ġ���ʰ� ������ �����ɴϴ�.
	FORCEINLINE UCameraComponent* GetCamera() { return Camera; }
	FORCEINLINE	USkeletalMeshComponent* GetHair() { return Hair; }
	FORCEINLINE FDynamicCam GetCurrentCamSet() { return CurrentCamSet; }
	FORCEINLINE FDynamicCam GetDestCamSet() { return DestCamSet; }	

	//�����۰��� ��ȣ�ۿ��Ҷ� ���̴� Widget
	UPROPERTY() class UWidgetComponent* InteractWidgetComp;
		
	UPROPERTY() class UArrowComponent* TargetingArrow;
	UPROPERTY() AActor* BossTarget;

	//������ ���Ⱑ �ƴ� �ָ��� �Ҷ�, SphereTrace ���� ��ġ�� ���� �����̸���. 
	UPROPERTY() TArray<FName>HandRightSocketNames;
	UPROPERTY() TArray<FName>HandLeftSocketNames;

	//Axis Variables
	UPROPERTY() float ForwardAxis;
	UPROPERTY() float RightAxis;
	//Axis Func
	UFUNCTION() void MoveForward(float value);
	UFUNCTION() void MoveRight(float value);
	UFUNCTION() void Turn(float value);
	UFUNCTION() void LookUp(float value);

	//Input Action
	UFUNCTION() void InventoryUIOpen();
	UFUNCTION() void EquipmentUIOpen();
	UFUNCTION() void MenuUIOpen();
	UFUNCTION() void ShiftDown();
	UFUNCTION() void ShiftUp();
	UFUNCTION() void CtrlDown();
	UFUNCTION() void CtrlUp();
	UFUNCTION() void Sprint();
	UFUNCTION() void Walk();
	UFUNCTION() void CombatOnOff();
	UFUNCTION() void Interaction();
	UFUNCTION() void Input_1();
	UFUNCTION() void Input_2();
	UFUNCTION() void Input_3();
	UFUNCTION() void Attack();
	UFUNCTION() void SaveAttack();
	UFUNCTION() void ResetAttack();
	UFUNCTION() void Guard();
	UFUNCTION() void Guard_Cancel();
	UFUNCTION() void Parry();
	UFUNCTION() void FinishExecute();
	UFUNCTION() void Roll();
	UFUNCTION() void Slide();
	UFUNCTION() void LongSlide();
	UFUNCTION() void Targeting();
	UFUNCTION() virtual void Die();
	UFUNCTION() void DrinkPotion();
	UFUNCTION() void SpecialAttack();
	UPROPERTY() FTimerHandle SpecialAttackhandle;
	UPROPERTY() FTimerHandle SAZoomhandle;

	UFUNCTION() void StartGhostTrail();
	UFUNCTION() void StopGhostTrail();
	UFUNCTION() void SpawnGhostTrail();
	UPROPERTY() FTimerHandle GhostTrailhandle;

	//DECLARE MeleeCombat
	UFUNCTION() void CollisionActivated(ECollisionParts CollisionType);
	UFUNCTION() void AttackHit(FHitResult Hit);
	//DECLARE InventoryUpdateUI
	UFUNCTION() void UpdateSlotUI();
	UFUNCTION() void UpdateMeshRender(EEquipmentType EquipmentType, FName BoneName, UStaticMesh* StMesh, USkeletalMesh* SKMesh);
	UFUNCTION() void UpdateEquipmentUI(TSubclassOf<class AItem>EquipmentClass, EEquipmentType EquipmemtType);
	//DECLARE Stats
	UFUNCTION() void SetSaveMoveSpeed();

	//IStateInterface
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsAlive();
	virtual bool IsAlive_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) float GetAttackSpeed();
	virtual float GetAttackSpeed_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsCombat();
	virtual bool IsCombat_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsImmotal();
	virtual bool IsImmotal_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetImmotal(bool on);
	virtual void SetImmotal_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetCombat(bool Combat);
	virtual void SetCombat_Implementation(bool Combat) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetRolling(bool on);
	virtual void SetRolling_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetSliding(bool on);
	virtual void SetSliding_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsWalk();
	virtual bool IsWalk_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsSprint();
	virtual bool IsSprint_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool IsSuperArmor();
	virtual bool IsSuperArmor_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetSuperArmor(bool on);
	virtual void SetSuperArmor_Implementation(bool on) override;

	//CombatInterface
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) FRotator GetDesiredRotation();
	virtual FRotator GetDesiredRotation_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) FName GetTag();
	virtual FName GetTag_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) bool CheckEnemy(const FName& Tag);
	virtual bool CheckEnemy_Implementation(const FName& Tag) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void TakeDamaged(const FDamage& Damage, AActor* Causer);
	virtual void TakeDamaged_Implementation(const FDamage& Damage, AActor* Causer) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetEnemyTarget(AActor* Enemy, EAIType AIType);
	virtual void SetEnemyTarget_Implementation(AActor* Enemy, EAIType AIType) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetCanGuard(bool on);
	virtual void SetCanGuard_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetCanWalk(bool on);
	virtual void SetCanWalk_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetCanSprint(bool on);
	virtual void SetCanSprint_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void SetIsParry(bool on);
	virtual void SetIsParry_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void CanFinishExecute(bool on);
	virtual void CanFinishExecute_Implementation(bool on) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void CallResetAttack();
	virtual void CallResetAttack_Implementation() override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable) void GhostTailOnOff(bool on);
	virtual void GhostTailOnOff_Implementation(bool on) override;	
};
