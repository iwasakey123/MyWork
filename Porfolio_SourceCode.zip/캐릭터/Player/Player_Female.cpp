// Fill out your copyright notice in the Description page of Project Settings.

#include "Player_Female.h"
#include "KilsuARPG/Components/InteractComponent.h"
#include "KilsuARPG/Components/InventoryComponent.h"
#include "KilsuARPG/Components/EquipmentComponent.h"
#include "KilsuARPG/Components/MontageComponent.h"
#include "KilsuARPG/Components/MeleeCombatComponent.h"
#include "KilsuARPG/Components/RotateComponent.h"
#include "KilsuARPG/Components/TargetingComponent.h"

APlayer_Female::APlayer_Female()
{
	//Mannequin ĳ���� ���̷�Ż �Ž�
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mannequin(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Heads/SK_HeadA.SK_HeadA'"));
	if (Mannequin.Succeeded())
		GetMesh()->SetSkeletalMesh(Mannequin.Object);
	//AnimBP �ִϸ��̼Ǻ�������Ʈ
	static ConstructorHelpers::FObjectFinder<UClass>AnimBP(TEXT("AnimBlueprint'/Game/BP/AnimInstance/ABP_PlayerFM.ABP_PlayerFM_C'"));
	if (AnimBP.Succeeded())
		GetMesh()->SetAnimInstanceClass(AnimBP.Object);
	//MeshCaptureActor ���â�� ���̴� �Ǵٸ� ĳ����
	static ConstructorHelpers::FClassFinder<AMeshCaptureActor>CapturedMeshclass(TEXT("Class'/Script/KilsuARPG.MeshCaptureActor_FM'"));
	if (CapturedMeshclass.Class != NULL)
		CapturedMeshClass = CapturedMeshclass.Class;
	//MontageTable
	static ConstructorHelpers::FObjectFinder<UDataTable>MontageTableOb(TEXT("DataTable'/Game/BP/Data/DataTable/MontagesDT_FM.MontagesDT_FM'"));
	if (MontageTableOb.Succeeded())
		MontageComp->MontageTable = MontageTableOb.Object;

	//�ƹ��͵� �������� �ʾ������� ����� ���ҽ��� �����ͼ� �����Ͽ����ϴ�.
	//Upper_Default 
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Upper_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/TopBodies/SK_TopBody_A.SK_TopBody_A'"));
	if (Upper_DefaultOb.Succeeded())
		Upper_Default = Upper_DefaultOb.Object;
	//Lower_Default
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Lower_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/BotBodies/SK_BotBody_A.SK_BotBody_A'"));
	if (Lower_DefaultOb.Succeeded())
		Lower_Default = Lower_DefaultOb.Object;
	//Hand_Default
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Hand_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Gauntlets/SK_HandsMerge.SK_HandsMerge'"));
	if (Hand_DefaultOb.Succeeded())
		Hand_Default = Hand_DefaultOb.Object;
	//Shoes_Default
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Shoes_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Shoes/SK_Feet.SK_Feet'"));
	if (Shoes_DefaultOb.Succeeded())
		Shoes_Default = Shoes_DefaultOb.Object;	
	//Cape_Default //����� ���ҽ������ �ּ�ó�� �Ͽ����ϴ�.
	//static ConstructorHelpers::FObjectFinder<USkeletalMesh>Cape_DefaultOb(TEXT("SkeletalMesh'/Game/Model/GhostLady_S2/Meshes/Characters/Separates/Heads/SK_HeadA.SK_HeadA'"));
	//if (Cape_DefaultOb.Succeeded())
	//	Cape_Default = Cape_DefaultOb.Object;
}

void APlayer_Female::BeginPlay()
{
	Super::BeginPlay();	

	//�ڽ�Ƭ ����, �Ӹ��� �⺻������ �����Դϴ�.
	//EquipmentComp->HeadComp->SetSkeletalMesh(Head_Default);
	EquipmentComp->UpperComp->SetSkeletalMesh(Upper_Default);
	EquipmentComp->LowerComp->SetSkeletalMesh(Lower_Default);
	EquipmentComp->HandComp->SetSkeletalMesh(Hand_Default);
	EquipmentComp->ShoesComp->SetSkeletalMesh(Shoes_Default); 
}

void APlayer_Female::Die()
{
	APlayerCharacter::Die();
	UE_LOG(LogTemp, Warning, TEXT("Player_Female Dead"));
}

