// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "InventorySlotWidget.generated.h"

UCLASS()
class KILSUARPG_API UInventorySlotWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	virtual void NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation) override;
	virtual bool NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;
public:
	UPROPERTY(BlueprintReadOnly) TSubclassOf<class AItem>SlotItemClass;
	UPROPERTY() int32 SlotIndex;
	UPROPERTY() int32 SlotItemAmount;

	UPROPERTY(meta = (BindWidget)) class UBorder* ItemBorder;
	UPROPERTY(meta = (BindWidget)) class UImage* Icon;
	UPROPERTY(meta = (BindWidget)) class UTextBlock* AmountText;

	UFUNCTION() void UpdateSlot();

};
