// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "KilsuARPG/Data/Struct/FItem.h"
#include "InventoryComponent.generated.h"

class AItem;
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KILSUARPG_API UInventoryComponent : public UActorComponent
{
	GENERATED_BODY()

private:
	UPROPERTY() int32 Gold;
	UPROPERTY() int32 MaxGold;
	UPROPERTY() int32 SlotAmount;
	UPROPERTY() int32 MaxStackSize;
public:	
	UInventoryComponent();

	DECLARE_EVENT(ACharacter, FUIUpdate) FUIUpdate UpdateInventoryUI;

	UPROPERTY() TArray<FInventoryItem> InventoryItems;
	UPROPERTY() TArray<FInventoryItem> Temp_InventoryItems;
	UPROPERTY() TArray<FInventoryItem> Hidden_InventoryItems;	   
	UFUNCTION() int32 FindEmptyidx();
	UFUNCTION() int32 FindStackidx(TSubclassOf<AItem>ItemClass);
	UFUNCTION() bool IsSlotEmpty(int32 idx);
	UFUNCTION() int32 AddItem(TSubclassOf<AItem>ItemClass, int32 Amount);
	UFUNCTION() bool RemoveItem(int32 idx, int32 Amount);
	UFUNCTION() void UseItemAtidx(int32 idx, int32 Amount);
	UFUNCTION() void DragSlotByInventory(int32 From_idx, int32 To_idx);
	UFUNCTION() bool AddItemAtidx(int32 idx, TSubclassOf<AItem>ItemClass, int32 Amount = 1);

	UFUNCTION() void Sort(EItemType ItemType);
	UFUNCTION() void Sort_All();
	UFUNCTION() void Sort_Weapon();
	UFUNCTION() void Sort_Armor();
	UFUNCTION() void Sort_Consumable();
	UFUNCTION() void Sort_Quest();
	UFUNCTION() void Sort_ETC();

	FORCEINLINE int32 GetAmountAtidx(int32 idx)
	{
		return (IsSlotEmpty(idx) == false) ? InventoryItems[idx].Amount : 0;
	}
	FORCEINLINE TSubclassOf<AItem> GetItemClassAtidx(int32 idx)
	{
		return (IsSlotEmpty(idx) == false) ? InventoryItems[idx].ItemClass : nullptr;
	}	

	FORCEINLINE int32 GetGold() { return Gold; }
	UFUNCTION() void AddGold(int32 money);
	UFUNCTION() void DrawOffGold(int32 money);
};
